package com.proximityvoice.app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class MixTest {
    // ผู้ฟังอยู่ที่ (0,0,0) หันไปทาง +z (yaw 0)
    private static double[] hear(double bx, double by, double bz, int mode) {
        return Mix.compute(0, 0, 0, 0, 1, "0", bx, by, bz, "0", mode, 0, 0);
    }

    @Test public void closeIsFullVolume() { assertEquals(1.0, hear(1.5, 0, 0, 0)[0], 1e-9); }
    @Test public void halfwayIsQuarterPower() { assertEquals(0.25, hear(17, 0, 0, 0)[0], 1e-9); }
    @Test public void tooFarIsSilent() { assertEquals(0.0, hear(32, 0, 0, 0)[0], 1e-9); assertEquals(0.0, hear(40, 0, 0, 0)[0], 1e-9); }

    @Test public void shoutReachesFurther() {
        assertEquals(0.0, hear(50, 0, 0, 0)[0], 1e-9);
        assertTrue(hear(50, 0, 0, 1)[0] > 0.2);
        assertEquals(0.0, hear(100, 0, 0, 1)[0], 1e-9);
    }

    @Test public void whisperIsShortRange() {
        assertEquals(0.16, hear(8, 0, 0, 2)[0], 1e-9);
        assertEquals(0.0, hear(14, 0, 0, 2)[0], 1e-9);
    }

    @Test public void panFollowsFacing() {
        // หันไป +z: ตะวันออก (+x) อยู่ซ้ายมือ, ตะวันตก (-x) อยู่ขวามือ
        assertEquals(-1.0, hear(10, 0, 0, 0)[1], 1e-9);
        assertEquals(1.0, hear(-10, 0, 0, 0)[1], 1e-9);
        assertEquals(0.0, hear(0, 0, 10, 0)[1], 1e-9);
    }

    @Test public void frontBackUpDown() {
        assertEquals(-1.0, hear(0, 0, 10, 0)[4], 1e-9);   // ข้างหน้า = z ลบ
        assertEquals(1.0, hear(0, 0, -10, 0)[4], 1e-9);   // ข้างหลัง = z บวก
        assertTrue(hear(0, 5, 10, 0)[3] > 0);             // อยู่สูงกว่า = y บวก
        assertTrue(hear(0, -5, 10, 0)[3] < 0);
        assertEquals(1.0, hear(10, 0, 0, 0)[2] * -1, 1e-9);
    }

    @Test public void veryCloseHasNoPan() {
        double[] m = hear(0.5, 0, 0, 0);
        assertEquals(1.0, m[0], 1e-9);
        assertEquals(0.0, m[1], 1e-9);
    }

    @Test public void otherDimensionIsSilent() {
        assertEquals(0.0, Mix.compute(0, 0, 0, 0, 1, "0", 1, 0, 0, "1", 0, 0, 0)[0], 1e-9);
    }

    @Test public void staleDataIsSilent() {
        assertEquals(0.0, Mix.compute(0, 0, 0, 0, 1, "0", 1, 0, 0, "0", 0, 3001, 0)[0], 1e-9);
        assertEquals(0.0, Mix.compute(0, 0, 0, 0, 1, "0", 1, 0, 0, "0", 0, 0, 3001)[0], 1e-9);
    }
}
