package com.proximityvoice.app;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/** หน้าตรวจระบบ: เช็กทีละอย่างว่าอะไรพร้อม/ไม่พร้อม พร้อมบอกวิธีแก้เป็นภาษาไทย */
public class DiagnosticsActivity extends Activity {
    private LinearLayout box, list;
    private final List<String> report = new ArrayList<>();
    private Button run;

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackground(Ui.bg());
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(24), dp(16), dp(40));
        sv.addView(box);
        setContentView(sv);

        LinearLayout hd = new LinearLayout(this);
        hd.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = new TextView(this);
        back.setText("\u2039"); back.setTextSize(30); back.setTextColor(Ui.FG); back.setGravity(Gravity.CENTER);
        back.setPadding(0, 0, 0, dp(3));
        android.graphics.drawable.GradientDrawable bb = new android.graphics.drawable.GradientDrawable();
        bb.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        bb.setColor(Color.parseColor("#2A352F"));
        back.setBackground(bb);
        back.setOnClickListener(v -> finish());
        hd.addView(back, new LinearLayout.LayoutParams(dp(42), dp(42)));
        TextView t = new TextView(this);
        t.setText("ตรวจระบบ"); t.setTextSize(22); t.setTextColor(Ui.FG); t.setTypeface(null, Typeface.BOLD);
        t.setPadding(dp(12), 0, 0, 0);
        hd.addView(t);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.setMargins(0, 0, 0, dp(10));
        box.addView(hd, hp);

        TextView sub = new TextView(this);
        sub.setText("เช็กว่าไมค์ อินเทอร์เน็ต เซิร์ฟเวอร์ และกลุ่มพร้อมใช้งานไหม ถ้าเพื่อนบอกว่า \"ไม่ได้ยินเสียง\" ให้กดตรวจที่นี่ก่อน");
        sub.setTextColor(Ui.MUT); sub.setTextSize(13);
        box.addView(sub);

        run = btn("ตรวจอีกครั้ง", true, this::runChecks);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setBackground(Ui.card(this));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(14), 0, 0);
        box.addView(list, lp);
        btn("คัดลอกผลทั้งหมด (ส่งให้คนช่วยดู)", false, () -> {
            ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("diag", String.join("\n", report)));
            Toast.makeText(this, "คัดลอกแล้ว", Toast.LENGTH_SHORT).show();
        });
        runChecks();
    }

    private Button btn(String label, boolean primary, Runnable r) {
        Button bt = new Button(this);
        bt.setText(label); bt.setAllCaps(false); bt.setTextColor(Color.WHITE); bt.setTextSize(15);
        bt.setBackground(Ui.round(primary ? Ui.AC_DARK : Color.parseColor("#2A352F"), dp(14)));
        bt.setStateListAnimator(null);
        bt.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(12), 0, 0);
        box.addView(bt, lp);
        return bt;
    }

    // ok: 1 = ผ่าน, 0 = เตือน, -1 = ไม่ผ่าน
    private void row(int ok, String title, String detail) {
        runOnUiThread(() -> {
            if (list.getChildCount() > 0) {
                android.view.View d = new android.view.View(this);
                d.setBackgroundColor(Ui.LINE);
                list.addView(d, new LinearLayout.LayoutParams(-1, 1));
            }
            LinearLayout r = new LinearLayout(this);
            r.setPadding(dp(14), dp(12), dp(14), dp(12));
            TextView ic = new TextView(this);
            ic.setText(ok > 0 ? "✓" : ok == 0 ? "!" : "✕");
            ic.setTextColor(Color.WHITE); ic.setTextSize(14); ic.setTypeface(null, Typeface.BOLD); ic.setGravity(Gravity.CENTER);
            ic.setBackground(Ui.round(ok > 0 ? Ui.AC_DARK : ok == 0 ? Color.parseColor("#B8860B") : Color.parseColor("#C0392B"), dp(15)));
            r.addView(ic, new LinearLayout.LayoutParams(dp(30), dp(30)));
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(12), 0, 0, 0);
            TextView a = new TextView(this);
            a.setText(title); a.setTextColor(Ui.FG); a.setTextSize(15); a.setTypeface(null, Typeface.BOLD);
            col.addView(a);
            if (detail != null && !detail.isEmpty()) {
                TextView s = new TextView(this);
                s.setText(detail); s.setTextColor(Ui.MUT); s.setTextSize(13);
                col.addView(s);
            }
            r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
            list.addView(r);
            report.add((ok > 0 ? "[OK] " : ok == 0 ? "[!!] " : "[XX] ") + title + (detail == null ? "" : " - " + detail));
        });
    }

    private int http(String u, String method) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
            c.setRequestMethod(method);
            c.setConnectTimeout(8000); c.setReadTimeout(8000);
            return c.getResponseCode();
        } catch (Exception e) { return -1; }
    }

    private void runChecks() {
        list.removeAllViews();
        report.clear();
        run.setEnabled(false);
        run.setText("กำลังตรวจ...");
        final boolean mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        new Thread(() -> {
            row(mic ? 1 : -1, "สิทธิ์ไมค์", mic ? "อนุญาตแล้ว" : "ยังไม่อนุญาต → ตั้งค่า > ตั้งค่าให้ครบในครั้งเดียว");

            boolean noti = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
            row(noti ? 1 : 0, "การแจ้งเตือน", noti ? "อนุญาตแล้ว" : "ไม่อนุญาต อาจทำให้ระบบฆ่าบริการเบื้องหลังง่ายขึ้น");
            boolean bat = ((PowerManager) getSystemService(POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName());
            row(bat ? 1 : 0, "ไม่จำกัดแบตเตอรี่", bat ? "ตั้งแล้ว" : "ยังไม่ตั้ง ระบบอาจตัดไมค์/เซิร์ฟเวอร์ตอนปิดจอ → ตั้งค่า > ตั้งค่าให้ครบ");
            row(Settings.canDrawOverlays(this) ? 1 : 0, "แสดงทับแอปอื่น (ปุ่มลอย)",
                    Settings.canDrawOverlays(this) ? "อนุญาตแล้ว" : "ยังไม่อนุญาต ใช้ปุ่มลอยไม่ได้ (ไม่จำเป็นถ้าไม่ใช้)");

            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            boolean hp = false;
            for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                int t = d.getType();
                if (t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || t == AudioDeviceInfo.TYPE_WIRED_HEADSET
                        || t == AudioDeviceInfo.TYPE_USB_HEADSET || t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP) hp = true;
            }
            row(1, "อุปกรณ์เสียงออก", hp ? "ตรวจพบหูฟัง (ซ้ายขวาเต็มเมื่อเลือกโหมดอัตโนมัติ)" : "ใช้ลำโพงเครื่อง");

            int net = http("https://www.gstatic.com/generate_204", "GET");
            row(net == 204 || net == 200 ? 1 : -1, "อินเทอร์เน็ต", net > 0 ? "ออนไลน์ได้" : "ต่อไม่ได้ → เช็กไวไฟ/เน็ตมือถือ");

            List<Group.G> gs = Group.list(this);
            String gid = Group.id(this);
            if (gid != null) {
                int g = http("https://ntfy.sh/pvgrp-" + gid.toLowerCase() + "/json?poll=1&since=1m", "GET");
                row(g == 200 ? 1 : -1, "กระดานกลุ่ม (ntfy.sh)", g == 200 ? "ติดต่อได้ (" + gs.size() + " กลุ่ม)" : g == 429 ? "ถูกจำกัดโควตาชั่วคราว (429) รอสักครู่" : "ติดต่อไม่ได้ (รหัส " + g + ")");
            } else row(0, "กลุ่ม", "ยังไม่ได้อยู่ในกลุ่มใด");

            HostService hs = HostService.instance;
            if (hs != null && hs.host != null) {
                row(hs.host.isRunning() ? 1 : -1, "เซิร์ฟเวอร์เสียงในเครื่อง", hs.host.isRunning() ? "ทำงานอยู่ (พอร์ต 3000)" : "ไม่ทำงาน");
                row(hs.host.gameConnected() ? 1 : 0, "การเชื่อมต่อเกม", hs.host.gameConnected()
                        ? "ต่ออยู่ ✓" : "ยังไม่ต่อ → ในเกมพิมพ์ /wsserver localhost:3001 (ต้องเปิด cheats)");
                row(1, "คนในห้องเสียง", hs.host.clientCount() + " คน");
                Tunnel t = hs.tunnel;
                if (t != null) {
                    String st = t.state;
                    boolean okT = "ok".equals(st);
                    row(okT ? 1 : "starting".equals(st) || "restarting".equals(st) ? 0 : -1,
                            t.permanent() ? "อุโมงค์ Cloudflare (ลิงก์ถาวร)" : "อุโมงค์ cloudflared",
                            okT ? "พร้อม" : "สถานะ: " + st + (t.permanent() ? " (ตรวจ token/โดเมนในตั้งค่า)" : " (ต่อไม่ติดให้ลองปิด-สร้างเซิร์ฟเวอร์ใหม่)"));
                    if (t.url != null) {
                        int c = http(t.url, "GET");
                        row(c == 200 ? 1 : -1, "ลิงก์ที่ให้เพื่อน", c == 200 ? t.url + " เปิดได้" : "เปิดลิงก์เองไม่ได้ (รหัส " + c + ") เพื่อนอาจเข้าไม่ได้");
                    }
                }
            } else {
                String jg = getSharedPreferences("pv", MODE_PRIVATE).getString("jgid", null);
                if (jg != null) {
                    try {
                        Group.Host w = Group.current(jg);
                        if (w == null) row(0, "เซิร์ฟเวอร์ของกลุ่ม", "ตอนนี้ไม่มีใครโฮสต์ในกลุ่มที่เข้าล่าสุด");
                        else {
                            int c = http(w.url, "GET");
                            row(c == 200 ? 1 : -1, "เซิร์ฟเวอร์ของ " + w.name, c == 200 ? "เปิดได้ ✓" : "ตอบไม่ได้ (รหัส " + c + ") โฮสต์อาจปิดแอป/เน็ตหลุด");
                        }
                    } catch (Exception e) { row(-1, "เซิร์ฟเวอร์ของกลุ่ม", "เช็กไม่ได้: " + e.getMessage()); }
                } else row(0, "เซิร์ฟเวอร์", "เครื่องนี้ไม่ได้โฮสต์ และยังไม่ได้เข้าเสียงของกลุ่มใด");
            }
            runOnUiThread(() -> { run.setEnabled(true); run.setText("ตรวจอีกครั้ง"); });
        }, "diag").start();
    }
}
