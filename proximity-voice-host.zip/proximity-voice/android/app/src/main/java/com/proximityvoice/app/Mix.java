package com.proximityvoice.app;

/** สูตรคำนวณเสียงตามตำแหน่ง (ไม่ผูกกับ Android เพื่อให้ทดสอบอัตโนมัติได้) */
final class Mix {
    static final double FULL = 2, MAX = 32, SHOUT = 3, WHISPER = 0.4;

    private Mix() { }

    /** ผู้ฟัง A (ตำแหน่ง/ทิศที่หัน afx,afz) ฟังผู้พูด B. mode: 0 ปกติ 1 ตะโกน 2 กระซิบ
     *  คืน [gain, pan, x, y, z, 0] โดย x=ขวา y=บน z=-หน้า (แบบ WebAudio) */
    static double[] compute(double ax, double ay, double az, double afx, double afz, String adim,
                            double bx, double by, double bz, String bdim,
                            int mode, long ageA, long ageB) {
        double[] none = {0, 0, 0, 0, 0, 0};
        if (ageA > 3000 || ageB > 3000 || adim == null || !adim.equals(bdim)) return none;
        double mult = mode == 1 ? SHOUT : mode == 2 ? WHISPER : 1;
        double full = FULL * mult, max = MAX * mult;
        double dx = bx - ax, dy = by - ay, dz = bz - az;
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double gain = dist <= full ? 1 : dist >= max ? 0 : 1 - (dist - full) / (max - full);
        double h = Math.hypot(dx, dz); if (h == 0) h = 1;
        double fl = Math.hypot(afx, afz); if (fl == 0) fl = 1;
        double fx = afx / fl, fz = afz / fl;
        // ขวามือของผู้ฟัง = (-fz, fx) ในพิกัด Minecraft (x=ตะวันออก, z=ใต้)
        double pan = Math.max(-1, Math.min(1, (dx / h) * -fz + (dz / h) * fx));
        if (dist < 1) return new double[]{gain * gain, 0, 0, 0, 0, 0};
        double fwd = (dx * fx + dz * fz) / dist;
        double right = (dx * -fz + dz * fx) / dist;
        return new double[]{gain * gain, pan, right, dy / dist, -fwd, 0};
    }
}
