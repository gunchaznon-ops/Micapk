package com.proximityvoice.app;

import android.content.Context;
import android.os.Build;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** เก็บรายงานตอนแอปเด้ง ไว้โชว์/คัดลอกในการเปิดครั้งถัดไป */
final class CrashReport {
    private CrashReport() { }

    private static File file(Context c) { return new File(c.getFilesDir(), "crash.txt"); }

    static void install(final Context app) {
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                String s = "เวลา: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())
                        + "\nเวอร์ชัน build: " + Updater.localVersion(app)
                        + "\nเครื่อง: " + Build.MANUFACTURER + " " + Build.MODEL + " (Android " + Build.VERSION.RELEASE + ")"
                        + "\nเธรด: " + t.getName()
                        + "\nสถานะ: " + (HostService.instance != null ? "กำลังโฮสต์" : "ไม่ได้โฮสต์")
                        + "\n\n" + sw;
                try (FileWriter w = new FileWriter(file(app), false)) { w.write(s.length() > 12000 ? s.substring(0, 12000) : s); }
            } catch (Throwable ignored) { }
            if (prev != null) prev.uncaughtException(t, e);
        });
    }

    /** รายงานที่ยังไม่ได้ลบ (null ถ้าไม่มี) */
    static String pending(Context c) {
        try {
            File f = file(c);
            if (!f.exists()) return null;
            java.io.BufferedReader r = new java.io.BufferedReader(new java.io.FileReader(f));
            StringBuilder sb = new StringBuilder();
            String l;
            while ((l = r.readLine()) != null) sb.append(l).append('\n');
            r.close();
            return sb.toString();
        } catch (Exception e) { return null; }
    }

    static void clear(Context c) { file(c).delete(); }
}
