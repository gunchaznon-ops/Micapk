package com.proximityvoice.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.PictureInPictureParams;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Rational;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.util.HashMap;

public class MainActivity extends Activity {
    private static final int REQ_MIC = 1;
    static WebView web;      // ให้ปุ่มลอยเรียกปิด/เปิดไมค์ได้
    static boolean visible;  // แอปอยู่หน้าจอหรือไม่
    private PermissionRequest pendingWebPermission;
    private boolean dialogOpen = false;
    private String loadedUrl = null;

    /** WebView ที่ไม่ยอมหยุดทำงานตอนแอปถูกพับ (ไม่งั้นไมค์ดับเมื่อพับนานๆ) */
    static class KeepWebView extends WebView {
        KeepWebView(Context c) { super(c); }
        @Override
        protected void onWindowVisibilityChanged(int v) {
            if (v != View.GONE) super.onWindowVisibilityChanged(View.VISIBLE);
        }
    }

    private SharedPreferences prefs() {
        return getSharedPreferences("pv", MODE_PRIVATE);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new KeepWebView(this);
        // เว็บเต็มจอ + แถบเมนูล่างที่ใช้บ่อย (กลุ่ม / เซิร์ฟเวอร์ / โหลดใหม่ / ตั้งค่า)
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#161B18"));
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        GradientDrawable barBg = new GradientDrawable();
        barBg.setColor(Color.parseColor("#1B2220"));
        barBg.setCornerRadii(new float[]{dp(20), dp(20), dp(20), dp(20), 0, 0, 0, 0});
        bar.setBackground(barBg);
        bar.setPadding(dp(8), dp(8), dp(8), dp(10));
        bar.setElevation(dp(8));
        bar.addView(navItem("\uD83D\uDC65", "กลุ่ม", null, () -> startActivity(new Intent(this, GroupActivity.class))), new LinearLayout.LayoutParams(0, -2, 1f));
        srvLabel = new TextView[1];
        bar.addView(navItem("\uD83D\uDDA5", "เซิร์ฟเวอร์", srvLabel, () -> startActivity(new Intent(this, HostActivity.class))), new LinearLayout.LayoutParams(0, -2, 1f));
        bar.addView(navItem("\u21BB", "โหลดใหม่", null, this::reloadPage), new LinearLayout.LayoutParams(0, -2, 1f));
        bar.addView(navItem("\u2699", "ตั้งค่า", null, () -> startActivity(new Intent(this, SettingsActivity.class))), new LinearLayout.LayoutParams(0, -2, 1f));
        navBar = bar;
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);

        web.addJavascriptInterface(new Object() {
            @android.webkit.JavascriptInterface
            public boolean hasHeadphones() { return headphonesNow(); }
        }, "AndroidBridge");
        audioCb = new AudioDeviceCallback() {
            @Override public void onAudioDevicesAdded(AudioDeviceInfo[] d) { pushHeadphones(); }
            @Override public void onAudioDevicesRemoved(AudioDeviceInfo[] d) { pushHeadphones(); }
        };
        ((AudioManager) getSystemService(AUDIO_SERVICE)).registerAudioDeviceCallback(audioCb, null);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("appassets.local".equals(u.getHost())) {
                    try {
                        String path = u.getPath();
                        if (path == null || path.equals("/")) path = "/index.html";
                        InputStream in = getAssets().open(path.substring(1));
                        String mime = path.endsWith(".html") ? "text/html" : "application/octet-stream";
                        return new android.webkit.WebResourceResponse(mime, "utf-8", in);
                    } catch (Exception e) {
                        return new android.webkit.WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                                new HashMap<String, String>(), null);
                    }
                }
                return super.shouldInterceptRequest(v, r);
            }

            @Override
            public void onPageStarted(WebView v, String u, android.graphics.Bitmap f) {
                pageFailed = false;
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) {
                    pageFailed = true;
                    Toast.makeText(MainActivity.this, "เปิดไม่ได้ กดปุ่ม ↻ มุมขวาบนเพื่อลองใหม่", Toast.LENGTH_LONG).show();
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest req) {
                runOnUiThread(() -> {
                    if (hasMic()) {
                        grantAudio(req);
                    } else {
                        // ขอสิทธิ์ไมค์เฉพาะตอนที่กดเข้าร่วมเสียงจริงๆ
                        pendingWebPermission = req;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                    }
                });
            }
        });

        String fromLink = linkFromIntent(getIntent());
        if (fromLink != null) prefs().edit().putString("url", fromLink).apply();
        boolean ask = getIntent().getBooleanExtra("ask", false);
        // ถ้าอยู่ในกลุ่ม ให้หน้ากลุ่มเป็นคนเลือกเซิร์ฟเวอร์ (ลิงก์เก่าหมดอายุทุกครั้งที่สร้างใหม่)
        if (fromLink == null && !ask && Group.any(this)) prefs().edit().remove("url").apply();
        String url = prefs().getString("url", null);
        if (url == null) {
            if (ask) askUrl("ใส่ที่อยู่เซิร์ฟเวอร์เสียง");
            else startActivity(new Intent(this, GroupActivity.class));
        } else { loadedUrl = url; openTarget(url); }
    }

    /** ลิงก์ที่เพื่อนกดมา (https://xxx.trycloudflare.com หรือ pvoice://xxx.trycloudflare.com) */
    private String linkFromIntent(Intent i) {
        if (i == null || i.getData() == null) return null;
        Uri d = i.getData();
        String host = d.getHost();
        if (host == null || !host.endsWith(".trycloudflare.com")) return null;
        return "https://" + host;
    }

    private static final java.util.regex.Pattern CF_LINK =
            java.util.regex.Pattern.compile("https://([a-z0-9-]+)\\.trycloudflare\\.com");
    private String lastOffered = null;

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) checkClipboard();
    }

    /** เพื่อนคัดลอกลิงก์แล้วเปิดแอป → ถามว่าจะใช้ลิงก์นี้เลยไหม */
    private void checkClipboard() {
        if (dialogOpen || HostService.instance != null) return;
        try {
            android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip() || cm.getPrimaryClip().getItemCount() == 0) return;
            CharSequence t = cm.getPrimaryClip().getItemAt(0).getText();
            if (t == null) return;
            java.util.regex.Matcher m = CF_LINK.matcher(t);
            String link = null;
            while (m.find()) if (!"api".equals(m.group(1))) { link = m.group(0); break; }
            if (link == null || link.equals(prefs().getString("url", null)) || link.equals(lastOffered)) return;
            lastOffered = link;
            final String u = link;
            dialogOpen = true;
            new AlertDialog.Builder(this)
                    .setTitle("พบลิงก์เซิร์ฟเวอร์เสียง")
                    .setMessage(u + "\n\nเข้าห้องนี้เลยไหม?")
                    .setPositiveButton("เข้าเลย", (d, w) -> {
                        dialogOpen = false;
                        prefs().edit().putString("url", u).apply();
                        loadedUrl = u;
                        openTarget(u);
                    })
                    .setNegativeButton("ไม่", (d, w) -> dialogOpen = false)
                    .setOnCancelListener(d -> dialogOpen = false)
                    .show();
        } catch (Exception ignored) {
        }
    }

    private AudioDeviceCallback audioCb;

    /** มีหูฟัง (สาย / USB / บลูทูธ) ต่ออยู่ไหม */
    private boolean headphonesNow() {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
            int t = d.getType();
            if (t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || t == AudioDeviceInfo.TYPE_WIRED_HEADSET
                    || t == AudioDeviceInfo.TYPE_USB_HEADSET || t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP
                    || t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || t == AudioDeviceInfo.TYPE_HEARING_AID
                    || (android.os.Build.VERSION.SDK_INT >= 31 && t == 26 /* TYPE_BLE_HEADSET */)) return true;
        }
        return false;
    }

    private void pushHeadphones() {
        final boolean b = headphonesNow();
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window.onHeadphones&&window.onHeadphones(" + b + ")", null); });
    }

    private TextView[] srvLabel;
    private View navBar;

    @Override
    public void onPictureInPictureModeChanged(boolean inPip, android.content.res.Configuration cfg) {
        super.onPictureInPictureModeChanged(inPip, cfg);
        if (navBar != null) navBar.setVisibility(inPip ? View.GONE : View.VISIBLE);
    }

    private LinearLayout navItem(String icon, String label, TextView[] labelRef, Runnable tap) {
        LinearLayout it = new LinearLayout(this);
        it.setOrientation(LinearLayout.VERTICAL);
        it.setGravity(Gravity.CENTER);
        it.setPadding(0, dp(6), 0, dp(4));
        TextView i = new TextView(this);
        i.setText(icon); i.setTextSize(21); i.setTextColor(Color.WHITE); i.setGravity(Gravity.CENTER);
        it.addView(i);
        TextView l = new TextView(this);
        l.setText(label); l.setTextSize(11); l.setTextColor(Color.parseColor("#8FA196")); l.setGravity(Gravity.CENTER);
        it.addView(l);
        if (labelRef != null) labelRef[0] = l;
        it.setOnClickListener(v -> tap.run());
        return it;
    }

    /** จุดเขียวที่ "เซิร์ฟเวอร์" เมื่อเครื่องนี้กำลังโฮสต์อยู่ */
    private void refreshBar() {
        if (srvLabel == null || srvLabel[0] == null) return;
        boolean on = HostService.instance != null;
        srvLabel[0].setText(on ? "เซิร์ฟเวอร์ ●" : "เซิร์ฟเวอร์");
        srvLabel[0].setTextColor(Color.parseColor(on ? "#5FBF86" : "#8FA196"));
    }

    private volatile boolean pageFailed = false;

    /** ปุ่ม ↻ โหลดหน้าใหม่ */
    private void reloadPage() {
        String u = prefs().getString("url", null);
        if (u == null) { askUrl("ใส่ที่อยู่เซิร์ฟเวอร์เสียง"); return; }
        Runnable go = () -> {
            if (u.startsWith("http://localhost") && HostService.instance == null)
                Toast.makeText(this, "ยังไม่ได้เริ่มเซิร์ฟเวอร์ ไปที่ ⚙ > สร้างเซิร์ฟเวอร์ก่อน", Toast.LENGTH_LONG).show();
            loadedUrl = u;
            openTarget(u);
        };
        if (pageFailed) { go.run(); return; }
        // หน้ากำลังใช้งานอยู่ โหลดใหม่จะหลุดจากห้องเสียง จึงถามก่อน
        new AlertDialog.Builder(this)
                .setMessage("โหลดหน้าใหม่? จะหลุดจากห้องเสียงชั่วคราว")
                .setPositiveButton("โหลดใหม่", (d, w) -> go.run())
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    private boolean hasMic() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshBar();
        visible = true;
        applyPrefs();
        String url = prefs().getString("url", null);
        if (url != null && !url.equals(loadedUrl)) { loadedUrl = url; openTarget(url); }
    }

    @Override
    protected void onPause() {
        visible = false;
        if (VoiceService.instance != null) VoiceService.instance.applyBubble();
        super.onPause();
    }

    @Override
    protected void onStop() {
        // กันระบบพักหน้าเว็บตอนพับแอป
        if (web != null) { web.onResume(); web.resumeTimers(); }
        super.onStop();
    }

    private void applyPrefs() {
        if (prefs().getBoolean("screenOn", true)) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (hasMic() && prefs().getBoolean("keepalive", true)) startVoiceService();
        if (VoiceService.instance != null) VoiceService.instance.applyBubble();
    }

    /** ลิงก์ https/http เต็ม → เปิดตรงๆ; host:port หรือ ws:// → ใช้หน้าที่ฝังในแอป */
    private void openTarget(String input) {
        String u = input.trim();
        if (u.startsWith("https://") || u.startsWith("http://")) {
            web.loadUrl(u);
            return;
        }
        String ws = u;
        if (!(ws.startsWith("ws://") || ws.startsWith("wss://"))) ws = "ws://" + ws;
        web.loadUrl("https://appassets.local/index.html?server=" + Uri.encode(ws));
    }

    private void grantAudio(PermissionRequest req) {
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) {
                req.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                if (prefs().getBoolean("keepalive", true)) startVoiceService();
                return;
            }
        }
        req.deny();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (pendingWebPermission != null) {
            if (hasMic()) grantAudio(pendingWebPermission);
            else pendingWebPermission.deny();
            pendingWebPermission = null;
        }
    }

    private void startVoiceService() {
        try {
            startForegroundService(new Intent(this, VoiceService.class));
        } catch (Exception ignored) {
        }
    }

    private void askUrl(String title) {
        if (dialogOpen) return;
        dialogOpen = true;
        EditText et = new EditText(this);
        et.setHint("147.185.221.216:12345  หรือ  https://xxxx.trycloudflare.com");
        et.setText(prefs().getString("url", ""));
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(et)
                .setCancelable(false)
                .setNeutralButton("สร้างเซิร์ฟเวอร์เอง", (d, w) -> {
                    dialogOpen = false;
                    startActivity(new Intent(this, HostActivity.class));
                })
                .setPositiveButton("เปิด", (d, w) -> {
                    String u = et.getText().toString().trim();
                    dialogOpen = false;
                    if (u.isEmpty()) { askUrl("ใส่ที่อยู่เซิร์ฟเวอร์เสียง"); return; }
                    prefs().edit().putString("url", u).apply();
                    loadedUrl = u;
                    openTarget(u);
                })
                .show();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String lk = linkFromIntent(intent);
        if (lk != null) {
            prefs().edit().putString("url", lk).apply();
            loadedUrl = lk;
            openTarget(lk);
        }
        if (intent.getBooleanExtra("ask", false)) {
            askUrl("ใส่ที่อยู่เซิร์ฟเวอร์เสียง");
        } else if (intent.getBooleanExtra("join", false)) {
            String ju = prefs().getString("url", null);
            if (ju != null) { loadedUrl = ju; openTarget(ju); }
        }
        if (intent.getBooleanExtra("exit", false)) {
            stopService(new Intent(this, VoiceService.class));
            stopService(new Intent(this, HostService.class));
            finishAndRemoveTask();
        }
    }

    /** กดโฮม → ย่อเป็นหน้าต่างลอย (ถ้าเปิดไว้ในตั้งค่า) */
    @Override
    protected void onUserLeaveHint() {
        if (!prefs().getBoolean("pip", true)) return;
        try {
            enterPictureInPictureMode(
                    new PictureInPictureParams.Builder().setAspectRatio(new Rational(2, 1)).build());
        } catch (Exception ignored) {
        }
    }

    /** กดย้อนกลับ → ซ่อนแอปแต่ไม่ปิด */
    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        try { ((AudioManager) getSystemService(AUDIO_SERVICE)).unregisterAudioDeviceCallback(audioCb); } catch (Exception ignored) { }
        stopService(new Intent(this, VoiceService.class));
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }
}
