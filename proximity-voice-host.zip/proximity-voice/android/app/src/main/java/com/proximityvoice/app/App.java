package com.proximityvoice.app;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;

/** ติดตามว่ามีหน้าจอของแอปนี้อยู่หน้าจอไหม (ไว้ซ่อนปุ่มลอยเมื่อเปิดแอปเอง และโชว์เมื่อไปเล่นเกม) */
public class App extends Application implements Application.ActivityLifecycleCallbacks {
    static volatile boolean foreground;
    private int started;

    @Override
    public void onCreate() {
        super.onCreate();
        registerActivityLifecycleCallbacks(this);
    }

    private void change(boolean fg) {
        foreground = fg;
        if (VoiceService.instance != null) VoiceService.instance.applyBubble();
    }

    @Override public void onActivityStarted(Activity a) { if (++started == 1) change(true); }
    @Override public void onActivityStopped(Activity a) { if (started > 0 && --started == 0) change(false); }
    @Override public void onActivityCreated(Activity a, Bundle b) { }
    @Override public void onActivityResumed(Activity a) { }
    @Override public void onActivityPaused(Activity a) { }
    @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
    @Override public void onActivityDestroyed(Activity a) { }
}
