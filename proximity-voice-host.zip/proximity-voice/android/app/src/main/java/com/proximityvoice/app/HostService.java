package com.proximityvoice.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import android.os.IBinder;
import android.os.PowerManager;

/** บริการเบื้องหน้าที่รันเซิร์ฟเวอร์เสียง + cloudflared */
public class HostService extends Service {
    static final String ACTION_STOP = "com.proximityvoice.app.STOP_HOST";
    static HostService instance;

    volatile VoiceHost host;
    volatile Tunnel tunnel;
    volatile String error;
    private PowerManager.WakeLock wakeLock;
    volatile String gid;
    private String gname, gdev, gclaim;
    private Thread gthread;
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("host", "Voice Server", NotificationManager.IMPORTANCE_LOW));
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, HostActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 2,
                new Intent(this, HostService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, "host")
                .setContentTitle("เซิร์ฟเวอร์เสียงกำลังทำงาน")
                .setContentText("แตะเพื่อดูลิงก์")
                .setSmallIcon(android.R.drawable.ic_menu_share)
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "หยุด", stop).build())
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(2, n);
        }

        if (wakeLock == null) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "proximityvoice:host");
            wakeLock.acquire();
        }
        if (host == null) {
            VoiceHost h = new VoiceHost(getAssets());
            try {
                h.setRequireCode(getSharedPreferences("pv", MODE_PRIVATE).getBoolean("reqcode", false));
                h.start();
                host = h;
                error = null;
            } catch (Exception e) {
                error = "เริ่มเซิร์ฟเวอร์ไม่ได้ (พอร์ต 3000/3001 ถูกใช้อยู่? ปิด voice ใน Termux ก่อน): " + e.getMessage();
            }
        }
        boolean wantTunnel = intent == null || intent.getBooleanExtra("tunnel", true);
        if (host != null && wantTunnel && tunnel == null) {
            SharedPreferences sp = getSharedPreferences("pv", MODE_PRIVATE);
            Tunnel t = new Tunnel(sp.getString("cftoken", ""), sp.getString("cfhost", ""));
            tunnel = t;
            t.start(this, VoiceHost.VOICE_PORT);
        }
        String g = intent == null ? null : intent.getStringExtra("gid");
        if (g != null && host != null && gthread == null) {
            gid = g;
            gname = intent.getStringExtra("gname");
            gdev = intent.getStringExtra("gdev");
            gclaim = java.util.UUID.randomUUID().toString().substring(0, 8);
            gthread = new Thread(this::groupLoop, "group-host");
            gthread.setDaemon(true);
            gthread.start();
        }
        return START_NOT_STICKY;
    }

    /** ประกาศโฮสต์ไปที่กลุ่ม ส่งสัญญาณทุก 5 นาที และประกาศใหม่ทันทีเมื่อลิงก์เปลี่ยน (เช่น cloudflared ต่อใหม่) */
    private void groupLoop() {
        try {
            long end = System.currentTimeMillis() + 90000;
            while (tunnel != null && tunnel.url == null && System.currentTimeMillis() < end) Thread.sleep(500);
            if (tunnel == null || tunnel.url == null) {
                toastAndStop(tunnel != null && tunnel.permanent()
                        ? "ต่อ Cloudflare Tunnel ไม่สำเร็จ ตรวจ token/โดเมนในตั้งค่า"
                        : "ขอลิงก์ cloudflared ไม่สำเร็จ ลองสร้างใหม่อีกครั้ง");
                return;
            }
            Group.publishHost(this, gid, gname, tunnel.url, gdev, gclaim);
            Thread.sleep(3000);
            Group.Host w = Group.current(gid);
            if (w != null && !gdev.equals(w.dev)) {
                try { Group.publishStop(gid, gdev, gclaim); } catch (Exception ignored) { }
                gid = null;
                toastAndStop(w.name + " สร้างเซิร์ฟเวอร์ในกลุ่มนี้ไปก่อนแล้ว");
                return;
            }
            String lastUrl = tunnel.url;
            long lastBeat = System.currentTimeMillis();
            long noUrlSince = 0;
            while (true) {
                Thread.sleep(5000);
                String u = tunnel == null ? null : tunnel.url;
                if (u == null) {   // กำลังต่อใหม่ ถ้านานเกิน 3 นาทีให้ถอนประกาศ
                    if (noUrlSince == 0) noUrlSince = System.currentTimeMillis();
                    if (System.currentTimeMillis() - noUrlSince > 180000) {
                        try { Group.publishStop(gid, gdev, gclaim); } catch (Exception ignored) { }
                        toastAndStop("เซิร์ฟเวอร์ต่ออินเทอร์เน็ตไม่ได้นานเกินไป จึงปิดให้");
                        return;
                    }
                    continue;
                }
                noUrlSince = 0;
                boolean changed = !u.equals(lastUrl);
                if (changed || System.currentTimeMillis() - lastBeat >= Group.BEAT_MS) {
                    try {
                        Group.publishHost(this, gid, gname, u, gdev, gclaim);
                        lastUrl = u;
                        lastBeat = System.currentTimeMillis();
                    } catch (Exception ignored) { }   // ลองใหม่รอบถัดไป
                }
            }
        } catch (InterruptedException ignored) {
        } catch (Exception e) {
            toastAndStop("ประกาศเซิร์ฟเวอร์ให้กลุ่มไม่ได้ (ต้องมีอินเทอร์เน็ต): " + e.getMessage());
        }
    }

    private void toastAndStop(String msg) {
        main.post(() -> {
            Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
            stopSelf();
        });
    }

    @Override
    public void onDestroy() {
        if (gthread != null) gthread.interrupt();
        final String g = gid, d = gdev, c = gclaim;
        if (g != null) {
            Thread t = new Thread(() -> { try { Group.publishStop(g, d, c); } catch (Exception ignored) { } });
            t.start();
            try { t.join(2500); } catch (InterruptedException ignored) { }
        }
        if (tunnel != null) tunnel.stop();
        if (host != null) host.stop();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        instance = null;
        super.onDestroy();
    }
}
