package com.proximityvoice.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/** บริการเบื้องหน้าที่รันเซิร์ฟเวอร์เสียง + cloudflared */
public class HostService extends Service {
    static final String ACTION_STOP = "com.proximityvoice.app.STOP_HOST";
    static HostService instance;

    volatile VoiceHost host;
    volatile Tunnel tunnel;
    volatile String error;
    private PowerManager.WakeLock wakeLock;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("host", "Voice Server", NotificationManager.IMPORTANCE_LOW));
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, HostActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 2,
                new Intent(this, HostService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, "host")
                .setContentTitle("เซิร์ฟเวอร์เสียงกำลังทำงาน")
                .setContentText("แตะเพื่อดูลิงก์")
                .setSmallIcon(android.R.drawable.ic_menu_share)
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "หยุด", stop).build())
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(2, n);
        }

        if (wakeLock == null) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "proximityvoice:host");
            wakeLock.acquire();
        }
        if (host == null) {
            VoiceHost h = new VoiceHost(getAssets());
            try {
                h.start();
                host = h;
                error = null;
            } catch (Exception e) {
                error = "เริ่มเซิร์ฟเวอร์ไม่ได้ (พอร์ต 3000/3001 ถูกใช้อยู่? ปิด voice ใน Termux ก่อน): " + e.getMessage();
            }
        }
        boolean wantTunnel = intent == null || intent.getBooleanExtra("tunnel", true);
        if (host != null && wantTunnel && tunnel == null) {
            Tunnel t = new Tunnel();
            tunnel = t;
            t.start(this, VoiceHost.VOICE_PORT);
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        if (tunnel != null) tunnel.stop();
        if (host != null) host.stop();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        instance = null;
        super.onDestroy();
    }
}
