package com.proximityvoice.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import android.os.IBinder;
import android.os.PowerManager;

/** บริการเบื้องหน้าที่รันเซิร์ฟเวอร์เสียง + cloudflared */
public class HostService extends Service {
    static final String ACTION_STOP = "com.proximityvoice.app.STOP_HOST";
    static HostService instance;

    volatile VoiceHost host;
    volatile Tunnel tunnel;
    volatile String error;
    private PowerManager.WakeLock wakeLock;
    volatile String gid;
    private String gname, gdev, gclaim;
    private Thread gthread;
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("host", "Voice Server", NotificationManager.IMPORTANCE_LOW));
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, HostActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 2,
                new Intent(this, HostService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, "host")
                .setContentTitle("เซิร์ฟเวอร์เสียงกำลังทำงาน")
                .setContentText("แตะเพื่อดูลิงก์")
                .setSmallIcon(android.R.drawable.ic_menu_share)
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "หยุด", stop).build())
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(2, n);
        }

        if (wakeLock == null) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "proximityvoice:host");
            wakeLock.acquire();
        }
        if (host == null) {
            VoiceHost h = new VoiceHost(getAssets());
            try {
                h.start();
                host = h;
                error = null;
            } catch (Exception e) {
                error = "เริ่มเซิร์ฟเวอร์ไม่ได้ (พอร์ต 3000/3001 ถูกใช้อยู่? ปิด voice ใน Termux ก่อน): " + e.getMessage();
            }
        }
        boolean wantTunnel = intent == null || intent.getBooleanExtra("tunnel", true);
        if (host != null && wantTunnel && tunnel == null) {
            Tunnel t = new Tunnel();
            tunnel = t;
            t.start(this, VoiceHost.VOICE_PORT);
        }
        String g = intent == null ? null : intent.getStringExtra("gid");
        if (g != null && host != null && gthread == null) {
            gid = g;
            gname = intent.getStringExtra("gname");
            gdev = intent.getStringExtra("gdev");
            gclaim = java.util.UUID.randomUUID().toString().substring(0, 8);
            gthread = new Thread(this::groupLoop, "group-host");
            gthread.setDaemon(true);
            gthread.start();
        }
        return START_NOT_STICKY;
    }

    /** ประกาศโฮสต์ไปที่กลุ่ม แล้วส่งสัญญาณทุก 5 นาที */
    private void groupLoop() {
        try {
            long end = System.currentTimeMillis() + 90000;
            while (tunnel != null && tunnel.url == null && System.currentTimeMillis() < end) Thread.sleep(500);
            if (tunnel == null || tunnel.url == null) {
                toastAndStop("ขอลิงก์ cloudflared ไม่สำเร็จ ลองสร้างใหม่อีกครั้ง");
                return;
            }
            Group.publishHost(gid, gname, tunnel.url, gdev, gclaim);
            Thread.sleep(3000);
            Group.Host w = Group.current(gid);
            if (w != null && !gdev.equals(w.dev)) {
                try { Group.publishStop(gid, gdev, gclaim); } catch (Exception ignored) { }
                gid = null;
                toastAndStop(w.name + " สร้างเซิร์ฟเวอร์ในกลุ่มนี้ไปก่อนแล้ว");
                return;
            }
            while (true) {
                Thread.sleep(Group.BEAT_MS);
                if (tunnel == null || !"ok".equals(tunnel.state)) {
                    try { Group.publishStop(gid, gdev, gclaim); } catch (Exception ignored) { }
                    toastAndStop("การเชื่อมต่ออินเทอร์เน็ตของเซิร์ฟเวอร์หลุด");
                    return;
                }
                try { Group.publishHost(gid, gname, tunnel.url, gdev, gclaim); } catch (Exception ignored) { }
            }
        } catch (InterruptedException ignored) {
        } catch (Exception e) {
            toastAndStop("ประกาศเซิร์ฟเวอร์ให้กลุ่มไม่ได้ (ต้องมีอินเทอร์เน็ต): " + e.getMessage());
        }
    }

    private void toastAndStop(String msg) {
        main.post(() -> {
            Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
            stopSelf();
        });
    }

    @Override
    public void onDestroy() {
        if (gthread != null) gthread.interrupt();
        final String g = gid, d = gdev, c = gclaim;
        if (g != null) {
            Thread t = new Thread(() -> { try { Group.publishStop(g, d, c); } catch (Exception ignored) { } });
            t.start();
            try { t.join(2500); } catch (InterruptedException ignored) { }
        }
        if (tunnel != null) tunnel.stop();
        if (host != null) host.stop();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        instance = null;
        super.onDestroy();
    }
}
