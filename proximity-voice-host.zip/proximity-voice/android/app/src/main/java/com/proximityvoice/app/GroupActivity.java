package com.proximityvoice.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** รายการกลุ่ม (สูงสุด 3) + หน้ากลุ่ม: ชื่อกลุ่ม สมาชิก โฮสต์ และปุ่มเข้าเสียง */
public class GroupActivity extends Activity {
    private static final int BG = Color.parseColor("#161B18"), FG = Color.parseColor("#E8EFE9"),
            MUT = Color.parseColor("#8FA196"), AC = Color.parseColor("#5FBF86"), CARD = Color.parseColor("#1F2622");
    private static String lastAutoClaim = null;
    static boolean visible;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final ExecutorService ex = Executors.newSingleThreadExecutor();
    private final Map<String, Long> lastPresence = new HashMap<>();   // ใช้เฉพาะในเธรด ex
    private LinearLayout box;
    private String viewGid;            // null = หน้ารายการกลุ่ม
    private Group.Snap snap;
    private String netErr;
    private boolean checked, nameDialog;
    private long pausedUntil;       // ntfy จำกัดโควตา: พักการเช็กจนถึงเวลานี้
    private int backoffSec = 30;
    private LinearLayout clientBox;     // การ์ด "คนในห้องเสียงตอนนี้" (เฉพาะตอนเราโฮสต์)
    private final Runnable clientTick = new Runnable() {
        @Override public void run() { fillClients(); h.postDelayed(this, 3000); }
    };

    private final Runnable tick = new Runnable() {
        @Override public void run() { poll(); h.postDelayed(this, 15000); }
    };

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackground(Ui.bg());
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(24), dp(16), dp(40));
        sv.addView(box);
        setContentView(sv);
        String cur = Group.id(this);
        viewGid = (cur != null && !getIntent().getBooleanExtra("list", false)) ? cur : null;
    }

    @Override protected void onResume() {
        super.onResume();
        visible = true;
        h.post(clientTick);
        render();
        if (Group.name(this) == null) askName(false);
        h.post(tick);
    }

    @Override protected void onPause() { visible = false; h.removeCallbacks(tick); h.removeCallbacks(clientTick); super.onPause(); }
    @Override protected void onDestroy() { h.removeCallbacksAndMessages(null); ex.shutdownNow(); super.onDestroy(); }

    @Override
    public void onBackPressed() {
        if (viewGid != null) { viewGid = null; snap = null; render(); }
        else super.onBackPressed();
    }

    // ---------- ดึงสถานะกลุ่ม ----------
    private void poll() {
        final String gid = viewGid;
        if (gid == null || ex.isShutdown()) return;
        if (System.currentTimeMillis() < pausedUntil) {
            netErr = "ntfy จำกัดโควตาชั่วคราว จะลองใหม่เองใน " + ((pausedUntil - System.currentTimeMillis()) / 1000 + 1) + " วินาที";
            checked = true;
            render();
            return;
        }
        ex.submit(() -> {
            long t0 = System.currentTimeMillis();
            Long lp = lastPresence.get(gid);
            if (lp == null || t0 - lp > 270000) {
                try { Group.publishHere(this, gid); lastPresence.put(gid, t0); } catch (IOException ignored) { }
            }
            Group.Snap s = null; String err = null;
            try { s = Group.snapshot(gid, "12h"); backoffSec = 30; }
            catch (Group.RateLimited e) {
                backoffSec = Math.max(e.retryAfterSec, Math.min(300, backoffSec * 2));
                pausedUntil = System.currentTimeMillis() + backoffSec * 1000L;
                err = "ntfy จำกัดโควตาชั่วคราว จะลองใหม่เองใน " + backoffSec + " วินาที";
            }
            catch (IOException e) { err = "เช็กสถานะกลุ่มไม่ได้ (ต้องมีอินเทอร์เน็ต)"; }
            final Group.Snap fs = s; final String ferr = err;
            h.post(() -> {
                if (isFinishing() || !gid.equals(viewGid)) return;
                if (ferr == null) {
                    snap = fs;
                    Group.G g = Group.find(this, gid);
                    // ชื่อกลุ่ม: สมาชิกใช้ชื่อที่เจ้าของตั้ง / เจ้าของใช้ชื่อตัวเองเป็นหลัก
                    if (g != null && !fs.title.isEmpty() && (!g.own || g.title.isEmpty()) && !fs.title.equals(g.title))
                        Group.setTitle(this, gid, fs.title);
                }
                netErr = ferr;
                checked = true;
                render();
                autoJoin();
            });
        });
    }

    private boolean iAmHost() {
        HostService s = HostService.instance;
        return s != null && s.gid != null && s.gid.equals(viewGid);
    }

    private void autoJoin() {
        if (snap == null || snap.host == null || !Group.auto(this) || iAmHost()) return;
        if (snap.host.dev.equals(Group.device(this))) return;
        if (snap.host.claim.equals(lastAutoClaim)) return;
        lastAutoClaim = snap.host.claim;
        join();
    }

    private void join() {
        if (snap == null || snap.host == null) return;
        boolean me = snap.host.dev.equals(Group.device(this)) && iAmHost();
        String url = me ? "http://localhost:" + VoiceHost.VOICE_PORT : snap.host.url;
        getSharedPreferences("pv", MODE_PRIVATE).edit().putString("url", url).putString("jgid", viewGid).apply();
        startActivity(new Intent(this, MainActivity.class).putExtra("join", true)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
    }

    // ---------- สร้างเซิร์ฟเวอร์ (มีได้คนเดียวต่อกลุ่ม) ----------
    private void toggleHost() {
        final String gid = viewGid;
        if (iAmHost()) {
            stopService(new Intent(this, HostService.class));
            if (snap != null) snap.host = null;
            h.postDelayed(this::poll, 1500);
            clientBox = null;
            render();
            return;
        }
        if (HostService.instance != null) {
            Toast.makeText(this, HostService.instance.gid != null
                    ? "คุณกำลังโฮสต์ของอีกกลุ่มอยู่ หยุดก่อนถึงจะสร้างกลุ่มนี้ได้"
                    : "มีเซิร์ฟเวอร์แบบแมนนวลรันอยู่ ปิดที่ ⚙ > สร้างเซิร์ฟเวอร์ก่อน", Toast.LENGTH_LONG).show();
            return;
        }
        if (ex.isShutdown()) return;
        Toast.makeText(this, "กำลังเช็กกลุ่ม...", Toast.LENGTH_SHORT).show();
        ex.submit(() -> {
            try {
                Group.Host w = Group.current(gid);
                if (w != null && !w.dev.equals(Group.device(this))) {
                    h.post(() -> {
                        poll();
                        Toast.makeText(this, w.name + " สร้างเซิร์ฟเวอร์ในกลุ่มนี้อยู่แล้ว สร้างซ้ำไม่ได้", Toast.LENGTH_LONG).show();
                    });
                    return;
                }
                h.post(this::startHost);
            } catch (IOException e) {
                h.post(() -> Toast.makeText(this, "เช็กกลุ่มไม่ได้ ต้องมีอินเทอร์เน็ต", Toast.LENGTH_LONG).show());
            }
        });
    }

    private void startHost() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 22);
        try {
            startForegroundService(new Intent(this, HostService.class)
                    .putExtra("tunnel", true)
                    .putExtra("gid", viewGid)
                    .putExtra("gname", Group.name(this))
                    .putExtra("gdev", Group.device(this)));
            Toast.makeText(this, "กำลังสร้างเซิร์ฟเวอร์ รอสักครู่...", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "เริ่มบริการไม่ได้: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        h.postDelayed(this::render, 500);
        h.postDelayed(this::poll, 8000);
    }

    // ---------- กล่องโต้ตอบ ----------
    private EditText input(String hint, int max, String preset) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setSingleLine();
        et.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max)});
        if (preset != null) et.setText(preset);
        return et;
    }

    private void askName(boolean cancelable) {
        if (nameDialog) return;
        nameDialog = true;
        EditText et = input("ชื่อของคุณ เช่น Steve", 20, Group.name(this));
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("ตั้งชื่อของคุณ")
                .setMessage("เพื่อนในกลุ่มจะเห็นชื่อนี้ในรายชื่อสมาชิก และถ้ายังไม่เคยตั้ง จะใช้เป็นชื่อในเกมด้วย (เปลี่ยนได้ที่ ตั้งค่า > ชื่อในเกม)")
                .setView(et)
                .setCancelable(cancelable)
                .setPositiveButton("ตกลง", (d, w) -> {
                    String n = et.getText().toString().trim();
                    Group.setName(this, n.isEmpty() ? "Player" : n);
                    android.content.SharedPreferences gp = getSharedPreferences("pv", MODE_PRIVATE);
                    if (!n.isEmpty() && gp.getString("ingame", "").isEmpty()) gp.edit().putString("ingame", n).apply();
                    lastPresence.clear();
                    render();
                    poll();
                })
                .setOnDismissListener(d -> nameDialog = false);
        if (cancelable) b.setNegativeButton("ยกเลิก", null);
        b.show();
    }

    private void createGroup() {
        if (Group.name(this) == null) { askName(false); return; }
        if (Group.list(this).size() >= Group.MAX) {
            Toast.makeText(this, "มีกลุ่มครบ " + Group.MAX + " กลุ่มแล้ว ออกจากกลุ่มเดิมก่อน", Toast.LENGTH_LONG).show();
            return;
        }
        EditText et = input("เช่น ก๊วนมายคราฟ", 24, "กลุ่มของ " + Group.name(this));
        new AlertDialog.Builder(this)
                .setTitle("ตั้งชื่อกลุ่ม")
                .setView(et)
                .setPositiveButton("สร้างกลุ่ม", (d, w) -> {
                    String t = et.getText().toString().trim();
                    String id = Group.newId();
                    Group.add(this, id, t.isEmpty() ? "กลุ่ม " + id : t, true);
                    openGroup(id);
                })
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    private void askJoinGroup() {
        if (Group.name(this) == null) { askName(false); return; }
        if (Group.list(this).size() >= Group.MAX) {
            Toast.makeText(this, "มีกลุ่มครบ " + Group.MAX + " กลุ่มแล้ว ออกจากกลุ่มเดิมก่อน", Toast.LENGTH_LONG).show();
            return;
        }
        EditText et = input("ไอดีกลุ่ม 6 ตัว เช่น K7M2QX", 6, null);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        new AlertDialog.Builder(this)
                .setTitle("เข้าร่วมกลุ่ม")
                .setView(et)
                .setPositiveButton("เข้าร่วม", (d, w) -> {
                    String id = Group.normalize(et.getText().toString());
                    if (!Group.valid(id)) {
                        Toast.makeText(this, "ไอดีไม่ถูกต้อง ต้องเป็นตัวอักษร/ตัวเลข 6 ตัว", Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (!Group.add(this, id, "", false)) return;
                    openGroup(id);
                })
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    private void renameGroup() {
        Group.G g = Group.find(this, viewGid);
        if (g == null || !g.own) return;
        EditText et = input("ชื่อกลุ่ม", 24, g.title);
        new AlertDialog.Builder(this)
                .setTitle("เปลี่ยนชื่อกลุ่ม")
                .setView(et)
                .setPositiveButton("บันทึก", (d, w) -> {
                    String t = et.getText().toString().trim();
                    if (t.isEmpty()) return;
                    Group.setTitle(this, g.id, t);
                    lastPresence.remove(g.id);   // ประกาศชื่อใหม่ให้สมาชิกทันที
                    render();
                    poll();
                })
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    private void openGroup(String id) {
        if (getSharedPreferences("pv", MODE_PRIVATE).getBoolean("notifyGroup", false)) {
            try { startForegroundService(new Intent(this, GroupWatchService.class)); } catch (Exception ignored) { }
        }
        viewGid = id;
        Group.setCurrent(this, id);
        snap = null; netErr = null; checked = false;
        render();
        poll();
    }

    private void leaveGroup() {
        final String gid = viewGid;
        new AlertDialog.Builder(this)
                .setMessage("ออกจากกลุ่มนี้? (ถ้าคุณโฮสต์อยู่ เซิร์ฟเวอร์จะถูกปิดด้วย)")
                .setPositiveButton("ออก", (d, w) -> {
                    if (iAmHost()) stopService(new Intent(this, HostService.class));
                    final android.content.Context app = getApplicationContext();
                    new Thread(() -> { try { Group.publishLeave(app, gid); } catch (Exception ignored) { } }).start();
                    Group.remove(this, gid);
                    if (!Group.any(this))
                        getSharedPreferences("pv", MODE_PRIVATE).edit().remove("url").apply();
                    viewGid = null; snap = null;
                    render();
                })
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    // ---------- หน้าจอ ----------
    private void render() {
        box.removeAllViews();
        if (viewGid == null) renderList(); else renderGroup();
    }

    private void nameLine() {
        String name = Group.name(this);
        TextView who = text("ชื่อของคุณ: " + (name == null ? "-" : name) + "   (แตะเพื่อเปลี่ยน)", 13, MUT, false);
        who.setOnClickListener(v -> askName(true));
        who.setPadding(dp(4), dp(4), 0, dp(12));
    }

    private boolean hasMic() { return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED; }

    @Override
    public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        super.onRequestPermissionsResult(c, p, r);
        render();
    }

    private void renderList() {
        header("กลุ่มเสียง");
        nameLine();
        List<Group.G> gs = Group.list(this);
        if (gs.isEmpty()) { renderWelcome(); return; }
        text("กลุ่มของคุณ " + gs.size() + "/" + Group.MAX, 13, MUT, false).setPadding(dp(4), 0, 0, dp(2));
        for (Group.G g : gs) {
            LinearLayout c = new LinearLayout(this);
            c.setGravity(Gravity.CENTER_VERTICAL);
            c.setPadding(dp(14), dp(14), dp(14), dp(14));
            c.setBackground(Ui.card(this));
            c.setOnClickListener(v -> openGroup(g.id));
            c.addView(Ui.avatar(this, g.label(), dp(48)), new LinearLayout.LayoutParams(dp(48), dp(48)));
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(14), 0, 0, 0);
            TextView t = new TextView(this);
            t.setText(g.label()); t.setTextColor(FG); t.setTextSize(17); t.setTypeface(null, Typeface.BOLD);
            col.addView(t);
            TextView i = new TextView(this);
            i.setText("ไอดี " + g.id + (g.own ? "  ·  ★ คุณเป็นเจ้าของ" : ""));
            i.setTextColor(MUT); i.setTextSize(12);
            col.addView(i);
            c.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
            TextView ch = new TextView(this);
            ch.setText("›"); ch.setTextSize(26); ch.setTextColor(MUT);
            c.addView(ch);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, dp(8), 0, 0);
            box.addView(c, lp);
        }
        button("สร้างกลุ่มใหม่", true, this::createGroup);
        button("เข้าร่วมกลุ่ม (ใส่ไอดี)", false, this::askJoinGroup);
        if (gs.size() >= Group.MAX)
            text("ครบ " + Group.MAX + " กลุ่มแล้ว ถ้าจะสร้างหรือเข้าเพิ่ม ต้องออกจากกลุ่มเดิมก่อน", 12, MUT, false).setPadding(dp(4), dp(6), 0, 0);
        footer();
    }

    private void footer() {
        button("ใส่ลิงก์เซิร์ฟเวอร์เอง (ไม่ใช้กลุ่ม)", false, () ->
                startActivity(new Intent(this, MainActivity.class).putExtra("ask", true)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)));
        text("สถานะกลุ่มส่งผ่านบริการสาธารณะ ntfy.sh ใครรู้ไอดีก็เข้าได้ อย่าแชร์ให้คนที่ไม่ไว้ใจ", 12, MUT, false).setPadding(dp(4), dp(16), 0, 0);
    }

    /** หน้าต้อนรับ + ขั้นตอนเริ่มต้นสำหรับคนที่ยังไม่มีกลุ่ม */
    private void renderWelcome() {
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(22), dp(24), dp(22), dp(22));
        hero.setBackground(Ui.hero(this));
        TextView em = new TextView(this);
        em.setText("\uD83C\uDFA7"); em.setTextSize(44);
        hero.addView(em);
        TextView t = new TextView(this);
        t.setText("คุยตามระยะในเกม\nกับเพื่อนๆ"); t.setTextColor(Color.WHITE); t.setTextSize(24); t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, dp(6), 0, dp(6));
        hero.addView(t);
        TextView sub = new TextView(this);
        sub.setText("ตั้งค่าครั้งเดียว 3 ขั้นตอน แล้วเพื่อนในกลุ่มเข้าเสียงได้ทุกครั้งโดยไม่ต้องส่งลิงก์"); sub.setTextColor(0xCCFFFFFF); sub.setTextSize(14);
        hero.addView(sub);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.setMargins(0, dp(8), 0, dp(12));
        box.addView(hero, hp);

        boolean named = Group.name(this) != null, mic = hasMic();
        LinearLayout steps = new LinearLayout(this);
        steps.setOrientation(LinearLayout.VERTICAL);
        steps.setPadding(dp(14), dp(6), dp(14), dp(6));
        steps.setBackground(Ui.card(this));
        step(steps, 1, "ตั้งชื่อของคุณ", named, () -> askName(true));
        step(steps, 2, "อนุญาตให้ใช้ไมค์", mic, () -> requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 30));
        step(steps, 3, "สร้างหรือเข้าร่วมกลุ่ม", false, null);
        box.addView(steps, new LinearLayout.LayoutParams(-1, -2));

        button("สร้างกลุ่ม", true, this::createGroup);
        button("เข้าร่วมกลุ่ม (ใส่ไอดีจากเพื่อน)", false, this::askJoinGroup);
        footer();
    }

    private void step(LinearLayout parent, int n, String label, boolean done, Runnable tap) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(10), 0, dp(10));
        TextView c = new TextView(this);
        c.setText(done ? "✓" : String.valueOf(n));
        c.setGravity(Gravity.CENTER); c.setTextSize(14); c.setTypeface(null, Typeface.BOLD);
        c.setTextColor(done ? Color.WHITE : MUT);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(done ? Ui.AC_DARK : Ui.LINE);
        c.setBackground(g);
        r.addView(c, new LinearLayout.LayoutParams(dp(30), dp(30)));
        TextView t = new TextView(this);
        t.setText(label); t.setTextSize(15); t.setTextColor(done ? MUT : FG);
        t.setPadding(dp(12), 0, 0, 0);
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        if (!done && tap != null) {
            TextView go = Ui.pill(this, "ทำเลย", Ui.AC_DARK, Color.WHITE);
            r.addView(go);
            r.setOnClickListener(v -> tap.run());
        }
        parent.addView(r, new LinearLayout.LayoutParams(-1, -2));
    }

    private String ago(long ms) {
        long m = ms / 60000;
        if (m < 1) return "เมื่อครู่";
        if (m < 60) return m + " นาทีที่แล้ว";
        return (m / 60) + " ชม.ที่แล้ว";
    }

    private void renderGroup() {
        final String gid = viewGid;
        final Group.G g = Group.find(this, gid);
        if (g == null) { viewGid = null; renderList(); return; }
        final String me = Group.device(this);

        header("กลุ่ม");

        HostService hs = HostService.instance;
        boolean mine = hs != null && hs.gid != null && hs.gid.equals(gid);
        Group.Host host = snap == null ? null : snap.host;
        boolean other = host != null && !host.dev.equals(me);

        // ---------- การ์ดหลัก ----------
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(20), dp(18), dp(20), dp(18));
        hero.setBackground(Ui.hero(this));
        TextView tag = Ui.pill(this, g.own ? "★ กลุ่มของคุณ" : "กลุ่มที่เข้าร่วม", 0x33FFFFFF, Color.WHITE);
        hero.addView(tag);
        TextView title = new TextView(this);
        title.setText(g.label() + (g.own ? "  ✎" : ""));
        title.setTextColor(Color.WHITE); title.setTextSize(26); title.setTypeface(null, Typeface.BOLD);
        title.setPadding(0, dp(8), 0, dp(10));
        if (g.own) title.setOnClickListener(v -> renameGroup());
        hero.addView(title);

        LinearLayout idRow = new LinearLayout(this);
        idRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView idv = new TextView(this);
        idv.setText(gid);
        idv.setTextColor(Color.WHITE); idv.setTextSize(20);
        idv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        idv.setLetterSpacing(0.18f);
        idv.setPadding(dp(14), dp(7), dp(14), dp(7));
        idv.setBackground(Ui.round(0x33000000, dp(14)));
        idv.setOnClickListener(v -> {
            ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("gid", gid));
            Toast.makeText(this, "คัดลอกไอดีแล้ว", Toast.LENGTH_SHORT).show();
        });
        idRow.addView(idv);
        TextView share = Ui.pill(this, "แชร์ ↗", 0x33FFFFFF, Color.WHITE);
        share.setTextSize(13);
        share.setPadding(dp(14), dp(8), dp(14), dp(8));
        share.setOnClickListener(v -> startActivity(Intent.createChooser(
                new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,
                        "เข้ากลุ่ม \"" + g.label() + "\" ในเกม 🎧\nเปิดแอป Proximity Voice > เข้าร่วมกลุ่ม แล้วใส่ไอดี: " + gid), "แชร์ไอดีกลุ่ม")));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-2, -2);
        slp.setMargins(dp(10), 0, 0, 0);
        idRow.addView(share, slp);
        hero.addView(idRow);

        // รูปสมาชิกซ้อนกัน
        if (snap != null && !snap.members.isEmpty()) {
            LinearLayout av = new LinearLayout(this);
            av.setGravity(Gravity.CENTER_VERTICAL);
            av.setPadding(0, dp(14), 0, 0);
            int shown = Math.min(5, snap.members.size());
            for (int i = 0; i < shown; i++) {
                Group.Member m = snap.members.get(i);
                LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(dp(34), dp(34));
                if (i > 0) ap.setMargins(-dp(8), 0, 0, 0);
                av.addView(Ui.avatar(this, m.name, dp(34)), ap);
            }
            TextView cnt = new TextView(this);
            cnt.setText(snap.members.size() + " คนในกลุ่ม");
            cnt.setTextColor(0xCCFFFFFF); cnt.setTextSize(13);
            cnt.setPadding(dp(10), 0, 0, 0);
            av.addView(cnt);
            hero.addView(av);
        }

        // สถานะ
        String st; int dot;
        if (netErr != null && !mine) { st = netErr; dot = Ui.WARN; }
        else if (!checked && !mine) { st = "กำลังเช็กสถานะกลุ่ม..."; dot = 0x99FFFFFF; }
        else if (mine) { st = "คุณกำลังโฮสต์" + (hs.tunnel != null && hs.tunnel.url == null ? " (กำลังขอลิงก์...)" : ""); dot = 0xFF9BF0BE; }
        else if (host == null) { st = "ยังไม่มีใครสร้างเซิร์ฟเวอร์เสียง"; dot = 0x99FFFFFF; }
        else { st = host.name + " กำลังโฮสต์อยู่"; dot = 0xFF9BF0BE; }
        TextView stv = new TextView(this);
        stv.setText("●  " + st);
        stv.setTextColor(0xFFFFFFFF); stv.setTextSize(14);
        stv.setPadding(0, dp(16), 0, dp(12));
        android.text.SpannableString sp = new android.text.SpannableString(stv.getText());
        sp.setSpan(new android.text.style.ForegroundColorSpan(dot), 0, 1, 0);
        stv.setText(sp);
        hero.addView(stv);

        // ปุ่มหลักปุ่มเดียวตามสถานการณ์
        String pText; Runnable pAct; boolean pEn = true;
        if (mine && host == null) { pText = "กำลังประกาศให้กลุ่มรู้..."; pAct = null; pEn = false; }
        else if (mine) { pText = "🎧  เข้าร่วมเสียงเอง"; pAct = this::join; }
        else if (other) { pText = "🎧  เข้าเสียงของ " + host.name; pAct = this::join; }
        else if (netErr != null) { pText = "ลองใหม่"; pAct = this::poll; }
        else if (!checked) { pText = "กำลังเช็ก..."; pAct = null; pEn = false; }
        else { pText = "🖥  สร้างเซิร์ฟเวอร์เสียง"; pAct = this::toggleHost; }
        Button pb = new Button(this);
        pb.setText(pText);
        pb.setAllCaps(false);
        pb.setTextSize(16);
        pb.setTypeface(null, Typeface.BOLD);
        pb.setTextColor(pEn ? Ui.AC_DARK : 0x99FFFFFF);
        pb.setBackground(Ui.round(pEn ? Color.WHITE : 0x33FFFFFF, dp(16)));
        pb.setStateListAnimator(null);
        pb.setEnabled(pEn);
        if (pAct != null) { final Runnable act = pAct; pb.setOnClickListener(v -> act.run()); }
        hero.addView(pb, new LinearLayout.LayoutParams(-1, dp(54)));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.setMargins(0, dp(4), 0, 0);
        box.addView(hero, hp);

        if (mine)
            text("ในเกม (โลกที่เปิด cheats) พิมพ์:  /wsserver localhost:3001\nแล้วรหัส 4 หลักจะขึ้นที่แถบด้านบนจอ", 12, MUT, false).setPadding(dp(4), dp(10), 0, 0);

        clientBox = null;
        if (mine && hs.host != null) {
            clientBox = new LinearLayout(this);
            clientBox.setOrientation(LinearLayout.VERTICAL);
            clientBox.setPadding(dp(14), dp(10), dp(14), dp(10));
            clientBox.setBackground(Ui.card(this));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
            cp.setMargins(0, dp(14), 0, 0);
            box.addView(clientBox, cp);
            fillClients();
        }

        // ---------- สมาชิก ----------
        int n = snap == null ? 0 : snap.members.size();
        text("สมาชิก" + (snap == null ? "" : " (" + n + ")"), 13, Ui.AC, true).setPadding(dp(4), dp(22), 0, dp(8));
        LinearLayout mc = new LinearLayout(this);
        mc.setOrientation(LinearLayout.VERTICAL);
        mc.setPadding(dp(14), dp(6), dp(14), dp(6));
        mc.setBackground(Ui.card(this));
        if (snap == null || snap.members.isEmpty()) {
            TextView e = new TextView(this);
            e.setText(netErr != null ? "โหลดรายชื่อไม่ได้" : checked ? "ยังไม่มีใครส่งสัญญาณ (เปิดหน้านี้ค้างไว้สักครู่)" : "กำลังโหลด...");
            e.setTextColor(MUT); e.setTextSize(14);
            e.setPadding(0, dp(10), 0, dp(10));
            mc.addView(e);
        } else {
            for (Group.Member m : snap.members) {
                boolean isHost = host != null && host.dev.equals(m.dev);
                boolean online = snap.now - m.seen <= Group.ACTIVE_MS;
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, dp(8), 0, dp(8));
                row.addView(Ui.avatar(this, m.name, dp(40)), new LinearLayout.LayoutParams(dp(40), dp(40)));
                TextView nm = new TextView(this);
                nm.setText((m.name == null || m.name.isEmpty() ? "Player" : m.name) + (m.dev.equals(me) ? " (คุณ)" : ""));
                nm.setTextColor(FG); nm.setTextSize(15);
                nm.setPadding(dp(12), 0, 0, 0);
                row.addView(nm, new LinearLayout.LayoutParams(0, -2, 1f));
                row.addView(isHost ? Ui.pill(this, "🎙 โฮสต์", 0x332F7D4F, Ui.AC)
                        : online ? Ui.pill(this, "ออนไลน์", 0x332F7D4F, Ui.AC)
                        : Ui.pill(this, ago(snap.now - m.seen), Ui.LINE, MUT));
                mc.addView(row);
            }
        }
        box.addView(mc, new LinearLayout.LayoutParams(-1, -2));
        text("สถานะ \"ออนไลน์\" นับจากตอนที่เปิดหน้านี้ล่าสุด ไม่ใช่ว่ากำลังคุยอยู่", 11, MUT, false).setPadding(dp(4), dp(6), 0, 0);

        // ---------- ตัวเลือก ----------
        text("ตัวเลือก", 13, Ui.AC, true).setPadding(dp(4), dp(20), 0, dp(8));
        LinearLayout oc = new LinearLayout(this);
        oc.setOrientation(LinearLayout.VERTICAL);
        oc.setBackground(Ui.card(this));
        Switch sw = new Switch(this);
        sw.setText("เข้าเสียงอัตโนมัติเมื่อมีคนในกลุ่มสร้างเซิร์ฟเวอร์");
        sw.setTextColor(FG);
        Ui.tint(sw);
        sw.setChecked(Group.auto(this));
        sw.setOnCheckedChangeListener((v, on) -> Group.setAuto(this, on));
        sw.setPadding(dp(16), dp(14), dp(16), dp(14));
        oc.addView(sw, new LinearLayout.LayoutParams(-1, -2));
        if (mine) {
            Switch rq = new Switch(this);
            rq.setText("บังคับใช้รหัส 4 หลัก (ไม่ให้เข้าด้วยชื่อในเกม)");
            rq.setTextColor(FG);
            Ui.tint(rq);
            rq.setChecked(getSharedPreferences("pv", MODE_PRIVATE).getBoolean("reqcode", false));
            rq.setOnCheckedChangeListener((v, on) -> {
                getSharedPreferences("pv", MODE_PRIVATE).edit().putBoolean("reqcode", on).apply();
                HostService s2 = HostService.instance;
                if (s2 != null && s2.host != null) s2.host.setRequireCode(on);
            });
            rq.setPadding(dp(16), dp(14), dp(16), dp(14));
            oc.addView(rq, new LinearLayout.LayoutParams(-1, -2));
            option(oc, "🛑", "หยุดเซิร์ฟเวอร์ของฉัน", Ui.WARN, this::toggleHost);
        }
        option(oc, "🩺", "ตรวจระบบ (ทำไมไม่ได้ยิน?)", FG, () -> startActivity(new Intent(this, DiagnosticsActivity.class)));
        if (g.own) option(oc, "✎", "เปลี่ยนชื่อกลุ่ม", FG, this::renameGroup);
        option(oc, "🚪", "ออกจากกลุ่ม", Ui.DANGER, this::leaveGroup);
        box.addView(oc, new LinearLayout.LayoutParams(-1, -2));
    }

    /** รายชื่อคนในห้องเสียงตอนนี้ + ปุ่มปิดเสียง/เตะ (เฉพาะโฮสต์) */
    private void fillClients() {
        HostService hs = HostService.instance;
        if (clientBox == null || hs == null || hs.host == null || isFinishing()) return;
        final VoiceHost vh = hs.host;
        clientBox.removeAllViews();
        List<VoiceHost.Info> infos = vh.clientInfos();
        TextView hd = new TextView(this);
        hd.setText("คนในห้องเสียงตอนนี้ (" + infos.size() + ")  ·  เกม: " + (vh.gameConnected() ? "ต่ออยู่ ✓" : "ยังไม่ต่อ"));
        hd.setTextColor(FG); hd.setTextSize(14); hd.setTypeface(null, Typeface.BOLD);
        hd.setPadding(0, dp(4), 0, dp(6));
        clientBox.addView(hd);
        if (infos.isEmpty()) {
            TextView e = new TextView(this);
            e.setText("ยังไม่มีใครเข้าห้องเสียง");
            e.setTextColor(MUT); e.setTextSize(13);
            clientBox.addView(e);
        }
        for (VoiceHost.Info i : infos) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(6), 0, dp(6));
            row.addView(Ui.avatar(this, i.name, dp(36)), new LinearLayout.LayoutParams(dp(36), dp(36)));
            TextView nm = new TextView(this);
            nm.setText(i.name + (i.mode == 1 ? " 📢" : i.mode == 2 ? " 🤫" : ""));
            nm.setTextColor(i.muted ? MUT : FG); nm.setTextSize(15);
            nm.setPadding(dp(10), 0, 0, 0);
            row.addView(nm, new LinearLayout.LayoutParams(0, -2, 1f));
            TextView mute = Ui.pill(this, i.muted ? "🔇 ปิดเสียงอยู่" : "ปิดเสียง", i.muted ? Ui.WARN : Ui.LINE, i.muted ? Color.BLACK : FG);
            mute.setOnClickListener(v -> { vh.setHostMuted(i.id, !i.muted); fillClients(); });
            TextView kick = Ui.pill(this, "เตะ", 0x44F0716F, Ui.DANGER);
            kick.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setMessage("เตะ " + i.name + " ออกจากห้องเสียง? (เข้าใหม่ไม่ได้จนกว่าจะปิด-สร้างเซิร์ฟเวอร์ใหม่)")
                    .setPositiveButton("เตะ", (d, w) -> { vh.kick(i.id); fillClients(); })
                    .setNegativeButton("ยกเลิก", null).show());
            LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(-2, -2);
            kp.setMargins(dp(6), 0, 0, 0);
            row.addView(kick, kp);
            row.addView(mute, row.getChildCount() - 1, new LinearLayout.LayoutParams(-2, -2));
            clientBox.addView(row);
        }
    }

    private void option(LinearLayout parent, String icon, String label, int color, Runnable tap) {
        View d = new View(this);
        d.setBackgroundColor(Ui.LINE);
        parent.addView(d, new LinearLayout.LayoutParams(-1, 1));
        TextView t = new TextView(this);
        t.setText(icon + "   " + label);
        t.setTextColor(color); t.setTextSize(15);
        t.setPadding(dp(16), dp(15), dp(16), dp(15));
        t.setOnClickListener(v -> tap.run());
        parent.addView(t, new LinearLayout.LayoutParams(-1, -2));
    }

    /** หัวหน้า: ปุ่มย้อนกลับกลมที่ซ้ายบน + ชื่อหน้า */
    private TextView header(String t) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = new TextView(this);
        back.setText("\u2039");
        back.setTextSize(30);
        back.setTextColor(Color.parseColor("#E8EFE9"));
        back.setGravity(Gravity.CENTER);
        back.setPadding(0, 0, 0, dp(3));
        GradientDrawable bb = new GradientDrawable();
        bb.setShape(GradientDrawable.OVAL);
        bb.setColor(Color.parseColor("#2A352F"));
        back.setBackground(bb);
        back.setContentDescription("ย้อนกลับ");
        back.setOnClickListener(v -> onBackPressed());
        r.addView(back, new LinearLayout.LayoutParams(dp(42), dp(42)));
        TextView title = new TextView(this);
        title.setText(t);
        title.setTextSize(22);
        title.setTextColor(Color.parseColor("#E8EFE9"));
        title.setTypeface(null, Typeface.BOLD);
        title.setPadding(dp(12), 0, 0, 0);
        r.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        box.addView(r, lp);
        return title;
    }

    // ---------- ตัวช่วย UI ----------
    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(radiusDp));
        g.setColor(color);
        return g;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setBackground(round(CARD, 16));
        box.addView(c, new LinearLayout.LayoutParams(-1, -2));
        return c;
    }

    private TextView text(String t, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(size); v.setTextColor(color);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        box.addView(v);
        return v;
    }

    private Button button(String t, boolean primary, Runnable r) {
        Button bt = new Button(this);
        bt.setText(t);
        bt.setAllCaps(false);
        bt.setTextColor(Color.WHITE);
        bt.setTextSize(15);
        bt.setPadding(dp(16), dp(14), dp(16), dp(14));
        bt.setBackground(round(primary ? Color.parseColor("#2F7D4F") : Color.parseColor("#2A352F"), 14));
        bt.setStateListAnimator(null);
        bt.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(8), 0, 0);
        box.addView(bt, lp);
        return bt;
    }
}
