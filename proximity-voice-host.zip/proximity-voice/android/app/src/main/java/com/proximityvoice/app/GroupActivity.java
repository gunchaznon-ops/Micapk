package com.proximityvoice.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputFilter;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** หน้าหลักของกลุ่ม: ตั้งชื่อ สร้าง/เข้าร่วมกลุ่ม ดูว่าใครโฮสต์ และเข้าเสียง */
public class GroupActivity extends Activity {
    private static final int BG = Color.parseColor("#161B18"), FG = Color.parseColor("#E8EFE9"),
            MUT = Color.parseColor("#8FA196"), AC = Color.parseColor("#5FBF86"), CARD = Color.parseColor("#1F2622");
    private static String lastAutoClaim = null;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final ExecutorService ex = Executors.newSingleThreadExecutor();
    private LinearLayout box;
    private Group.Host host;      // โฮสต์ปัจจุบันของกลุ่ม (null = ไม่มี)
    private String netErr;
    private boolean checked;      // เช็กสถานะรอบแรกเสร็จหรือยัง
    private boolean nameDialog;

    private final Runnable tick = new Runnable() {
        @Override public void run() { poll(); h.postDelayed(this, 15000); }
    };

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(24), dp(16), dp(40));
        sv.addView(box);
        setContentView(sv);
    }

    @Override protected void onResume() {
        super.onResume();
        render();
        if (Group.name(this) == null) askName(false);
        h.post(tick);
    }

    @Override protected void onPause() { h.removeCallbacks(tick); super.onPause(); }
    @Override protected void onDestroy() { ex.shutdownNow(); super.onDestroy(); }

    // ---------- ดึงสถานะกลุ่ม ----------
    private void poll() {
        final String gid = Group.id(this);
        if (gid == null) return;
        ex.submit(() -> {
            Group.Host w = null; String err = null;
            try { w = Group.current(gid); } catch (IOException e) { err = "เช็กสถานะกลุ่มไม่ได้ (ต้องมีอินเทอร์เน็ต)"; }
            final Group.Host fw = w; final String ferr = err;
            h.post(() -> {
                if (isFinishing()) return;
                if (ferr == null) host = fw;
                netErr = ferr;
                checked = true;
                render();
                autoJoin();
            });
        });
    }

    private boolean iAmHost() {
        HostService s = HostService.instance;
        return s != null && s.gid != null && s.gid.equals(Group.id(this));
    }

    /** มีโฮสต์ใหม่ในกลุ่ม + เปิดโหมดเข้าอัตโนมัติ → เข้าเสียงให้เลย (ครั้งเดียวต่อเซิร์ฟเวอร์) */
    private void autoJoin() {
        if (host == null || !Group.auto(this) || iAmHost()) return;
        if (host.dev.equals(Group.device(this))) return;
        if (host.claim.equals(lastAutoClaim)) return;
        lastAutoClaim = host.claim;
        join();
    }

    private void join() {
        if (host == null) return;
        boolean me = host.dev.equals(Group.device(this)) && iAmHost();
        String url = me ? "http://localhost:" + VoiceHost.VOICE_PORT : host.url;
        getSharedPreferences("pv", MODE_PRIVATE).edit().putString("url", url).apply();
        startActivity(new Intent(this, MainActivity.class).putExtra("join", true)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
    }

    // ---------- สร้างเซิร์ฟเวอร์ (ล็อกให้มีได้คนเดียวต่อกลุ่ม) ----------
    private void toggleHost() {
        if (iAmHost()) {
            stopService(new Intent(this, HostService.class));
            host = null;
            h.postDelayed(this::poll, 1500);
            render();
            return;
        }
        if (HostService.instance != null) {
            Toast.makeText(this, "มีเซิร์ฟเวอร์แบบแมนนวลรันอยู่ ปิดที่ ⚙ > สร้างเซิร์ฟเวอร์ก่อน", Toast.LENGTH_LONG).show();
            return;
        }
        final String gid = Group.id(this);
        Toast.makeText(this, "กำลังเช็กกลุ่ม...", Toast.LENGTH_SHORT).show();
        ex.submit(() -> {
            try {
                Group.Host w = Group.current(gid);
                if (w != null && !w.dev.equals(Group.device(this))) {
                    h.post(() -> { host = w; render();
                        Toast.makeText(this, w.name + " สร้างเซิร์ฟเวอร์ในกลุ่มนี้อยู่แล้ว สร้างซ้ำไม่ได้", Toast.LENGTH_LONG).show(); });
                    return;
                }
                h.post(this::startHost);
            } catch (IOException e) {
                h.post(() -> Toast.makeText(this, "เช็กกลุ่มไม่ได้ ต้องมีอินเทอร์เน็ต", Toast.LENGTH_LONG).show());
            }
        });
    }

    private void startHost() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 22);
        try {
            startForegroundService(new Intent(this, HostService.class)
                    .putExtra("tunnel", true)
                    .putExtra("gid", Group.id(this))
                    .putExtra("gname", Group.name(this))
                    .putExtra("gdev", Group.device(this)));
            Toast.makeText(this, "กำลังสร้างเซิร์ฟเวอร์ รอสักครู่...", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "เริ่มบริการไม่ได้: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        h.postDelayed(this::render, 500);
        h.postDelayed(this::poll, 8000);
    }

    // ---------- หน้าจอ ----------
    private void askName(boolean cancelable) {
        if (nameDialog) return;
        nameDialog = true;
        EditText et = new EditText(this);
        et.setHint("ชื่อของคุณ เช่น Steve");
        et.setSingleLine();
        et.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});
        String cur = Group.name(this);
        if (cur != null) et.setText(cur);
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("ตั้งชื่อของคุณ")
                .setMessage("ชื่อนี้เพื่อนในกลุ่มจะเห็นตอนคุณสร้างเซิร์ฟเวอร์")
                .setView(et)
                .setCancelable(cancelable)
                .setPositiveButton("ตกลง", (d, w) -> {
                    nameDialog = false;
                    String n = et.getText().toString().trim();
                    Group.setName(this, n.isEmpty() ? "Player" : n);
                    render();
                })
                .setOnDismissListener(d -> nameDialog = false);
        if (cancelable) b.setNegativeButton("ยกเลิก", null);
        b.show();
    }

    private void askJoinGroup() {
        EditText et = new EditText(this);
        et.setHint("ไอดีกลุ่ม 6 ตัว เช่น K7M2QX");
        et.setSingleLine();
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        new AlertDialog.Builder(this)
                .setTitle("เข้าร่วมกลุ่ม")
                .setView(et)
                .setPositiveButton("เข้าร่วม", (d, w) -> {
                    String id = Group.normalize(et.getText().toString());
                    if (!Group.valid(id)) {
                        Toast.makeText(this, "ไอดีไม่ถูกต้อง ต้องเป็นตัวอักษร/ตัวเลข 6 ตัว", Toast.LENGTH_LONG).show();
                        return;
                    }
                    enterGroup(id);
                })
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    private void enterGroup(String id) {
        Group.setId(this, id);
        host = null; netErr = null; checked = false; lastAutoClaim = null;
        render();
        poll();
    }

    private void leaveGroup() {
        new AlertDialog.Builder(this)
                .setMessage("ออกจากกลุ่มนี้? (ถ้าคุณโฮสต์อยู่ เซิร์ฟเวอร์จะถูกปิดด้วย)")
                .setPositiveButton("ออก", (d, w) -> {
                    if (iAmHost()) stopService(new Intent(this, HostService.class));
                    Group.setId(this, null);
                    getSharedPreferences("pv", MODE_PRIVATE).edit().remove("url").apply();
                    host = null;
                    render();
                })
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    private void render() {
        box.removeAllViews();
        text("กลุ่มเสียง", 26, FG, true);
        String name = Group.name(this);
        TextView who = text("ชื่อของคุณ: " + (name == null ? "-" : name) + "   (แตะเพื่อเปลี่ยน)", 13, MUT, false);
        who.setOnClickListener(v -> askName(true));
        who.setPadding(0, dp(4), 0, dp(12));

        final String gid = Group.id(this);
        if (gid == null) {
            text("สร้างกลุ่มใหม่แล้วส่งไอดีให้เพื่อน หรือใส่ไอดีกลุ่มของเพื่อนเพื่อเข้าร่วม ทุกคนในกลุ่มจะเข้าเสียงของกลุ่มได้อัตโนมัติ และมีคนสร้างเซิร์ฟเวอร์ได้ทีละคน", 14, MUT, false);
            button("สร้างกลุ่ม", true, () -> {
                if (Group.name(this) == null) { askName(false); return; }
                enterGroup(Group.newId());
            });
            button("เข้าร่วมกลุ่ม (ใส่ไอดี)", false, this::askJoinGroup);
            button("ใส่ลิงก์เซิร์ฟเวอร์เอง (ไม่ใช้กลุ่ม)", false, () ->
                    startActivity(new Intent(this, MainActivity.class).putExtra("ask", true)
                            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)));
            return;
        }

        // ไอดีกลุ่ม
        LinearLayout idCard = card();
        TextView lab = new TextView(this);
        lab.setText("ไอดีกลุ่ม");
        lab.setTextColor(MUT);
        lab.setTextSize(13);
        idCard.addView(lab);
        TextView idv = new TextView(this);
        idv.setText(gid);
        idv.setTextColor(AC);
        idv.setTextSize(34);
        idv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        idv.setLetterSpacing(0.15f);
        idv.setTextIsSelectable(true);
        idCard.addView(idv);
        button("คัดลอกไอดี", false, () -> {
            ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("gid", gid));
            Toast.makeText(this, "คัดลอกแล้ว", Toast.LENGTH_SHORT).show();
        });
        button("แชร์ไอดีให้เพื่อน", false, () -> startActivity(Intent.createChooser(
                new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,
                        "เข้ากลุ่มเสียงในเกม 🎧\nเปิดแอป Proximity Voice > เข้าร่วมกลุ่ม แล้วใส่ไอดี: " + gid), "แชร์ไอดีกลุ่ม")));

        // สถานะ
        HostService hs = HostService.instance;
        boolean mine = hs != null && hs.gid != null && hs.gid.equals(gid);
        String st;
        if (netErr != null && !mine) st = netErr;
        else if (!checked && !mine) st = "กำลังเช็กสถานะกลุ่ม...";
        else if (mine) st = "คุณกำลังโฮสต์เซิร์ฟเวอร์ของกลุ่ม" + (hs.tunnel != null && hs.tunnel.url == null ? "\n(กำลังขอลิงก์...)" : "");
        else if (host == null) st = "ตอนนี้ยังไม่มีใครสร้างเซิร์ฟเวอร์ในกลุ่ม";
        else st = host.name + " กำลังโฮสต์เซิร์ฟเวอร์อยู่";
        TextView s = text(st, 15, FG, false);
        s.setPadding(dp(16), dp(14), dp(16), dp(14));
        s.setBackground(round(CARD, 16));
        ((LinearLayout.LayoutParams) s.getLayoutParams()).setMargins(0, dp(14), 0, dp(4));

        boolean other = host != null && !host.dev.equals(Group.device(this));
        if (host != null && (other || mine))
            button(mine ? "เข้าร่วมเสียงเอง (เครื่องนี้)" : "เข้าเสียงของ " + host.name, true, this::join);

        Button hb = button(mine ? "หยุดเซิร์ฟเวอร์ของฉัน" : other ? "สร้างเซิร์ฟเวอร์ไม่ได้ (" + host.name + " สร้างอยู่)" : "สร้างเซิร์ฟเวอร์เสียง",
                !mine && !other, this::toggleHost);
        hb.setEnabled(mine || !other);
        hb.setAlpha(mine || !other ? 1f : 0.5f);

        Switch sw = new Switch(this);
        sw.setText("เข้าเสียงอัตโนมัติเมื่อมีคนในกลุ่มสร้างเซิร์ฟเวอร์");
        sw.setTextColor(FG);
        sw.setChecked(Group.auto(this));
        sw.setOnCheckedChangeListener((v, on) -> Group.setAuto(this, on));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.setMargins(0, dp(16), 0, dp(4));
        box.addView(sw, slp);

        if (mine)
            text("ในเกม (เป็นโฮสต์/เปิดโลก) พิมพ์:\n/wsserver localhost:3001\nแล้วรหัส 4 หลักจะขึ้นที่แถบด้านบนจอ", 13, MUT, false).setPadding(0, dp(12), 0, 0);

        button("ออกจากกลุ่ม", false, this::leaveGroup);
        text("สถานะกลุ่มส่งผ่านบริการสาธารณะ ntfy.sh ใครรู้ไอดีกลุ่มก็เข้าได้ อย่าแชร์ไอดีให้คนที่ไม่ไว้ใจ", 12, MUT, false).setPadding(0, dp(16), 0, 0);
    }

    // ---------- ตัวช่วย UI ----------
    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(radiusDp));
        g.setColor(color);
        return g;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setBackground(round(CARD, 16));
        box.addView(c, new LinearLayout.LayoutParams(-1, -2));
        return c;
    }

    private TextView text(String t, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(size); v.setTextColor(color);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        box.addView(v);
        return v;
    }

    private Button button(String t, boolean primary, Runnable r) {
        Button bt = new Button(this);
        bt.setText(t);
        bt.setAllCaps(false);
        bt.setTextColor(Color.WHITE);
        bt.setTextSize(15);
        bt.setPadding(dp(16), dp(14), dp(16), dp(14));
        bt.setBackground(round(primary ? Color.parseColor("#2F7D4F") : Color.parseColor("#2A352F"), 14));
        bt.setStateListAnimator(null);
        bt.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(8), 0, 0);
        box.addView(bt, lp);
        return bt;
    }
}
