package com.proximityvoice.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** รายการกลุ่ม (สูงสุด 3) + หน้ากลุ่ม: ชื่อกลุ่ม สมาชิก โฮสต์ และปุ่มเข้าเสียง */
public class GroupActivity extends Activity {
    private static final int BG = Color.parseColor("#161B18"), FG = Color.parseColor("#E8EFE9"),
            MUT = Color.parseColor("#8FA196"), AC = Color.parseColor("#5FBF86"), CARD = Color.parseColor("#1F2622");
    private static String lastAutoClaim = null;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final ExecutorService ex = Executors.newSingleThreadExecutor();
    private final Map<String, Long> lastPresence = new HashMap<>();   // ใช้เฉพาะในเธรด ex
    private LinearLayout box;
    private String viewGid;            // null = หน้ารายการกลุ่ม
    private Group.Snap snap;
    private String netErr;
    private boolean checked, nameDialog;

    private final Runnable tick = new Runnable() {
        @Override public void run() { poll(); h.postDelayed(this, 15000); }
    };

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(24), dp(16), dp(40));
        sv.addView(box);
        setContentView(sv);
        String cur = Group.id(this);
        viewGid = (cur != null && !getIntent().getBooleanExtra("list", false)) ? cur : null;
    }

    @Override protected void onResume() {
        super.onResume();
        render();
        if (Group.name(this) == null) askName(false);
        h.post(tick);
    }

    @Override protected void onPause() { h.removeCallbacks(tick); super.onPause(); }
    @Override protected void onDestroy() { ex.shutdownNow(); super.onDestroy(); }

    @Override
    public void onBackPressed() {
        if (viewGid != null) { viewGid = null; snap = null; render(); }
        else super.onBackPressed();
    }

    // ---------- ดึงสถานะกลุ่ม ----------
    private void poll() {
        final String gid = viewGid;
        if (gid == null) return;
        ex.submit(() -> {
            long t0 = System.currentTimeMillis();
            Long lp = lastPresence.get(gid);
            if (lp == null || t0 - lp > 270000) {
                try { Group.publishHere(this, gid); lastPresence.put(gid, t0); } catch (IOException ignored) { }
            }
            Group.Snap s = null; String err = null;
            try { s = Group.snapshot(gid, "12h"); } catch (IOException e) { err = "เช็กสถานะกลุ่มไม่ได้ (ต้องมีอินเทอร์เน็ต)"; }
            final Group.Snap fs = s; final String ferr = err;
            h.post(() -> {
                if (isFinishing() || !gid.equals(viewGid)) return;
                if (ferr == null) {
                    snap = fs;
                    Group.G g = Group.find(this, gid);
                    // ชื่อกลุ่ม: สมาชิกใช้ชื่อที่เจ้าของตั้ง / เจ้าของใช้ชื่อตัวเองเป็นหลัก
                    if (g != null && !fs.title.isEmpty() && (!g.own || g.title.isEmpty()) && !fs.title.equals(g.title))
                        Group.setTitle(this, gid, fs.title);
                }
                netErr = ferr;
                checked = true;
                render();
                autoJoin();
            });
        });
    }

    private boolean iAmHost() {
        HostService s = HostService.instance;
        return s != null && s.gid != null && s.gid.equals(viewGid);
    }

    private void autoJoin() {
        if (snap == null || snap.host == null || !Group.auto(this) || iAmHost()) return;
        if (snap.host.dev.equals(Group.device(this))) return;
        if (snap.host.claim.equals(lastAutoClaim)) return;
        lastAutoClaim = snap.host.claim;
        join();
    }

    private void join() {
        if (snap == null || snap.host == null) return;
        boolean me = snap.host.dev.equals(Group.device(this)) && iAmHost();
        String url = me ? "http://localhost:" + VoiceHost.VOICE_PORT : snap.host.url;
        getSharedPreferences("pv", MODE_PRIVATE).edit().putString("url", url).apply();
        startActivity(new Intent(this, MainActivity.class).putExtra("join", true)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
    }

    // ---------- สร้างเซิร์ฟเวอร์ (มีได้คนเดียวต่อกลุ่ม) ----------
    private void toggleHost() {
        final String gid = viewGid;
        if (iAmHost()) {
            stopService(new Intent(this, HostService.class));
            if (snap != null) snap.host = null;
            h.postDelayed(this::poll, 1500);
            render();
            return;
        }
        if (HostService.instance != null) {
            Toast.makeText(this, HostService.instance.gid != null
                    ? "คุณกำลังโฮสต์ของอีกกลุ่มอยู่ หยุดก่อนถึงจะสร้างกลุ่มนี้ได้"
                    : "มีเซิร์ฟเวอร์แบบแมนนวลรันอยู่ ปิดที่ ⚙ > สร้างเซิร์ฟเวอร์ก่อน", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "กำลังเช็กกลุ่ม...", Toast.LENGTH_SHORT).show();
        ex.submit(() -> {
            try {
                Group.Host w = Group.current(gid);
                if (w != null && !w.dev.equals(Group.device(this))) {
                    h.post(() -> {
                        poll();
                        Toast.makeText(this, w.name + " สร้างเซิร์ฟเวอร์ในกลุ่มนี้อยู่แล้ว สร้างซ้ำไม่ได้", Toast.LENGTH_LONG).show();
                    });
                    return;
                }
                h.post(this::startHost);
            } catch (IOException e) {
                h.post(() -> Toast.makeText(this, "เช็กกลุ่มไม่ได้ ต้องมีอินเทอร์เน็ต", Toast.LENGTH_LONG).show());
            }
        });
    }

    private void startHost() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 22);
        try {
            startForegroundService(new Intent(this, HostService.class)
                    .putExtra("tunnel", true)
                    .putExtra("gid", viewGid)
                    .putExtra("gname", Group.name(this))
                    .putExtra("gdev", Group.device(this)));
            Toast.makeText(this, "กำลังสร้างเซิร์ฟเวอร์ รอสักครู่...", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "เริ่มบริการไม่ได้: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        h.postDelayed(this::render, 500);
        h.postDelayed(this::poll, 8000);
    }

    // ---------- กล่องโต้ตอบ ----------
    private EditText input(String hint, int max, String preset) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setSingleLine();
        et.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max)});
        if (preset != null) et.setText(preset);
        return et;
    }

    private void askName(boolean cancelable) {
        if (nameDialog) return;
        nameDialog = true;
        EditText et = input("ชื่อของคุณ เช่น Steve", 20, Group.name(this));
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("ตั้งชื่อของคุณ")
                .setMessage("เพื่อนในกลุ่มจะเห็นชื่อนี้ในรายชื่อสมาชิกและตอนที่คุณสร้างเซิร์ฟเวอร์")
                .setView(et)
                .setCancelable(cancelable)
                .setPositiveButton("ตกลง", (d, w) -> {
                    String n = et.getText().toString().trim();
                    Group.setName(this, n.isEmpty() ? "Player" : n);
                    lastPresence.clear();
                    render();
                    poll();
                })
                .setOnDismissListener(d -> nameDialog = false);
        if (cancelable) b.setNegativeButton("ยกเลิก", null);
        b.show();
    }

    private void createGroup() {
        if (Group.name(this) == null) { askName(false); return; }
        if (Group.list(this).size() >= Group.MAX) {
            Toast.makeText(this, "มีกลุ่มครบ " + Group.MAX + " กลุ่มแล้ว ออกจากกลุ่มเดิมก่อน", Toast.LENGTH_LONG).show();
            return;
        }
        EditText et = input("เช่น ก๊วนมายคราฟ", 24, "กลุ่มของ " + Group.name(this));
        new AlertDialog.Builder(this)
                .setTitle("ตั้งชื่อกลุ่ม")
                .setView(et)
                .setPositiveButton("สร้างกลุ่ม", (d, w) -> {
                    String t = et.getText().toString().trim();
                    String id = Group.newId();
                    Group.add(this, id, t.isEmpty() ? "กลุ่ม " + id : t, true);
                    openGroup(id);
                })
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    private void askJoinGroup() {
        if (Group.name(this) == null) { askName(false); return; }
        if (Group.list(this).size() >= Group.MAX) {
            Toast.makeText(this, "มีกลุ่มครบ " + Group.MAX + " กลุ่มแล้ว ออกจากกลุ่มเดิมก่อน", Toast.LENGTH_LONG).show();
            return;
        }
        EditText et = input("ไอดีกลุ่ม 6 ตัว เช่น K7M2QX", 6, null);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        new AlertDialog.Builder(this)
                .setTitle("เข้าร่วมกลุ่ม")
                .setView(et)
                .setPositiveButton("เข้าร่วม", (d, w) -> {
                    String id = Group.normalize(et.getText().toString());
                    if (!Group.valid(id)) {
                        Toast.makeText(this, "ไอดีไม่ถูกต้อง ต้องเป็นตัวอักษร/ตัวเลข 6 ตัว", Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (!Group.add(this, id, "", false)) return;
                    openGroup(id);
                })
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    private void renameGroup() {
        Group.G g = Group.find(this, viewGid);
        if (g == null || !g.own) return;
        EditText et = input("ชื่อกลุ่ม", 24, g.title);
        new AlertDialog.Builder(this)
                .setTitle("เปลี่ยนชื่อกลุ่ม")
                .setView(et)
                .setPositiveButton("บันทึก", (d, w) -> {
                    String t = et.getText().toString().trim();
                    if (t.isEmpty()) return;
                    Group.setTitle(this, g.id, t);
                    lastPresence.remove(g.id);   // ประกาศชื่อใหม่ให้สมาชิกทันที
                    render();
                    poll();
                })
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    private void openGroup(String id) {
        viewGid = id;
        Group.setCurrent(this, id);
        snap = null; netErr = null; checked = false;
        render();
        poll();
    }

    private void leaveGroup() {
        final String gid = viewGid;
        new AlertDialog.Builder(this)
                .setMessage("ออกจากกลุ่มนี้? (ถ้าคุณโฮสต์อยู่ เซิร์ฟเวอร์จะถูกปิดด้วย)")
                .setPositiveButton("ออก", (d, w) -> {
                    if (iAmHost()) stopService(new Intent(this, HostService.class));
                    final android.content.Context app = getApplicationContext();
                    new Thread(() -> { try { Group.publishLeave(app, gid); } catch (Exception ignored) { } }).start();
                    Group.remove(this, gid);
                    if (!Group.any(this))
                        getSharedPreferences("pv", MODE_PRIVATE).edit().remove("url").apply();
                    viewGid = null; snap = null;
                    render();
                })
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    // ---------- หน้าจอ ----------
    private void render() {
        box.removeAllViews();
        if (viewGid == null) renderList(); else renderGroup();
    }

    private void nameLine() {
        String name = Group.name(this);
        TextView who = text("ชื่อของคุณ: " + (name == null ? "-" : name) + "   (แตะเพื่อเปลี่ยน)", 13, MUT, false);
        who.setOnClickListener(v -> askName(true));
        who.setPadding(0, dp(4), 0, dp(12));
    }

    private void renderList() {
        text("กลุ่มเสียง", 26, FG, true);
        nameLine();
        List<Group.G> gs = Group.list(this);
        text("กลุ่มของคุณ " + gs.size() + "/" + Group.MAX, 13, MUT, false);
        if (gs.isEmpty())
            text("สร้างกลุ่มใหม่แล้วส่งไอดีให้เพื่อน หรือใส่ไอดีกลุ่มของเพื่อนเพื่อเข้าร่วม สมาชิกจะเข้าเสียงที่คนในกลุ่มสร้างได้อัตโนมัติ และสร้างเซิร์ฟเวอร์ได้ทีละคนต่อกลุ่ม", 14, MUT, false)
                    .setPadding(0, dp(8), 0, 0);
        for (Group.G g : gs) {
            LinearLayout c = card();
            c.setOnClickListener(v -> openGroup(g.id));
            TextView t = new TextView(this);
            t.setText(g.label() + (g.own ? "  ★" : ""));
            t.setTextColor(FG); t.setTextSize(18); t.setTypeface(null, Typeface.BOLD);
            c.addView(t);
            TextView i = new TextView(this);
            i.setText("ไอดี " + g.id + "  ·  แตะเพื่อเปิด");
            i.setTextColor(MUT); i.setTextSize(13);
            c.addView(i);
            ((LinearLayout.LayoutParams) c.getLayoutParams()).setMargins(0, dp(8), 0, 0);
        }
        button("สร้างกลุ่มใหม่", true, this::createGroup);
        button("เข้าร่วมกลุ่ม (ใส่ไอดี)", false, this::askJoinGroup);
        if (gs.size() >= Group.MAX) text("ครบ " + Group.MAX + " กลุ่มแล้ว ถ้าจะสร้างหรือเข้าเพิ่ม ต้องออกจากกลุ่มเดิมก่อน", 12, MUT, false).setPadding(0, dp(6), 0, 0);
        button("ใส่ลิงก์เซิร์ฟเวอร์เอง (ไม่ใช้กลุ่ม)", false, () ->
                startActivity(new Intent(this, MainActivity.class).putExtra("ask", true)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)));
        text("★ = กลุ่มที่คุณสร้าง (เปลี่ยนชื่อกลุ่มได้) · สถานะกลุ่มส่งผ่านบริการสาธารณะ ntfy.sh ใครรู้ไอดีก็เข้าได้ อย่าแชร์ให้คนที่ไม่ไว้ใจ", 12, MUT, false).setPadding(0, dp(16), 0, 0);
    }

    private String ago(long ms) {
        long m = ms / 60000;
        if (m < 1) return "เมื่อครู่";
        if (m < 60) return m + " นาทีที่แล้ว";
        return (m / 60) + " ชม.ที่แล้ว";
    }

    private void renderGroup() {
        final String gid = viewGid;
        Group.G g = Group.find(this, gid);
        if (g == null) { viewGid = null; renderList(); return; }
        final String me = Group.device(this);

        TextView back = text("‹ กลุ่มทั้งหมด", 14, AC, false);
        back.setOnClickListener(v -> onBackPressed());
        back.setPadding(0, 0, 0, dp(8));
        TextView title = text(g.label() + (g.own ? "  ✎" : ""), 24, FG, true);
        if (g.own) title.setOnClickListener(v -> renameGroup());
        nameLine();

        LinearLayout idCard = card();
        TextView lab = new TextView(this);
        lab.setText("ไอดีกลุ่ม (ส่งให้เพื่อน)");
        lab.setTextColor(MUT); lab.setTextSize(13);
        idCard.addView(lab);
        TextView idv = new TextView(this);
        idv.setText(gid);
        idv.setTextColor(AC); idv.setTextSize(34);
        idv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        idv.setLetterSpacing(0.15f);
        idv.setTextIsSelectable(true);
        idCard.addView(idv);
        button("คัดลอกไอดี", false, () -> {
            ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("gid", gid));
            Toast.makeText(this, "คัดลอกแล้ว", Toast.LENGTH_SHORT).show();
        });
        button("แชร์ไอดีให้เพื่อน", false, () -> startActivity(Intent.createChooser(
                new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,
                        "เข้ากลุ่ม \"" + g.label() + "\" ในเกม 🎧\nเปิดแอป Proximity Voice > เข้าร่วมกลุ่ม แล้วใส่ไอดี: " + gid), "แชร์ไอดีกลุ่ม")));

        // สถานะโฮสต์
        HostService hs = HostService.instance;
        boolean mine = hs != null && hs.gid != null && hs.gid.equals(gid);
        Group.Host host = snap == null ? null : snap.host;
        String st;
        if (netErr != null && !mine) st = netErr;
        else if (!checked && !mine) st = "กำลังเช็กสถานะกลุ่ม...";
        else if (mine) st = "คุณกำลังโฮสต์เซิร์ฟเวอร์ของกลุ่ม" + (hs.tunnel != null && hs.tunnel.url == null ? "\n(กำลังขอลิงก์...)" : "");
        else if (host == null) st = "ตอนนี้ยังไม่มีใครสร้างเซิร์ฟเวอร์ในกลุ่ม";
        else st = host.name + " กำลังโฮสต์เซิร์ฟเวอร์อยู่";
        TextView s = text(st, 15, FG, false);
        s.setPadding(dp(16), dp(14), dp(16), dp(14));
        s.setBackground(round(CARD, 16));
        ((LinearLayout.LayoutParams) s.getLayoutParams()).setMargins(0, dp(14), 0, dp(4));

        boolean other = host != null && !host.dev.equals(me);
        if (host != null && (other || mine))
            button(mine ? "เข้าร่วมเสียงเอง (เครื่องนี้)" : "เข้าเสียงของ " + host.name, true, this::join);

        Button hb = button(mine ? "หยุดเซิร์ฟเวอร์ของฉัน" : other ? "สร้างเซิร์ฟเวอร์ไม่ได้ (" + host.name + " สร้างอยู่)" : "สร้างเซิร์ฟเวอร์เสียง",
                !mine && !other, this::toggleHost);
        hb.setEnabled(mine || !other);
        hb.setAlpha(mine || !other ? 1f : 0.5f);

        Switch sw = new Switch(this);
        sw.setText("เข้าเสียงอัตโนมัติเมื่อมีคนในกลุ่มสร้างเซิร์ฟเวอร์");
        sw.setTextColor(FG);
        sw.setChecked(Group.auto(this));
        sw.setOnCheckedChangeListener((v, on) -> Group.setAuto(this, on));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.setMargins(0, dp(16), 0, dp(4));
        box.addView(sw, slp);

        if (mine)
            text("ในเกม (เป็นโฮสต์/เปิดโลก) พิมพ์:\n/wsserver localhost:3001\nแล้วรหัส 4 หลักจะขึ้นที่แถบด้านบนจอ", 13, MUT, false).setPadding(0, dp(12), 0, 0);

        // รายชื่อสมาชิก
        int n = snap == null ? 0 : snap.members.size();
        text("สมาชิกในกลุ่ม" + (snap == null ? "" : " (" + n + ")"), 16, FG, true).setPadding(0, dp(20), 0, dp(6));
        LinearLayout mc = card();
        if (snap == null || snap.members.isEmpty()) {
            TextView e = new TextView(this);
            e.setText(netErr != null ? "โหลดรายชื่อไม่ได้" : checked ? "ยังไม่มีใครส่งสัญญาณ (เปิดหน้านี้ค้างไว้สักครู่)" : "กำลังโหลด...");
            e.setTextColor(MUT); e.setTextSize(14);
            mc.addView(e);
        } else {
            for (Group.Member m : snap.members) {
                boolean isHost = host != null && host.dev.equals(m.dev);
                boolean online = snap.now - m.seen <= Group.ACTIVE_MS;
                String status = isHost ? "🎙 โฮสต์" : online ? "ออนไลน์" : "เห็นเมื่อ " + ago(snap.now - m.seen);
                int col = (isHost || online) ? AC : MUT;
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, dp(7), 0, dp(7));
                TextView nm = new TextView(this);
                nm.setText((m.name == null || m.name.isEmpty() ? "Player" : m.name) + (m.dev.equals(me) ? " (คุณ)" : ""));
                nm.setTextColor(FG); nm.setTextSize(15);
                row.addView(nm, new LinearLayout.LayoutParams(0, -2, 1f));
                TextView stt = new TextView(this);
                stt.setText(status);
                stt.setTextColor(col); stt.setTextSize(13);
                row.addView(stt);
                mc.addView(row);
            }
        }
        text("สมาชิกจะโผล่ในรายชื่อเมื่อเปิดหน้ากลุ่มนี้ และสถานะ \"ออนไลน์\" นับจากการเปิดหน้านี้ล่าสุด (ไม่ใช่ว่ากำลังคุยอยู่)", 12, MUT, false).setPadding(0, dp(6), 0, 0);

        button("ออกจากกลุ่ม", false, this::leaveGroup);
    }

    // ---------- ตัวช่วย UI ----------
    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(radiusDp));
        g.setColor(color);
        return g;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setBackground(round(CARD, 16));
        box.addView(c, new LinearLayout.LayoutParams(-1, -2));
        return c;
    }

    private TextView text(String t, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(size); v.setTextColor(color);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        box.addView(v);
        return v;
    }

    private Button button(String t, boolean primary, Runnable r) {
        Button bt = new Button(this);
        bt.setText(t);
        bt.setAllCaps(false);
        bt.setTextColor(Color.WHITE);
        bt.setTextSize(15);
        bt.setPadding(dp(16), dp(14), dp(16), dp(14));
        bt.setBackground(round(primary ? Color.parseColor("#2F7D4F") : Color.parseColor("#2A352F"), 14));
        bt.setStateListAnimator(null);
        bt.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(8), 0, 0);
        box.addView(bt, lp);
        return bt;
    }
}
