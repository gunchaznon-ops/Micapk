package com.proximityvoice.app;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** รัน cloudflared (ฝังในแอปเป็น libcloudflared.so) แล้วอ่านลิงก์ trycloudflare.com */
final class Tunnel {
    private static final Pattern URL = Pattern.compile("https://([a-z0-9-]+)\\.trycloudflare\\.com");
    volatile String url;
    volatile String state = "idle";   // idle | starting | ok | missing | exited | error | stopped
    private final ArrayDeque<String> lines = new ArrayDeque<>();
    private Process proc;

    synchronized String log() {
        StringBuilder sb = new StringBuilder();
        for (String l : lines) sb.append(l).append('\n');
        return sb.toString();
    }

    private synchronized void add(String l) {
        lines.add(l);
        while (lines.size() > 40) lines.poll();
    }

    void start(Context ctx, int port) {
        state = "starting";
        final Context c = ctx.getApplicationContext();
        Thread t = new Thread(() -> run(c, port), "cloudflared");
        t.setDaemon(true);
        t.start();
    }

    private void run(Context c, int port) {
        try {
            File bin = new File(c.getApplicationInfo().nativeLibraryDir, "libcloudflared.so");
            if (!bin.exists()) { state = "missing"; add("ไม่พบ " + bin); return; }
            ProcessBuilder pb = new ProcessBuilder(bin.getAbsolutePath(), "tunnel", "--no-autoupdate",
                    "--edge-ip-version", "4", "--url", "http://127.0.0.1:" + port);
            pb.environment().put("HOME", c.getFilesDir().getAbsolutePath());
            pb.environment().put("TMPDIR", c.getCacheDir().getAbsolutePath());
            // ให้ Go หา CA ของ Android เจอ (ระบบ Linux ทั่วไปไม่มี /etc/ssl)
            pb.environment().put("SSL_CERT_DIR", "/apex/com.android.conscrypt/cacerts:/system/etc/security/cacerts");
            pb.redirectErrorStream(true);
            proc = pb.start();
            BufferedReader r = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            String line;
            while ((line = r.readLine()) != null) {
                add(line);
                if (url == null) {
                    Matcher m = URL.matcher(line);
                    while (m.find()) {
                        if (!"api".equals(m.group(1))) { url = m.group(0); state = "ok"; break; }
                    }
                }
            }
            if (!"stopped".equals(state)) state = "exited";
        } catch (Exception e) {
            if (!"stopped".equals(state)) { state = "error"; add(e.toString()); }
        }
    }

    void stop() {
        state = "stopped";
        if (proc != null) proc.destroy();
    }
}
