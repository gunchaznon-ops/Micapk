package com.proximityvoice.app;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** รัน cloudflared (ฝังในแอปเป็น libcloudflared.so) ต่อใหม่เองเมื่อหลุด
 *  - ไม่มี token: ลิงก์ชั่วคราว trycloudflare.com (เปลี่ยนทุกครั้งที่ต่อใหม่)
 *  - มี token + โดเมน: ลิงก์ถาวรของคุณเอง (Cloudflare Tunnel) */
final class Tunnel {
    private static final Pattern URL = Pattern.compile("https://([a-z0-9-]+)\\.trycloudflare\\.com");
    volatile String url;
    volatile int version;                 // เพิ่มทุกครั้งที่ได้ลิงก์ใหม่
    volatile String state = "idle";       // idle | starting | ok | restarting | missing | error | stopped
    private final String token, host;
    private final ArrayDeque<String> lines = new ArrayDeque<>();
    private Process proc;
    private volatile boolean stopped;

    Tunnel() { this(null, null); }

    Tunnel(String token, String host) {
        this.token = token == null ? "" : token.trim();
        this.host = host == null ? "" : host.trim().replace("https://", "").replace("http://", "").replaceAll("/.*$", "");
    }

    boolean permanent() { return !token.isEmpty(); }

    synchronized String log() {
        StringBuilder sb = new StringBuilder();
        for (String l : lines) sb.append(l).append('\n');
        return sb.toString();
    }

    private synchronized void add(String l) {
        lines.add(l);
        while (lines.size() > 60) lines.poll();
    }

    void start(Context ctx, int port) {
        state = "starting";
        final Context c = ctx.getApplicationContext();
        Thread t = new Thread(() -> loop(c, port), "cloudflared");
        t.setDaemon(true);
        t.start();
    }

    /** วนรัน: หลุดแล้วรอแล้วต่อใหม่ (รอ 2 → 4 → 8 ... สูงสุด 30 วินาที) */
    private void loop(Context c, int port) {
        int backoff = 2;
        while (!stopped) {
            long t0 = System.currentTimeMillis();
            runOnce(c, port);
            if (stopped) break;
            if (!"missing".equals(state)) state = "restarting";
            else return;
            if (System.currentTimeMillis() - t0 > 60000) backoff = 2;   // เคยทำงานนานพอ เริ่มรอสั้นใหม่
            add("-- cloudflared หยุด จะเริ่มใหม่ใน " + backoff + " วินาที --");
            try { Thread.sleep(backoff * 1000L); } catch (InterruptedException e) { return; }
            backoff = Math.min(30, backoff * 2);
            if (!permanent()) url = null;   // ลิงก์ชั่วคราวจะเปลี่ยนใหม่
        }
    }

    private void runOnce(Context c, int port) {
        try {
            File bin = new File(c.getApplicationInfo().nativeLibraryDir, "libcloudflared.so");
            if (!bin.exists()) { state = "missing"; add("ไม่พบ " + bin); return; }
            ProcessBuilder pb;
            if (permanent()) {
                pb = new ProcessBuilder(bin.getAbsolutePath(), "tunnel", "--no-autoupdate", "--edge-ip-version", "4",
                        "run", "--token", token);
            } else {
                pb = new ProcessBuilder(bin.getAbsolutePath(), "tunnel", "--no-autoupdate", "--edge-ip-version", "4",
                        "--url", "http://127.0.0.1:" + port);
            }
            pb.environment().put("HOME", c.getFilesDir().getAbsolutePath());
            pb.environment().put("TMPDIR", c.getCacheDir().getAbsolutePath());
            pb.environment().put("SSL_CERT_DIR", "/apex/com.android.conscrypt/cacerts:/system/etc/security/cacerts");
            pb.redirectErrorStream(true);
            proc = pb.start();
            BufferedReader r = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            String line;
            while ((line = r.readLine()) != null) {
                add(permanent() ? line.replace(token, "***") : line);
                if (permanent()) {
                    if (line.contains("Registered tunnel connection") && !"ok".equals(state)) {
                        if (!host.isEmpty()) { url = "https://" + host; version++; }
                        state = "ok";
                    }
                } else if (url == null) {
                    Matcher m = URL.matcher(line);
                    while (m.find()) {
                        if (!"api".equals(m.group(1))) { url = m.group(0); version++; state = "ok"; break; }
                    }
                }
            }
        } catch (Exception e) {
            if (!stopped) add(e.toString());
        }
    }

    void stop() {
        stopped = true;
        state = "stopped";
        if (proc != null) proc.destroy();
    }
}
