package com.proximityvoice.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** ฟังกระดานกลุ่มเบื้องหลัง แล้วแจ้งเตือนเมื่อมีเพื่อนสร้างเซิร์ฟเวอร์เสียง (เปิด/ปิดได้ในตั้งค่า) */
public class GroupWatchService extends Service {
    private static final Set<String> notified = Collections.synchronizedSet(new HashSet<>());
    private final Map<String, Thread> watchers = new HashMap<>();
    private final Map<String, HttpURLConnection> conns = new HashMap<>();
    private Thread manager;
    private volatile boolean stop;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("watch", "รอแจ้งเตือนกลุ่ม", NotificationManager.IMPORTANCE_MIN));
        NotificationChannel alert = new NotificationChannel("alerts", "เพื่อนสร้างเซิร์ฟเวอร์", NotificationManager.IMPORTANCE_HIGH);
        nm.createNotificationChannel(alert);
        Notification n = new Notification.Builder(this, "watch")
                .setContentTitle("กำลังรอแจ้งเตือนจากกลุ่ม")
                .setSmallIcon(android.R.drawable.ic_popup_sync)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(3, n);
        if (manager == null) {
            manager = new Thread(this::manage, "group-watch");
            manager.setDaemon(true);
            manager.start();
        }
        return START_STICKY;
    }

    /** ดูว่ามีกลุ่มไหนเพิ่ม/ลด แล้วเปิด/ปิดตัวฟังของกลุ่มนั้น */
    private void manage() {
        while (!stop) {
            List<Group.G> gs = Group.list(this);
            synchronized (watchers) {
                Set<String> ids = new HashSet<>();
                for (Group.G g : gs) {
                    ids.add(g.id);
                    Thread t = watchers.get(g.id);
                    if (t == null || !t.isAlive()) {
                        final String gid = g.id;
                        t = new Thread(() -> watch(gid), "watch-" + gid);
                        t.setDaemon(true);
                        watchers.put(gid, t);
                        t.start();
                    }
                }
                for (String id : new HashSet<>(watchers.keySet())) {
                    if (!ids.contains(id)) {
                        Thread t = watchers.remove(id);
                        t.interrupt();
                        HttpURLConnection c = conns.remove(id);
                        if (c != null) c.disconnect();
                    }
                }
            }
            try { Thread.sleep(20000); } catch (InterruptedException e) { return; }
        }
    }

    private void watch(String gid) {
        int backoff = 5;
        while (!stop && !Thread.currentThread().isInterrupted()) {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL("https://ntfy.sh/pvgrp-" + gid.toLowerCase() + "/json").openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(130000);   // ntfy ส่ง keepalive ทุก ~45 วินาที
                synchronized (watchers) { conns.put(gid, c); }
                if (c.getResponseCode() != 200) throw new java.io.IOException("HTTP " + c.getResponseCode());
                backoff = 5;
                try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
                    String line;
                    while ((line = r.readLine()) != null) handle(gid, line);
                }
            } catch (Exception e) {
                if (stop || Thread.currentThread().isInterrupted()) return;
            }
            try { Thread.sleep(backoff * 1000L); } catch (InterruptedException e) { return; }
            backoff = Math.min(60, backoff * 2);
        }
    }

    private void handle(String gid, String line) {
        try {
            JSONObject e = new JSONObject(line);
            if (!"message".equals(e.optString("event"))) return;
            JSONObject m = new JSONObject(e.optString("message"));
            if (!"host".equals(m.optString("t"))) return;
            if (m.optString("dev").equals(Group.device(this))) return;
            String key = gid + ":" + m.optString("claim");
            if (!notified.add(key)) return;
            if (GroupActivity.visible) return;   // เปิดหน้ากลุ่มอยู่แล้ว ไม่ต้องเด้ง
            Group.G g = Group.find(this, gid);
            String title = g == null ? "กลุ่ม " + gid : g.label();
            Group.setCurrent(this, gid);
            PendingIntent pi = PendingIntent.getActivity(this, gid.hashCode(),
                    new Intent(this, GroupActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(this, "alerts")
                    .setContentTitle(title)
                    .setContentText(m.optString("name") + " สร้างเซิร์ฟเวอร์เสียงแล้ว แตะเพื่อเข้า")
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build();
            getSystemService(NotificationManager.class).notify(gid.hashCode(), n);
        } catch (Exception ignored) { }
    }

    @Override
    public void onDestroy() {
        stop = true;
        if (manager != null) manager.interrupt();
        synchronized (watchers) {
            for (Thread t : watchers.values()) t.interrupt();
            for (HttpURLConnection c : conns.values()) c.disconnect();
        }
        super.onDestroy();
    }
}
