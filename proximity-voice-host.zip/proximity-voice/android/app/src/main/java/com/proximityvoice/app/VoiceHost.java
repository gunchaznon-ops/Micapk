package com.proximityvoice.app;

import android.content.res.AssetManager;

import fi.iki.elonen.NanoHTTPD;
import fi.iki.elonen.NanoWSD;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/** เซิร์ฟเวอร์เสียงในตัวแอป (พอร์ตตรรกะมาจาก server.js เดิม)
 *  - พอร์ต 3000: เว็บ + WebSocket ให้เพื่อนเข้า (ผ่าน cloudflared)
 *  - พอร์ต 3001 (เฉพาะเครื่องนี้): รับ /wsserver จากเกม */
final class VoiceHost {
    static final int VOICE_PORT = 3000, MC_PORT = 3001;
    private static final double FULL = 2, MAX = 32, SHOUT = 3, WHISPER = 0.4;   // ตะโกน = ไกลขึ้น 3 เท่า / กระซิบ = แคบลงเหลือ 40%

    private static final class Player {
        String name, dim;
        double x, y, z, fx, fz;
        long t;
    }

    private static final class Client {
        final int id;
        final NanoWSD.WebSocket ws;
        final String name;
        volatile int mode;               // 0 ปกติ, 1 ตะโกน, 2 กระซิบ
        volatile int radio;              // ช่องวิทยุที่จูนไว้ (0 = ปิด)
        volatile boolean radioTx;        // กำลังกดพูดวิทยุ
        volatile boolean hostMuted;      // โฮสต์ปิดเสียงคนนี้
        volatile long lastRx = System.currentTimeMillis();
        Client(int id, NanoWSD.WebSocket ws, String name) { this.id = id; this.ws = ws; this.name = name; }
    }

    private final AssetManager assets;
    private final Object lock = new Object();
    private final Map<String, Player> players = new HashMap<>();
    private final Map<String, String> codes = new HashMap<>();
    private final Map<String, String> nameCode = new HashMap<>();
    private final Map<Integer, Client> clients = new LinkedHashMap<>();
    private int nextId = 1;
    private final AtomicInteger games = new AtomicInteger();
    private volatile boolean running;
    private VoiceServer voice;
    private McServer mc;

    private volatile boolean requireCode;
    private final java.util.Set<String> banned = new java.util.HashSet<>();
    private Thread reaper;

    VoiceHost(AssetManager assets) { this.assets = assets; }

    void setRequireCode(boolean b) { requireCode = b; }

    static final class Info { int id; String name; boolean muted; int mode; }

    /** รายชื่อคนที่อยู่ในห้องเสียงตอนนี้ (ให้หน้าโฮสต์ใช้เตะ/ปิดเสียง) */
    List<Info> clientInfos() {
        List<Info> out = new ArrayList<>();
        synchronized (lock) {
            for (Client c : clients.values()) {
                Info i = new Info();
                i.id = c.id; i.name = c.name; i.muted = c.hostMuted; i.mode = c.mode;
                out.add(i);
            }
        }
        return out;
    }

    void kick(int id) {
        Client c;
        synchronized (lock) {
            c = clients.get(id);
            if (c == null) return;
            banned.add(c.name.toLowerCase());
            sendTo(c.ws, o("type", "kicked", "message", "คุณถูกโฮสต์เตะออกจากห้องเสียง"));
        }
        closeClient(c);
    }

    void setHostMuted(int id, boolean on) {
        synchronized (lock) {
            Client c = clients.get(id);
            if (c == null) return;
            c.hostMuted = on;
            sendTo(c.ws, o("type", "hostmute", "on", on));
        }
        sendMix();
    }

    private void closeClient(Client c) {
        try { c.ws.close(NanoWSD.WebSocketFrame.CloseCode.GoingAway, "closed", false); } catch (Exception ignored) { }
    }

    boolean isRunning() { return running; }
    boolean gameConnected() { return games.get() > 0; }
    int clientCount() { synchronized (lock) { return clients.size(); } }

    void start() throws IOException {
        voice = new VoiceServer();
        voice.start(0, true);
        try {
            mc = new McServer();
            mc.start(0, true);
        } catch (IOException e) {
            voice.stop();
            throw e;
        }
        running = true;
        reaper = new Thread(() -> {
            while (running) {
                try { Thread.sleep(5000); } catch (InterruptedException e) { return; }
                long now = System.currentTimeMillis();
                List<Client> dead = new ArrayList<>();
                synchronized (lock) {
                    for (Client c : clients.values()) if (now - c.lastRx > 20000) dead.add(c);
                }
                for (Client c : dead) closeClient(c);   // เงียบเกิน 20 วินาที = หลุดแบบค้าง
            }
        }, "voice-reaper");
        reaper.setDaemon(true);
        reaper.start();
    }

    void stop() {
        running = false;
        if (reaper != null) reaper.interrupt();
        if (voice != null) voice.stop();
        if (mc != null) mc.stop();
    }

    // ---------- ตัวช่วย ----------
    private static JSONObject o(Object... kv) {
        JSONObject j = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) j.put((String) kv[i], kv[i + 1]);
        } catch (Exception ignored) { }
        return j;
    }

    private static void sendTo(NanoWSD.WebSocket ws, JSONObject j) {
        try { ws.send(j.toString()); } catch (Exception ignored) { }
    }

    /** เรียกขณะถือ lock */
    private String newCode(String name) {
        String c = nameCode.get(name);
        if (c != null) return c;
        do { c = String.valueOf(1000 + (int) (Math.random() * 9000)); } while (codes.containsKey(c));
        codes.put(c, name);
        nameCode.put(name, c);
        return c;
    }

    /** คืน [gain, pan, x, y, z, radioFlag] */
    /** หาชื่อผู้เล่นที่อยู่ในเกมตอนนี้ (ไม่สนตัวพิมพ์ใหญ่เล็ก) */
    private String findPlayer(String n) {
        long now = System.currentTimeMillis();
        for (Player p : players.values())
            if (p.name != null && p.name.equalsIgnoreCase(n) && now - p.t < 8000) return p.name;
        return null;
    }

    private double[] mixFor(Client cA, Client cB) {
        if (cB.hostMuted) return new double[]{0, 0, 0, 0, 0, 0};
        // วิทยุทีม: ช่องเดียวกันได้ยินกันเต็มเสียงไม่สนระยะ/มิติ
        if (cB.radioTx && cA.radio != 0 && cA.radio == cB.radio) return new double[]{1, 0, 0, 0, 0, 1};
        double mult = cB.mode == 1 ? SHOUT : cB.mode == 2 ? WHISPER : 1;
        double full = FULL * mult, max = MAX * mult;
        long now = System.currentTimeMillis();
        Player A = players.get(cA.name), B = players.get(cB.name);
        if (A == null || B == null || now - A.t > 3000 || now - B.t > 3000 || !A.dim.equals(B.dim))
            return new double[]{0, 0, 0, 0, 0, 0};
        double dx = B.x - A.x, dy = B.y - A.y, dz = B.z - A.z;
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double gain = dist <= full ? 1 : dist >= max ? 0 : 1 - (dist - full) / (max - full);
        double h = Math.hypot(dx, dz); if (h == 0) h = 1;
        double fl = Math.hypot(A.fx, A.fz); if (fl == 0) fl = 1;
        double fx = A.fx / fl, fz = A.fz / fl;
        // ขวามือของผู้ฟัง = (-fz, fx) ในพิกัด Minecraft (x=ตะวันออก, z=ใต้)
        double pan = Math.max(-1, Math.min(1, (dx / h) * -fz + (dz / h) * fx));
        if (dist < 1) return new double[]{gain * gain, 0, 0, 0, 0, 0};
        double fwd = (dx * fx + dz * fz) / dist;
        double right = (dx * -fz + dz * fx) / dist;
        return new double[]{gain * gain, pan, right, dy / dist, -fwd, 0};
    }

    private void sendMix() {
        synchronized (lock) {
            for (Client A : clients.values()) {
                JSONObject peers = new JSONObject();
                for (Client B : clients.values()) {
                    if (A.id == B.id) continue;
                    double[] m = mixFor(A, B);
                    try { peers.put(String.valueOf(B.id), o("gain", m[0], "pan", m[1], "x", m[2], "y", m[3], "z", m[4], "sh", B.mode == 1, "ws", B.mode == 2, "rd", m[5] == 1)); } catch (Exception ignored) { }
                }
                sendTo(A.ws, o("type", "mix", "peers", peers));
            }
        }
    }

    // ---------- เซิร์ฟเวอร์เว็บ + WebSocket ของเพื่อน ----------
    private final class VoiceServer extends NanoWSD {
        VoiceServer() { super(VOICE_PORT); }

        @Override
        protected WebSocket openWebSocket(IHTTPSession handshake) { return new VoiceConn(handshake); }

        @Override
        public Response serve(IHTTPSession s) {
            String up = s.getHeaders().get("upgrade");
            if (up != null && up.equalsIgnoreCase("websocket")) return super.serve(s);
            String uri = s.getUri();
            if ("/".equals(uri) || "/index.html".equals(uri)) {
                try {
                    InputStream in = assets.open("index.html");
                    return newChunkedResponse(Response.Status.OK, "text/html; charset=utf-8", in);
                } catch (IOException e) {
                    return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", "no page");
                }
            }
            return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "not found");
        }
    }

    private final class VoiceConn extends NanoWSD.WebSocket {
        private int id = 0;

        VoiceConn(NanoHTTPD.IHTTPSession h) { super(h); }

        @Override protected void onOpen() { }

        private void err(String msg) { sendTo(this, o("type", "error", "message", msg)); }

        @Override
        protected void onMessage(NanoWSD.WebSocketFrame frame) {
            JSONObject m;
            try { m = new JSONObject(frame.getTextPayload()); } catch (Exception e) { return; }
            String type = m.optString("type");
            List<Client> stale = new ArrayList<>();
            synchronized (lock) {
                Client self = id != 0 ? clients.get(id) : null;
                if (self != null) self.lastRx = System.currentTimeMillis();
                if ("ping".equals(type)) {
                    sendTo(this, o("type", "pong"));
                } else if ("join".equals(type) && id == 0) {
                    String codeStr = m.optString("code", ""), want = m.optString("name", "").trim();
                    String name;
                    if (!codeStr.isEmpty()) {
                        name = codes.get(codeStr);
                        if (name == null) { err("รหัสไม่ถูกต้อง ดูรหัสที่แถบด้านบนจอในเกม"); return; }
                        for (Client c : clients.values()) if (c.name.equalsIgnoreCase(name)) stale.add(c);   // เข้าใหม่ = แทนที่ตัวเก่าที่ค้าง
                    } else if (!want.isEmpty()) {
                        if (requireCode) { err("โฮสต์ตั้งให้ต้องใช้รหัส 4 หลัก ดูรหัสที่แถบด้านบนจอในเกม"); return; }
                        name = findPlayer(want);
                        if (name == null) {
                            err("ไม่พบผู้เล่นชื่อ \"" + want + "\" ในเกม (ต้องอยู่ในโลกที่โฮสต์ต่อเกมไว้แล้ว) หรือใช้รหัส 4 หลักแทน");
                            return;
                        }
                        for (Client c : clients.values())
                            if (c.name.equalsIgnoreCase(name)) { err("ชื่อนี้เข้าห้องเสียงอยู่แล้ว ถ้าเป็นคุณลองใหม่ในอีก 20 วินาที หรือใช้รหัส 4 หลัก"); return; }
                    } else { err("ใส่ชื่อในเกมหรือรหัส 4 หลักก่อน"); return; }
                    if (banned.contains(name.toLowerCase())) { err("คุณถูกโฮสต์เตะออกจากห้องนี้"); return; }
                    id = nextId++;
                    JSONArray peers = new JSONArray();
                    for (Client c : clients.values()) if (!stale.contains(c)) peers.put(o("id", c.id, "name", c.name));
                    clients.put(id, new Client(id, this, name));
                    sendTo(this, o("type", "joined", "id", id, "name", name, "peers", peers));
                    for (Client c : clients.values())
                        if (c.id != id && !stale.contains(c)) sendTo(c.ws, o("type", "peer-joined", "id", id, "name", name));
                } else if ("signal".equals(type) && id != 0) {
                    Client t = clients.get(m.optInt("to"));
                    if (t != null) sendTo(t.ws, o("type", "signal", "from", id, "data", m.opt("data")));
                } else if (self != null && "voice".equals(type)) {
                    String md = m.optString("m", "");
                    self.mode = "shout".equals(md) ? 1 : "whisper".equals(md) ? 2 : 0;
                } else if (self != null && "shout".equals(type)) {          // เข้ากันได้กับรุ่นเก่า
                    self.mode = m.optBoolean("on") ? 1 : 0;
                } else if (self != null && "radio".equals(type)) {
                    int ch = m.optInt("ch", 0);
                    self.radio = ch < 0 || ch > 4 ? 0 : ch;
                    self.radioTx = m.optBoolean("tx") && self.radio != 0;
                }
                // "level" ใช้เฉพาะโหมด BDS เดิม ตอนนี้ไม่ใช้ จึงไม่ต้องทำอะไร
            }
            for (Client c : stale) closeClient(c);
        }

        @Override
        protected void onClose(NanoWSD.WebSocketFrame.CloseCode code, String reason, boolean remote) {
            synchronized (lock) {
                if (id == 0) return;
                clients.remove(id);
                for (Client c : clients.values()) sendTo(c.ws, o("type", "peer-left", "id", id));
                id = 0;
            }
        }

        @Override protected void onPong(NanoWSD.WebSocketFrame pong) { }
        @Override protected void onException(IOException e) { }
    }

    // ---------- รับเกม Minecraft (/wsserver localhost:3001) ----------
    private final class McServer extends NanoWSD {
        McServer() { super("127.0.0.1", MC_PORT); }

        @Override
        protected WebSocket openWebSocket(IHTTPSession handshake) { return new McConn(handshake); }
    }

    private final class McConn extends NanoWSD.WebSocket {
        private final Map<String, CompletableFuture<JSONObject>> pending = new ConcurrentHashMap<>();
        private volatile boolean open;
        private Thread poller;

        McConn(NanoHTTPD.IHTTPSession h) { super(h); }

        @Override
        protected void onOpen() {
            open = true;
            games.incrementAndGet();
            poller = new Thread(this::loop, "mc-poll");
            poller.setDaemon(true);
            poller.start();
        }

        @Override
        protected void onClose(NanoWSD.WebSocketFrame.CloseCode code, String reason, boolean remote) {
            if (!open) return;
            open = false;
            games.decrementAndGet();
            if (poller != null) poller.interrupt();
        }

        @Override
        protected void onMessage(NanoWSD.WebSocketFrame frame) {
            try {
                JSONObject m = new JSONObject(frame.getTextPayload());
                JSONObject h = m.optJSONObject("header");
                if (h == null || !"commandResponse".equals(h.optString("messagePurpose"))) return;
                CompletableFuture<JSONObject> f = pending.remove(h.optString("requestId"));
                if (f != null) f.complete(m.optJSONObject("body") != null ? m.optJSONObject("body") : new JSONObject());
            } catch (Exception ignored) { }
        }

        @Override protected void onPong(NanoWSD.WebSocketFrame pong) { }
        @Override protected void onException(IOException e) { }

        private void fire(String line) {
            String id = UUID.randomUUID().toString();
            JSONObject req = o(
                    "header", o("version", 1, "requestId", id, "messageType", "commandRequest",
                            "messagePurpose", "commandRequest"),
                    "body", o("version", 1, "commandLine", line, "origin", o("type", "player")));
            try { this.send(req.toString()); } catch (Exception ignored) { }
        }

        private JSONObject cmd(String line, long ms) {
            String id = UUID.randomUUID().toString();
            CompletableFuture<JSONObject> f = new CompletableFuture<>();
            pending.put(id, f);
            JSONObject req = o(
                    "header", o("version", 1, "requestId", id, "messageType", "commandRequest",
                            "messagePurpose", "commandRequest"),
                    "body", o("version", 1, "commandLine", line, "origin", o("type", "player")));
            try {
                this.send(req.toString());
                return f.get(ms, TimeUnit.MILLISECONDS);
            } catch (Exception e) {
                pending.remove(id);
                return null;
            }
        }

        private List<String> parseNames(JSONObject b) {
            List<String> out = new ArrayList<>();
            if (b == null) return out;
            String s = b.optString("players", "");
            if (s.isEmpty() && b.has("statusMessage")) {
                String[] lines = b.optString("statusMessage").split("\n");
                s = lines[lines.length - 1];
            }
            for (String x : s.split("\\s*,\\s*")) {
                x = x.trim();
                if (!x.isEmpty()) out.add(x);
            }
            return out;
        }

        private void loop() {
            // คำสั่งไม่ต้องรอผล (ห้ามเรียกใน onOpen เพราะจะรอผลจากเธรดเดียวกัน)
            fire("gamerule sendcommandfeedback false");
            int tick = 0;
            while (open) {
                long t0 = System.currentTimeMillis();
                try { tick = poll(tick); } catch (Exception ignored) { }
                long wait = 500 - (System.currentTimeMillis() - t0);
                if (wait > 0) {
                    try { Thread.sleep(wait); } catch (InterruptedException e) { return; }
                }
            }
        }

        private int poll(int tick) {
            JSONObject lb = cmd("list", 1500);
            List<Player> list = new ArrayList<>();
            for (String name : parseNames(lb)) {
                JSONObject b = cmd("querytarget \"" + name.replace("\"", "") + "\"", 1500);
                if (b == null || !b.has("details")) continue;
                try {
                    JSONArray a = new JSONArray(b.optString("details"));
                    JSONObject p = a.optJSONObject(0);
                    if (p == null || p.optJSONObject("position") == null) continue;
                    JSONObject pos = p.getJSONObject("position");
                    double yaw = Math.toRadians(p.optDouble("yRot", 0));
                    Player pl = new Player();
                    pl.name = name;
                    pl.x = pos.optDouble("x"); pl.y = pos.optDouble("y"); pl.z = pos.optDouble("z");
                    pl.fx = -Math.sin(yaw); pl.fz = Math.cos(yaw);
                    pl.dim = p.has("dimension") ? String.valueOf(p.opt("dimension")) : "0";
                    list.add(pl);
                } catch (Exception ignored) { }
            }
            long now = System.currentTimeMillis();
            List<String[]> titles = new ArrayList<>();
            synchronized (lock) {
                java.util.Set<String> linked = new java.util.HashSet<>();
                for (Client c : clients.values()) linked.add(c.name);
                for (Player p : list) {
                    p.t = now;
                    players.put(p.name, p);
                    if (!linked.contains(p.name)) titles.add(new String[]{p.name, newCode(p.name)});
                }
            }
            if (tick % 3 == 0) {
                for (String[] t : titles)
                    fire("titleraw \"" + t[0] + "\" actionbar {\"rawtext\":[{\"text\":\"รหัสเสียง: " + t[1] + "\"}]}");
            }
            sendMix();
            return tick + 1;
        }
    }
}
