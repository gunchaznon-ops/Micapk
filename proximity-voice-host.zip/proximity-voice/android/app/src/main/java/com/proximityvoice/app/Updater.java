package com.proximityvoice.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/** ตรวจ/ดาวน์โหลด/ติดตั้งเวอร์ชันใหม่จาก GitHub Releases (repo ต้องเป็นสาธารณะ) */
final class Updater {
    static final String DEFAULT_REPO = "gunchaznon-ops/Micapk";

    private Updater() { }

    /** รับได้ทั้ง owner/repo และลิงก์เต็ม https://github.com/owner/repo(.git) ถ้าว่างใช้ค่าเริ่มต้น */
    static String repoOf(Context c) {
        String r = c.getSharedPreferences("pv", Context.MODE_PRIVATE).getString("updrepo", "").trim();
        r = r.replaceAll("^(https?://)?(www\\.)?github\\.com/", "").replaceAll("\\.git$", "").replaceAll("^/+|/+$", "");
        String[] p = r.split("/");
        if (p.length >= 2) r = p[0] + "/" + p[1];
        return r.isEmpty() || !r.contains("/") ? DEFAULT_REPO : r;
    }

    private static String get(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(8000); c.setReadTimeout(10000);
        c.setRequestProperty("Accept", "application/vnd.github+json");
        c.setRequestProperty("User-Agent", "ProximityVoice-Updater");
        int code = c.getResponseCode();
        if (code != 200) throw new java.io.FileNotFoundException("HTTP " + code);
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
            String l; while ((l = r.readLine()) != null) sb.append(l);
        }
        return sb.toString();
    }

    static long localVersion(Context c) {
        try { return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).getLongVersionCode(); }
        catch (Exception e) { return 0; }
    }

    /** manual=true จะบอกผลทุกกรณี / false จะเงียบถ้าไม่มีอะไรใหม่ (และเช็กไม่เกินวันละ 2 ครั้ง) */
    static void check(Activity a, boolean manual) {
        SharedPreferences sp = a.getSharedPreferences("pv", Context.MODE_PRIVATE);
        final String repo = repoOf(a);
        long now = System.currentTimeMillis();
        if (!manual && now - sp.getLong("updlast", 0) < 12 * 3600 * 1000L) return;
        sp.edit().putLong("updlast", now).apply();
        new Thread(() -> {
            try {
                JSONObject j;
                try {
                    j = new JSONObject(get("https://api.github.com/repos/" + repo + "/releases/latest"));
                } catch (java.io.FileNotFoundException nf) {
                    // บาง repo ไม่มี "latest" ลองเอารายการล่าสุดแทน
                    JSONArray arr = new JSONArray(get("https://api.github.com/repos/" + repo + "/releases?per_page=1"));
                    if (arr.length() == 0) throw new Exception("repo " + repo + " ยังไม่มี Release");
                    j = arr.getJSONObject(0);
                }
                String tag = j.optString("tag_name", "");
                long remote = Long.parseLong(tag.replaceAll("[^0-9]", ""));
                String apk = null;
                JSONArray as = j.optJSONArray("assets");
                for (int i = 0; as != null && i < as.length(); i++) {
                    String n = as.getJSONObject(i).optString("name");
                    if (n.endsWith(".apk")) { apk = as.getJSONObject(i).optString("browser_download_url"); break; }
                }
                final long local = localVersion(a);
                final String fapk = apk, ftag = tag;
                final long fr = remote;
                a.runOnUiThread(() -> {
                    if (a.isFinishing()) return;
                    if (fr <= local) {
                        if (manual) Toast.makeText(a, "เป็นเวอร์ชันล่าสุดแล้ว (build " + local + ")", Toast.LENGTH_SHORT).show();
                    } else if (fapk == null) {
                        if (manual) Toast.makeText(a, "พบเวอร์ชันใหม่ " + ftag + " แต่ไม่มีไฟล์ .apk ใน Release", Toast.LENGTH_LONG).show();
                    } else {
                        new AlertDialog.Builder(a)
                                .setTitle("มีเวอร์ชันใหม่")
                                .setMessage("เวอร์ชันของคุณ build " + local + "\nเวอร์ชันใหม่ " + ftag + "\n\nดาวน์โหลดและติดตั้งเลยไหม?")
                                .setPositiveButton("อัปเดต", (d, w) -> download(a, fapk, fr))
                                .setNegativeButton("ไว้ทีหลัง", null)
                                .show();
                    }
                });
            } catch (Exception e) {
                if (manual) a.runOnUiThread(() -> Toast.makeText(a, "ตรวจอัปเดตไม่ได้ (" + repo + "): " + e.getMessage() + "\nเช็กชื่อ repo ที่ตั้งค่า > อัปเดตแอปจาก GitHub", Toast.LENGTH_LONG).show());
            }
        }, "updater").start();
    }

    private static void download(Activity a, String url, long build) {
        if (Build.VERSION.SDK_INT >= 26 && !a.getPackageManager().canRequestPackageInstalls()) {
            Toast.makeText(a, "อนุญาต \"ติดตั้งแอปที่ไม่รู้จัก\" ให้แอปนี้ก่อน แล้วกดอัปเดตอีกครั้ง", Toast.LENGTH_LONG).show();
            a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.getPackageName())));
            return;
        }
        DownloadManager dm = (DownloadManager) a.getSystemService(Context.DOWNLOAD_SERVICE);
        DownloadManager.Request rq = new DownloadManager.Request(Uri.parse(url))
                .setTitle("Proximity Voice build " + build)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "ProximityVoice-" + build + ".apk");
        final long id = dm.enqueue(rq);
        Toast.makeText(a, "กำลังดาวน์โหลด... เสร็จแล้วจะเปิดตัวติดตั้งให้", Toast.LENGTH_LONG).show();
        final Context app = a.getApplicationContext();
        BroadcastReceiver rec = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                if (i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) != id) return;
                try { app.unregisterReceiver(this); } catch (Exception ignored) { }
                Uri u = dm.getUriForDownloadedFile(id);
                if (u == null) { Toast.makeText(app, "ดาวน์โหลดไม่สำเร็จ", Toast.LENGTH_LONG).show(); return; }
                app.startActivity(new Intent(Intent.ACTION_VIEW)
                        .setDataAndType(u, "application/vnd.android.package-archive")
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION));
            }
        };
        IntentFilter f = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(rec, f, Context.RECEIVER_EXPORTED);
        else app.registerReceiver(rec, f);
    }
}
