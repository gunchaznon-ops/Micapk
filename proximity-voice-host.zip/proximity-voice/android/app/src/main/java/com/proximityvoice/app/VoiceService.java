package com.proximityvoice.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

/** บริการเบื้องหลัง (แจ้งเตือน "ใช้ไมค์") + ปุ่มไมค์ลอย ทำให้ระบบไม่ตัดไมค์ตอนพับแอป */
public class VoiceService extends Service {
    private static final String CHANNEL = "voice";
    static VoiceService instance;

    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock wifiLock;
    private WindowManager wm;
    private TextView bubble;
    private WindowManager.LayoutParams lp;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean muted = false;

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (MainActivity.web != null) {
                MainActivity.web.evaluateJavascript(
                        "(typeof muted!=='undefined'&&muted)?'1':'0'", v -> setMuted(v != null && v.contains("1")));
            }
            h.postDelayed(this, 1000);
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(
                new NotificationChannel(CHANNEL, "Proximity Voice", NotificationManager.IMPORTANCE_LOW));

        PendingIntent openPi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent exitPi = PendingIntent.getActivity(this, 1,
                new Intent(this, MainActivity.class).putExtra("exit", true),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Proximity Voice")
                .setContentText("กำลังใช้ไมค์และฟังเสียงรอบตัว")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(openPi)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel, "ออก", exitPi).build())
                .build();

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(1, n);
        }

        if (wakeLock == null) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "proximityvoice:voice");
            wakeLock.acquire();
        }
        if (wifiLock == null) {
            try {
                WifiManager wf = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                wifiLock = wf.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "proximityvoice:wifi");
                wifiLock.acquire();
            } catch (Exception ignored) {
            }
        }
        applyBubble();
        return START_NOT_STICKY;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void setMuted(boolean m) {
        muted = m;
        if (bubble == null) return;
        bubble.setText(m ? "\uD83D\uDD07" : "\uD83C\uDF99");
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(m ? Color.parseColor("#E5484D") : Color.parseColor("#2E9B4F"));
        bubble.setBackground(g);
    }

    private void toggleFromBubble() {
        if (MainActivity.web == null) return;
        MainActivity.web.evaluateJavascript(
                "(function(){if(typeof stream==='undefined'||!stream)return '0';toggleMute();return muted?'1':'0'})()",
                v -> setMuted(v != null && v.contains("1")));
    }

    private void removeBubble() {
        h.removeCallbacks(poll);
        if (bubble != null && wm != null) {
            try { wm.removeView(bubble); } catch (Exception ignored) { }
        }
        bubble = null;
    }

    /** สร้าง/ลบปุ่มไมค์ลอยตามค่าที่ตั้งไว้ (เรียกซ้ำได้ทุกครั้งที่ตั้งค่าเปลี่ยน) */
    void applyBubble() {
        SharedPreferences sp = getSharedPreferences("pv", MODE_PRIVATE);
        removeBubble();
        boolean want = sp.getBoolean("bubble", false)
                && Settings.canDrawOverlays(this)
                && !(sp.getBoolean("hideInApp", false) && MainActivity.visible);
        if (!want) return;

        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        bubble = new TextView(this);
        bubble.setGravity(Gravity.CENTER);
        bubble.setTextSize(Math.max(12, sp.getInt("bsize", 40) / 3));
        bubble.setAlpha(sp.getInt("balpha", 85) / 100f);
        setMuted(muted);
        int size = dp(sp.getInt("bsize", 40));
        lp = new WindowManager.LayoutParams(size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = sp.getInt("bx", dp(8));
        lp.y = sp.getInt("by", dp(160));
        final TextView b = bubble;
        b.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int sx, sy; boolean moved;
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = e.getRawX(); dy = e.getRawY(); sx = lp.x; sy = lp.y; moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX() - dx) > dp(8) || Math.abs(e.getRawY() - dy) > dp(8)) moved = true;
                        if (moved) {
                            lp.x = sx + (int) (e.getRawX() - dx);
                            lp.y = sy + (int) (e.getRawY() - dy);
                            try { wm.updateViewLayout(b, lp); } catch (Exception ignored) { }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) sp.edit().putInt("bx", lp.x).putInt("by", lp.y).apply();
                        else toggleFromBubble();
                        return true;
                }
                return false;
            }
        });
        try {
            wm.addView(b, lp);
            h.post(poll);
        } catch (Exception ex) {
            bubble = null;
        }
    }

    @Override
    public void onDestroy() {
        removeBubble();
        instance = null;
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        super.onDestroy();
    }
}
