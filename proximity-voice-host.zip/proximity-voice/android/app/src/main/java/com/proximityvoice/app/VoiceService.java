package com.proximityvoice.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** บริการเบื้องหลัง (แจ้งเตือน "ใช้ไมค์") + ปุ่มไมค์ลอย ทำให้ระบบไม่ตัดไมค์ตอนพับแอป */
public class VoiceService extends Service {
    private static final String CHANNEL = "voice";
    static VoiceService instance;

    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock wifiLock;
    private WindowManager wm;
    private TextView bubble;
    private WindowManager.LayoutParams lp;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean muted = false;

    /** ปุ่มควรมีอยู่ไหม (ตามค่าตั้ง + ไม่ซ่อนตอนอยู่ในแอป + มีสิทธิ์) */
    private boolean wantBubbles() {
        SharedPreferences sp = getSharedPreferences("pv", MODE_PRIVATE);
        boolean any = false;
        for (String k : KEY) any |= sp.getBoolean(k, false);
        boolean hide = sp.getBoolean("hideInApp", true) && App.foreground;
        return any && !hide && Settings.canDrawOverlays(this);
    }

    /** ตรวจทุก 2 วินาที: ถ้าปุ่มควรมีแต่หาย/หลุดจากหน้าจอ ให้สร้างใหม่เอง (ไม่ต้องรอใครสั่ง) */
    private final Runnable heal = new Runnable() {
        @Override public void run() {
            try {
                boolean want = wantBubbles(), have = !overlays.isEmpty();
                boolean attached = true;
                for (View v : overlays) if (!v.isAttachedToWindow()) attached = false;
                if ((want && (!have || !attached)) || (!want && have)) applyBubble();
            } catch (Exception ignored) { }
            h.postDelayed(this, 2000);
        }
    };

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (MainActivity.web != null) {
                MainActivity.web.evaluateJavascript(
                        "(typeof muted!=='undefined'&&muted)?'1':'0'", v -> setMuted(v != null && v.contains("1")));
            }
            h.postDelayed(this, 1000);
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_TOGGLE.equals(intent.getAction())) {   // ปุ่ม "ปิด/เปิดไมค์" ในแถบแจ้งเตือน
            toggleFromBubble();
            return START_NOT_STICKY;
        }
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(
                new NotificationChannel(CHANNEL, "Proximity Voice", NotificationManager.IMPORTANCE_LOW));

        Notification n = buildNote();

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(1, n);
        }

        if (wakeLock == null) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "proximityvoice:voice");
            wakeLock.acquire();
        }
        if (wifiLock == null) {
            try {
                WifiManager wf = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                wifiLock = wf.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "proximityvoice:wifi");
                wifiLock.acquire();
            } catch (Exception ignored) {
            }
        }
        applyBubble();
        h.removeCallbacks(heal);
        h.postDelayed(heal, 2000);
        return START_NOT_STICKY;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static final String ACTION_TOGGLE = "com.proximityvoice.app.TOGGLE_MIC";

    private Notification buildNote() {
        PendingIntent openPi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent exitPi = PendingIntent.getActivity(this, 1,
                new Intent(this, MainActivity.class).putExtra("exit", true),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent togglePi = PendingIntent.getService(this, 3,
                new Intent(this, VoiceService.class).setAction(ACTION_TOGGLE),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("Proximity Voice")
                .setContentText(muted ? "🔇 ไมค์ปิดอยู่" : "🎙 ไมค์เปิดอยู่ · กำลังฟังเสียงรอบตัว")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(openPi)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_lock_silent_mode, muted ? "เปิดไมค์" : "ปิดไมค์", togglePi).build())
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel, "ออก", exitPi).build())
                .build();
    }

    private void setMuted(boolean m) {
        boolean changed = muted != m;
        muted = m;
        if (changed) {
            try { getSystemService(NotificationManager.class).notify(1, buildNote()); } catch (Exception ignored) { }
        }
        if (bubble == null) return;
        bubble.setText(m ? "\uD83D\uDD07" : "\uD83C\uDF99");
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(m ? Color.parseColor("#E5484D") : Color.parseColor("#2E9B4F"));
        bubble.setBackground(g);
    }

    private void toggleFromBubble() {
        if (MainActivity.web == null) return;
        MainActivity.web.evaluateJavascript(
                "(function(){if(typeof stream==='undefined'||!stream)return '0';toggleMute();return muted?'1':'0'})()",
                v -> setMuted(v != null && v.contains("1")));
    }

    // ---------- ปุ่มลอย: ปิด/เปิดไมค์ + ตะโกน + กดค้างพูด ----------
    private final List<View> overlays = new ArrayList<>();
    // 0 ปิด/เปิดไมค์, 1 ตะโกน, 2 กดค้างพูด, 3 กระซิบ, 4 วิทยุทีม
    private final TextView[] btns = new TextView[5];
    private final boolean[] down = new boolean[5];
    private static final String[] JS = {null, "pvShout", "pvPtt", "pvWhisper", "pvRadio"};
    private static final String[] EMOJI = {"\uD83C\uDF99", "\uD83D\uDCE2", "\uD83C\uDFA4", "\uD83E\uDD2B", "\uD83D\uDCFB"};
    private static final String[] COLOR = {"#2E9B4F", "#F59E0B", "#3B82F6", "#64748B", "#10B981"};
    private static final String[] COLOR_ON = {"#2E9B4F", "#EF4444", "#60A5FA", "#94A3B8", "#34D399"};
    private static final String[] KEY = {"bubble", "bubbleShout", "bubblePtt", "bubbleWhisper", "bubbleRadio"};

    private void js(String code) {
        if (MainActivity.web != null) MainActivity.web.evaluateJavascript(code, null);
    }

    /** kind 1-4 = ปุ่มกดค้าง */
    private void hold(int kind, boolean on) {
        if (kind <= 0 || down[kind] == on) return;
        down[kind] = on;
        js("window." + JS[kind] + "&&" + JS[kind] + "(" + on + ")");
        paint(btns[kind], on ? COLOR_ON[kind] : COLOR[kind], on);
    }

    private void paint(TextView b, String color, boolean big) {
        if (b == null) return;
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(Color.parseColor(color));
        g.setStroke(dp(2), 0x66FFFFFF);
        b.setBackground(g);
        b.setScaleX(big ? 1.18f : 1f);
        b.setScaleY(big ? 1.18f : 1f);
    }

    private TextView makeBtn(int kind, int size, float alpha) {
        TextView t = new TextView(this);
        t.setGravity(Gravity.CENTER);
        t.setText(EMOJI[kind]);
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, size * 0.5f);   // อีโมจิพอดีวงกลม ไม่ล้นขอบ
        t.setIncludeFontPadding(false);
        t.setPadding(0, 0, 0, 0);
        t.setAlpha(alpha);
        paint(t, COLOR[kind], false);
        return t;
    }

    private WindowManager.LayoutParams params(int w, int h, int x, int y) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        p.x = x;
        p.y = y;
        return p;
    }

    /** kind 0 = แตะสลับไมค์ / 1,2 = กดค้าง (ลากไกลๆ เพื่อย้ายตำแหน่ง) */
    private void wire(final TextView btn, final View target, final WindowManager.LayoutParams p,
                      final String kx, final String ky, final int kind, final SharedPreferences sp) {
        btn.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int sx, sy; boolean moved, holding;
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                int a = e.getAction();
                if (a == MotionEvent.ACTION_DOWN) {
                    dx = e.getRawX(); dy = e.getRawY(); sx = p.x; sy = p.y; moved = false;
                    if (kind != 0) {
                        holding = true;
                        v.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
                        hold(kind, true);
                    }
                    return true;
                }
                if (a == MotionEvent.ACTION_MOVE) {
                    float th = dp(kind == 0 ? 8 : 24);
                    if (!moved && (Math.abs(e.getRawX() - dx) > th || Math.abs(e.getRawY() - dy) > th)) {
                        moved = true;
                        if (holding) { holding = false; hold(kind, false); }
                    }
                    if (moved) {
                        p.x = sx + (int) (e.getRawX() - dx);
                        p.y = sy + (int) (e.getRawY() - dy);
                        try { wm.updateViewLayout(target, p); } catch (Exception ignored) { }
                    }
                    return true;
                }
                if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    if (holding) { holding = false; hold(kind, false); }
                    if (moved) sp.edit().putInt(kx, p.x).putInt(ky, p.y).apply();
                    else if (kind == 0 && a == MotionEvent.ACTION_UP) toggleFromBubble();
                    return true;
                }
                return false;
            }
        });
    }

    private void removeBubble() {
        h.removeCallbacks(poll);
        for (int k = 1; k < 5; k++) if (down[k]) hold(k, false);
        for (View v : overlays) {
            try { wm.removeView(v); } catch (Exception ignored) { }
        }
        overlays.clear();
        for (int k = 0; k < 5; k++) btns[k] = null;
        bubble = null;
    }

    /** สร้าง/ลบปุ่มลอยตามค่าที่ตั้งไว้ (เรียกซ้ำได้ทุกครั้งที่ตั้งค่าเปลี่ยน) */
    void applyBubble() {
        SharedPreferences sp = getSharedPreferences("pv", MODE_PRIVATE);
        removeBubble();
        boolean any = false;
        for (String k : KEY) any |= sp.getBoolean(k, false);
        boolean hide = sp.getBoolean("hideInApp", true) && App.foreground;
        if (!any || hide || !Settings.canDrawOverlays(this)) return;

        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        int size = dp(sp.getInt("bsize", 40));
        float alpha = sp.getInt("balpha", 85) / 100f;
        int x0 = sp.getInt("bx", dp(8)), y0 = sp.getInt("by", dp(160)), gap = dp(8);
        boolean attach = sp.getBoolean("bubbleAttach", true);
        for (int k = 0; k < 5; k++) if (sp.getBoolean(KEY[k], false)) btns[k] = makeBtn(k, size, alpha);
        bubble = btns[0];
        setMuted(muted);
        String[] kx = {"bx", "sx", "px", "wx", "rx"}, ky = {"by", "sy", "py", "wy", "ry"};

        try {
            if (attach) {
                // รวมเป็นแถบเดียว ลากทีเดียวขยับทุกปุ่ม
                LinearLayout bar = new LinearLayout(this);
                bar.setOrientation(LinearLayout.HORIZONTAL);
                WindowManager.LayoutParams p = params(WindowManager.LayoutParams.WRAP_CONTENT,
                        WindowManager.LayoutParams.WRAP_CONTENT, x0, y0);
                int n = 0;
                for (int k = 0; k < 5; k++) {
                    if (btns[k] == null) continue;
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
                    if (n++ > 0) lp.setMargins(gap, 0, 0, 0);
                    bar.addView(btns[k], lp);
                    wire(btns[k], bar, p, "bx", "by", k, sp);
                }
                wm.addView(bar, p);
                overlays.add(bar);
            } else {
                int idx = 0;
                for (int k = 0; k < 5; k++) {
                    if (btns[k] == null) continue;
                    WindowManager.LayoutParams p = params(size, size,
                            sp.getInt(kx[k], x0 + idx * (size + gap)), sp.getInt(ky[k], y0));   // ค่าเริ่มต้น: เรียงเป็นแถวไม่ทับกัน
                    wire(btns[k], btns[k], p, kx[k], ky[k], k, sp);
                    wm.addView(btns[k], p);
                    overlays.add(btns[k]);
                    idx++;
                }
            }
            h.post(poll);
        } catch (Exception ex) {
            removeBubble();
        }
    }

    @Override
    public void onDestroy() {
        h.removeCallbacks(heal);
        removeBubble();
        instance = null;
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        super.onDestroy();
    }
}
