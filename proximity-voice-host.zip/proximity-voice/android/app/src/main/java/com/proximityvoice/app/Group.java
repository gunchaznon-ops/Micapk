package com.proximityvoice.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** ระบบกลุ่ม: เก็บค่าในเครื่อง + ใช้ ntfy.sh เป็นกระดานกลางบอกว่าใครเป็นโฮสต์ (ไม่ต้องมีเซิร์ฟเวอร์เอง) */
final class Group {
    static final String CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    static final long ACTIVE_MS = 11 * 60 * 1000;   // โฮสต์ส่งสัญญาณทุก 5 นาที ถ้าเงียบเกิน 11 นาทีถือว่าหลุด
    static final long BEAT_MS = 5 * 60 * 1000;
    private static final String BASE = "https://ntfy.sh/pvgrp-";

    private Group() { }

    // ---------- ค่าในเครื่อง ----------
    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("pv", Context.MODE_PRIVATE); }
    static String id(Context c) { return sp(c).getString("gid", null); }
    static void setId(Context c, String v) {
        SharedPreferences.Editor e = sp(c).edit();
        if (v == null) e.remove("gid"); else e.putString("gid", v);
        e.apply();
    }
    static String name(Context c) { return sp(c).getString("pname", null); }
    static void setName(Context c, String v) { sp(c).edit().putString("pname", v).apply(); }
    static boolean auto(Context c) { return sp(c).getBoolean("gauto", true); }
    static void setAuto(Context c, boolean v) { sp(c).edit().putBoolean("gauto", v).apply(); }
    static String device(Context c) {
        String d = sp(c).getString("gdev", null);
        if (d == null) {
            d = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
            sp(c).edit().putString("gdev", d).apply();
        }
        return d;
    }

    static String newId() {
        Random r = new java.security.SecureRandom();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) sb.append(CHARS.charAt(r.nextInt(CHARS.length())));
        return sb.toString();
    }

    static String normalize(String s) { return s == null ? "" : s.trim().toUpperCase().replace("O", "0").replace("I", "1"); }
    static boolean valid(String s) { return s != null && s.matches("[A-HJ-NP-Z2-9]{6}"); }

    // ---------- กระดานกลาง ----------
    static final class Host {
        String name, url, dev, claim;
        long time, claimStart;
    }

    /** คืนโฮสต์ที่ยัง active ของกลุ่ม (ถ้ามีหลายคนชนกัน เลือกคนที่เริ่มก่อน) หรือ null ถ้าไม่มี */
    static Host current(String gid) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(BASE + gid.toLowerCase() + "/json?poll=1&since=15m").openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(10000);
        int code = c.getResponseCode();
        if (code != 200) throw new IOException("HTTP " + code);
        long now = c.getHeaderFieldDate("Date", 0);
        if (now == 0) now = System.currentTimeMillis();
        Map<String, Host> byDev = new LinkedHashMap<>();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
            String line;
            while ((line = r.readLine()) != null) {
                try {
                    JSONObject e = new JSONObject(line);
                    if (!"message".equals(e.optString("event"))) continue;
                    long t = e.optLong("time") * 1000;
                    JSONObject m = new JSONObject(e.optString("message"));
                    String dev = m.optString("dev"), claim = m.optString("claim");
                    if ("host".equals(m.optString("t"))) {
                        Host h = byDev.get(dev);
                        if (h == null || !h.claim.equals(claim)) {
                            h = new Host();
                            h.claimStart = t;
                            h.dev = dev;
                            h.claim = claim;
                            byDev.put(dev, h);
                        }
                        h.time = t;
                        h.name = m.optString("name");
                        h.url = m.optString("url");
                    } else if ("stop".equals(m.optString("t"))) {
                        Host h = byDev.get(dev);
                        if (h != null && h.claim.equals(claim)) byDev.remove(dev);
                    }
                } catch (Exception ignored) { }
            }
        }
        List<Host> act = new ArrayList<>();
        for (Host h : byDev.values()) if (now - h.time <= ACTIVE_MS && h.url != null && !h.url.isEmpty()) act.add(h);
        Host best = null;
        for (Host h : act)
            if (best == null || h.claimStart < best.claimStart
                    || (h.claimStart == best.claimStart && h.dev.compareTo(best.dev) < 0)) best = h;
        return best;
    }

    private static void post(String gid, JSONObject body) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(BASE + gid.toLowerCase()).openConnection();
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setConnectTimeout(8000);
        c.setReadTimeout(10000);
        c.setRequestProperty("Content-Type", "text/plain; charset=utf-8");
        try (OutputStream o = c.getOutputStream()) { o.write(body.toString().getBytes("UTF-8")); }
        int code = c.getResponseCode();
        if (code != 200) throw new IOException("HTTP " + code);
        c.getInputStream().close();
    }

    static void publishHost(String gid, String name, String url, String dev, String claim) throws IOException {
        try {
            post(gid, new JSONObject().put("t", "host").put("name", name).put("url", url).put("dev", dev).put("claim", claim));
        } catch (org.json.JSONException e) { throw new IOException(e); }
    }

    static void publishStop(String gid, String dev, String claim) throws IOException {
        try {
            post(gid, new JSONObject().put("t", "stop").put("dev", dev).put("claim", claim));
        } catch (org.json.JSONException e) { throw new IOException(e); }
    }
}
