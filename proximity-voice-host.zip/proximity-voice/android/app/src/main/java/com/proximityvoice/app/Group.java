package com.proximityvoice.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** ระบบกลุ่ม: เก็บรายการกลุ่มในเครื่อง + ใช้ ntfy.sh เป็นกระดานกลาง (โฮสต์ / สมาชิก / ชื่อกลุ่ม) */
final class Group {
    static final int MAX = 3;                        // สร้าง/เข้าร่วมได้สูงสุด 3 กลุ่ม
    static final String CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    static final long ACTIVE_MS = 11 * 60 * 1000;    // เงียบเกิน 11 นาที = ไม่ออนไลน์
    static final long BEAT_MS = 5 * 60 * 1000;       // ส่งสัญญาณทุก 5 นาที
    private static final String BASE = "https://ntfy.sh/pvgrp-";

    private Group() { }

    // ====================== ค่าในเครื่อง ======================
    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("pv", Context.MODE_PRIVATE); }

    static final class G {
        String id, title;
        boolean own;
        String label() { return (title == null || title.isEmpty()) ? "กลุ่ม " + id : title; }
    }

    static List<G> list(Context c) {
        List<G> out = new ArrayList<>();
        try {
            String raw = sp(c).getString("groups", null);
            JSONArray a = new JSONArray(raw == null ? "[]" : raw);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                G g = new G();
                g.id = o.getString("id");
                g.title = o.optString("title", "");
                g.own = o.optBoolean("own");
                out.add(g);
            }
        } catch (Exception ignored) { }
        String legacy = sp(c).getString("gid", null);   // รุ่นเก่าที่มีกลุ่มเดียว
        if (out.isEmpty() && legacy != null && valid(legacy)) {
            G g = new G(); g.id = legacy; g.title = ""; g.own = false;
            out.add(g);
            save(c, out);
        }
        return out;
    }

    private static void save(Context c, List<G> l) {
        JSONArray a = new JSONArray();
        try {
            for (G g : l) a.put(new JSONObject().put("id", g.id).put("title", g.title == null ? "" : g.title).put("own", g.own));
        } catch (Exception ignored) { }
        sp(c).edit().putString("groups", a.toString()).apply();
    }

    static boolean any(Context c) { return !list(c).isEmpty(); }

    static G find(Context c, String id) {
        for (G g : list(c)) if (g.id.equals(id)) return g;
        return null;
    }

    /** false ถ้าเต็ม 3 กลุ่มแล้ว (กลุ่มที่มีอยู่แล้วถือว่าสำเร็จ) */
    static boolean add(Context c, String id, String title, boolean own) {
        List<G> l = list(c);
        for (G g : l) if (g.id.equals(id)) return true;
        if (l.size() >= MAX) return false;
        G g = new G(); g.id = id; g.title = title == null ? "" : title; g.own = own;
        l.add(g);
        save(c, l);
        return true;
    }

    static void remove(Context c, String id) {
        List<G> l = list(c);
        for (int i = 0; i < l.size(); i++) if (l.get(i).id.equals(id)) { l.remove(i); break; }
        save(c, l);
        if (id.equals(sp(c).getString("gid", null))) {
            if (l.isEmpty()) sp(c).edit().remove("gid").apply();
            else sp(c).edit().putString("gid", l.get(0).id).apply();
        }
    }

    static void setTitle(Context c, String id, String title) {
        List<G> l = list(c);
        for (G g : l) if (g.id.equals(id)) g.title = title == null ? "" : title;
        save(c, l);
    }

    /** กลุ่มที่เปิดดูล่าสุด (null ถ้าไม่มีกลุ่ม) */
    static String id(Context c) {
        String cur = sp(c).getString("gid", null);
        if (cur != null && find(c, cur) != null) return cur;
        List<G> l = list(c);
        return l.isEmpty() ? null : l.get(0).id;
    }
    static void setCurrent(Context c, String id) { sp(c).edit().putString("gid", id).apply(); }

    static String name(Context c) { return sp(c).getString("pname", null); }
    static void setName(Context c, String v) { sp(c).edit().putString("pname", v).apply(); }
    static boolean auto(Context c) { return sp(c).getBoolean("gauto", true); }
    static void setAuto(Context c, boolean v) { sp(c).edit().putBoolean("gauto", v).apply(); }
    static String device(Context c) {
        String d = sp(c).getString("gdev", null);
        if (d == null) {
            d = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
            sp(c).edit().putString("gdev", d).apply();
        }
        return d;
    }

    static String newId() {
        Random r = new java.security.SecureRandom();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) sb.append(CHARS.charAt(r.nextInt(CHARS.length())));
        return sb.toString();
    }
    static String normalize(String s) { return s == null ? "" : s.trim().toUpperCase().replace("O", "0").replace("I", "1"); }
    static boolean valid(String s) { return s != null && s.matches("[A-HJ-NP-Z2-9]{6}"); }

    // ====================== กระดานกลาง (ntfy) ======================
    static final class Host { String name, url, dev, claim; long time, claimStart; }
    static final class Member { String dev, name; long seen; }
    static final class Snap {
        Host host;
        List<Member> members = new ArrayList<>();
        String title = "";
        long now;
    }

    /** โฮสต์ที่ยัง active ของกลุ่ม (ใช้ตอนเช็กก่อนสร้างเซิร์ฟเวอร์) */
    static Host current(String gid) throws IOException { return snapshot(gid, "15m").host; }

    /** อ่านกระดานกลุ่ม: โฮสต์ สมาชิก และชื่อกลุ่ม ({since} เช่น 15m, 12h) */
    static Snap snapshot(String gid, String since) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(BASE + gid.toLowerCase() + "/json?poll=1&since=" + since).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(10000);
        int code = c.getResponseCode();
        if (code != 200) throw new IOException("HTTP " + code);
        long now = c.getHeaderFieldDate("Date", 0);
        if (now == 0) now = System.currentTimeMillis();
        Map<String, Host> hosts = new LinkedHashMap<>();
        Map<String, Member> mem = new LinkedHashMap<>();
        String ownerTitle = "", anyTitle = "";
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
            String line;
            while ((line = r.readLine()) != null) {
                try {
                    JSONObject e = new JSONObject(line);
                    if (!"message".equals(e.optString("event"))) continue;
                    long t = e.optLong("time") * 1000;
                    JSONObject m = new JSONObject(e.optString("message"));
                    String type = m.optString("t"), dev = m.optString("dev"), claim = m.optString("claim");
                    String gn = m.optString("gn", "");
                    if (!gn.isEmpty()) { anyTitle = gn; if (m.optBoolean("own")) ownerTitle = gn; }
                    if ("host".equals(type)) {
                        Host h = hosts.get(dev);
                        if (h == null || !h.claim.equals(claim)) {
                            h = new Host(); h.claimStart = t; h.dev = dev; h.claim = claim;
                            hosts.put(dev, h);
                        }
                        h.time = t; h.name = m.optString("name"); h.url = m.optString("url");
                    } else if ("stop".equals(type)) {
                        Host h = hosts.get(dev);
                        if (h != null && h.claim.equals(claim)) hosts.remove(dev);
                    }
                    if ("host".equals(type) || "here".equals(type)) {
                        Member mb = mem.get(dev);
                        if (mb == null) { mb = new Member(); mb.dev = dev; mem.put(dev, mb); }
                        mb.name = m.optString("name"); mb.seen = t;
                    } else if ("leave".equals(type)) {
                        mem.remove(dev);
                    }
                } catch (Exception ignored) { }
            }
        }
        Snap s = new Snap();
        s.now = now;
        s.title = !ownerTitle.isEmpty() ? ownerTitle : anyTitle;
        for (Host h : hosts.values()) {
            if (now - h.time > ACTIVE_MS || h.url == null || h.url.isEmpty()) continue;
            Host b = s.host;
            if (b == null || h.claimStart < b.claimStart || (h.claimStart == b.claimStart && h.dev.compareTo(b.dev) < 0)) s.host = h;
        }
        s.members.addAll(mem.values());
        Collections.sort(s.members, (a, b) -> Long.compare(b.seen, a.seen));
        return s;
    }

    private static void post(String gid, JSONObject body) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(BASE + gid.toLowerCase()).openConnection();
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setConnectTimeout(8000);
        c.setReadTimeout(10000);
        c.setRequestProperty("Content-Type", "text/plain; charset=utf-8");
        try (OutputStream o = c.getOutputStream()) { o.write(body.toString().getBytes("UTF-8")); }
        int code = c.getResponseCode();
        if (code != 200) throw new IOException("HTTP " + code);
        c.getInputStream().close();
    }

    private static JSONObject base(Context c, String gid, String type, String name, String dev) throws org.json.JSONException {
        G g = find(c, gid);
        return new JSONObject().put("t", type).put("dev", dev).put("name", name)
                .put("gn", g == null ? "" : (g.title == null ? "" : g.title)).put("own", g != null && g.own);
    }

    /** "ฉันอยู่ในกลุ่มนี้" (ใช้ทำรายชื่อสมาชิก + กระจายชื่อกลุ่ม) */
    static void publishHere(Context c, String gid) throws IOException {
        try { post(gid, base(c, gid, "here", name(c) == null ? "Player" : name(c), device(c))); }
        catch (org.json.JSONException e) { throw new IOException(e); }
    }

    static void publishLeave(Context c, String gid) throws IOException {
        try { post(gid, new JSONObject().put("t", "leave").put("dev", device(c))); }
        catch (org.json.JSONException e) { throw new IOException(e); }
    }

    static void publishHost(Context c, String gid, String name, String url, String dev, String claim) throws IOException {
        try { post(gid, base(c, gid, "host", name, dev).put("url", url).put("claim", claim)); }
        catch (org.json.JSONException e) { throw new IOException(e); }
    }

    static void publishStop(String gid, String dev, String claim) throws IOException {
        try { post(gid, new JSONObject().put("t", "stop").put("dev", dev).put("claim", claim)); }
        catch (org.json.JSONException e) { throw new IOException(e); }
    }
}
