package com.proximityvoice.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** หน้าตั้งค่า: ทางลัดฟังก์ชันหลักอยู่บนสุด ที่เหลือจัดเป็นหมวด */
public class SettingsActivity extends Activity {
    private static final int REQ_MIC = 10, REQ_NOTI = 11, REQ_ALL = 12;
    private static final int BG = Color.parseColor("#161B18"), CARD = Color.parseColor("#1F2622"),
            LINE = Color.parseColor("#2B352F"), FG = Color.parseColor("#E8EFE9"),
            MUT = Color.parseColor("#8FA196"), AC = Color.parseColor("#5FBF86"), WARN = Color.parseColor("#F5C518");
    private SharedPreferences sp;
    private LinearLayout box;
    private TextView stMic, stOv, stBat, stNoti, setupHint;

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("pv", MODE_PRIVATE);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(24), dp(16), dp(40));
        sv.addView(box);
        setContentView(sv);

        text("ตั้งค่า", 28, FG, true);

        // ---------- ทางลัด ----------
        LinearLayout r1 = tileRow();
        tile(r1, "\uD83D\uDC65", "กลุ่มเสียง", "สร้าง / เข้าร่วม / โฮสต์", () -> startActivity(new Intent(this, GroupActivity.class)));
        tile(r1, "\uD83D\uDDA5", "เซิร์ฟเวอร์", "สร้างเองไม่ต้องมีกลุ่ม", () -> startActivity(new Intent(this, HostActivity.class)));
        LinearLayout r2 = tileRow();
        tile(r2, "\uD83D\uDD17", "ที่อยู่เซิร์ฟเวอร์", "ใส่ลิงก์เอง", this::askUrl);
        tile(r2, "\u23FB", "ออกจากแอป", "ปิดไมค์และเซิร์ฟเวอร์", () -> {
            startActivity(new Intent(this, MainActivity.class).putExtra("exit", true));
            finish();
        });

        // ---------- สิทธิ์ ----------
        section("สิทธิ์ที่ต้องมี");
        LinearLayout perms = group();
        stMic = perm(perms, "\uD83C\uDF99", "ไมค์", "จำเป็นเมื่อจะเข้าร่วมเสียง", () ->
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC));
        stNoti = perm(perms, "\uD83D\uDD14", "การแจ้งเตือน", "แสดงสถานะไมค์/เซิร์ฟเวอร์ในแถบแจ้งเตือน", () -> {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTI);
        });
        stBat = perm(perms, "\uD83D\uDD0B", "ไม่จำกัดแบตเตอรี่", "กันระบบตัดไมค์/เซิร์ฟเวอร์เมื่อพับแอป (สำคัญ)", this::askBattery);
        stOv = perm(perms, "\uD83E\uDEA7", "แสดงทับแอปอื่น", "สำหรับปุ่มไมค์ลอยตอนเล่นเกม", () -> startActivity(new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))));
        setupHint = text("", 12, MUT, false);
        setupHint.setPadding(dp(4), dp(6), 0, 0);
        Button all = bigButton("ตั้งค่าให้ครบในครั้งเดียว", this::setupAll);

        // ---------- ปุ่มไมค์ลอย ----------
        section("ปุ่มไมค์ลอย");
        LinearLayout fl = group();
        sw(fl, "\uD83C\uDFAF", "เปิดปุ่มไมค์ลอย", "แตะ = ปิด/เปิดไมค์ ลาก = ย้าย", "bubble", false, on -> {
            if (on && !Settings.canDrawOverlays(this)) startActivity(new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        });
        seek(fl, "ขนาดปุ่ม", "bsize", 30, 80, 40, "dp");
        seek(fl, "ความโปร่งใส (ยิ่งมากยิ่งชัด)", "balpha", 30, 100, 85, "%");
        sw(fl, "\uD83D\uDE48", "ซ่อนปุ่มเมื่ออยู่ในแอป", "จะโผล่เฉพาะตอนอยู่แอปอื่น เช่น เกม", "hideInApp", false, null);

        // ---------- ทำงานเบื้องหลัง ----------
        section("การทำงานเบื้องหลัง");
        LinearLayout bg = group();
        sw(bg, "\uD83D\uDD04", "ทำงานเบื้องหลังต่อเนื่อง", "ให้ไมค์ทำงานตอนพับแอป (แนะนำเปิด)", "keepalive", true, on -> {
            if (!on) stopService(new Intent(this, VoiceService.class));
            else if (hasMic()) try { startForegroundService(new Intent(this, VoiceService.class)); } catch (Exception ignored) { }
        });
        sw(bg, "\uD83D\uDCA1", "กันจอดับ", "จอไม่ดับตอนเปิดแอปอยู่", "screenOn", true, null);
        sw(bg, "\uD83E\uDE9F", "ย่อเป็นหน้าต่างลอยเมื่อกดโฮม", "แสดงแถบวัดเสียงลอยเล็กๆ", "pip", true, null);

        // ---------- ระบบ ----------
        section("ระบบ");
        LinearLayout sys = group();
        nav(sys, "\u2699", "ตั้งค่าแอปของระบบ", "สิทธิ์ทั้งหมด / ล้างข้อมูล", () -> startActivity(new Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))));
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean mic = hasMic(), ov = Settings.canDrawOverlays(this);
        boolean bat = ((PowerManager) getSystemService(POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName());
        boolean noti = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        status(stMic, mic); status(stOv, ov); status(stBat, bat); status(stNoti, noti);
        int missing = (mic ? 0 : 1) + (bat ? 0 : 1) + (noti ? 0 : 1);   // ปุ่มลอยเป็นของเสริม ไม่นับ
        setupHint.setText(missing == 0 ? "✓ สิทธิ์สำคัญครบแล้ว" : "ยังขาด " + missing + " อย่างที่แนะนำ แตะที่รายการ หรือกดปุ่มด้านล่าง");
        setupHint.setTextColor(missing == 0 ? AC : WARN);
        if (VoiceService.instance != null) VoiceService.instance.applyBubble();
    }

    @Override
    public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        super.onRequestPermissionsResult(c, p, r);
        onResume();
        if (c == REQ_ALL) askBatteryIfNeeded();
    }

    private boolean hasMic() { return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED; }

    /** ขอไมค์ + แจ้งเตือนพร้อมกัน แล้วต่อด้วยแบตเตอรี่ */
    private void setupAll() {
        List<String> need = new ArrayList<>();
        if (!hasMic()) need.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ_ALL);
        else askBatteryIfNeeded();
    }

    private void askBatteryIfNeeded() {
        if (!((PowerManager) getSystemService(POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName())) askBattery();
    }

    private void askBattery() {
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }

    private void askUrl() {
        EditText et = new EditText(this);
        et.setText(sp.getString("url", ""));
        new AlertDialog.Builder(this).setTitle("ที่อยู่เซิร์ฟเวอร์เสียง").setView(et)
                .setPositiveButton("บันทึก", (d, w) -> {
                    String u = et.getText().toString().trim();
                    if (!u.isEmpty()) sp.edit().putString("url", u).apply();
                })
                .setNegativeButton("ยกเลิก", null).show();
    }

    // ---------- ตัวช่วยสร้าง UI ----------
    private GradientDrawable round(int color, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(r));
        g.setColor(color);
        return g;
    }

    private TextView text(String t, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(size); v.setTextColor(color);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        box.addView(v);
        return v;
    }

    private void section(String t) {
        TextView v = text(t, 13, AC, true);
        v.setPadding(dp(4), dp(24), 0, dp(8));
    }

    private LinearLayout group() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(round(CARD, 18));
        box.addView(l, new LinearLayout.LayoutParams(-1, -2));
        return l;
    }

    /** แถวในกลุ่ม: ไอคอนวงกลม + ชื่อ/คำอธิบาย + (วิดเจ็ตด้านขวา) */
    private LinearLayout row(LinearLayout parent, String icon, String title, String sub) {
        if (parent.getChildCount() > 0) {
            View d = new View(this);
            d.setBackgroundColor(LINE);
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, 1);
            dl.setMargins(dp(64), 0, 0, 0);
            parent.addView(d, dl);
        }
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(dp(64));
        row.setPadding(dp(14), dp(10), dp(14), dp(10));
        TextView ic = new TextView(this);
        ic.setText(icon); ic.setTextSize(18); ic.setGravity(Gravity.CENTER);
        ic.setBackground(round(Color.parseColor("#2A352F"), 14));
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(38), dp(38));
        ilp.setMargins(0, 0, dp(12), 0);
        row.addView(ic, ilp);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView a = new TextView(this);
        a.setText(title); a.setTextColor(FG); a.setTextSize(16);
        col.addView(a);
        if (sub != null) {
            TextView s = new TextView(this);
            s.setText(sub); s.setTextColor(MUT); s.setTextSize(12);
            col.addView(s);
        }
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        parent.addView(row, new LinearLayout.LayoutParams(-1, -2));
        return row;
    }

    private TextView perm(LinearLayout parent, String icon, String title, String sub, Runnable tap) {
        LinearLayout r = row(parent, icon, title, sub);
        TextView st = new TextView(this);
        st.setTextSize(13); st.setTypeface(null, Typeface.BOLD);
        r.addView(st);
        r.setOnClickListener(v -> tap.run());
        return st;
    }

    private void status(TextView t, boolean ok) {
        t.setText(ok ? "✓ แล้ว" : "แตะเพื่อขอ");
        t.setTextColor(ok ? AC : WARN);
    }

    private void nav(LinearLayout parent, String icon, String title, String sub, Runnable tap) {
        LinearLayout r = row(parent, icon, title, sub);
        TextView ch = new TextView(this);
        ch.setText("›"); ch.setTextSize(22); ch.setTextColor(MUT);
        r.addView(ch);
        r.setOnClickListener((View v) -> tap.run());
    }

    private interface OnChange { void on(boolean v); }

    private void sw(LinearLayout parent, String icon, String title, String sub, String key, boolean def, OnChange cb) {
        LinearLayout r = row(parent, icon, title, sub);
        Switch s = new Switch(this);
        s.setChecked(sp.getBoolean(key, def));
        s.setOnCheckedChangeListener((CompoundButton b, boolean on) -> {
            sp.edit().putBoolean(key, on).apply();
            if (cb != null) cb.on(on);
            if (VoiceService.instance != null) VoiceService.instance.applyBubble();
        });
        r.addView(s);
        r.setOnClickListener(v -> s.toggle());
    }

    private void seek(LinearLayout parent, String title, String key, int min, int max, int def, String unit) {
        if (parent.getChildCount() > 0) {
            View d = new View(this);
            d.setBackgroundColor(LINE);
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, 1);
            dl.setMargins(dp(64), 0, 0, 0);
            parent.addView(d, dl);
        }
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(64), dp(10), dp(18), dp(8));
        TextView a = new TextView(this);
        a.setTextColor(FG); a.setTextSize(14);
        int cur = sp.getInt(key, def);
        a.setText(title + ": " + cur + unit);
        row.addView(a);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(cur - min);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) { a.setText(title + ": " + (p + min) + unit); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) {
                sp.edit().putInt(key, s.getProgress() + min).apply();
                if (VoiceService.instance != null) VoiceService.instance.applyBubble();
            }
        });
        row.addView(sb, new LinearLayout.LayoutParams(-1, -2));
        parent.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    private LinearLayout tileRow() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(10), 0, 0);
        box.addView(r, lp);
        return r;
    }

    private void tile(LinearLayout rowL, String icon, String title, String sub, Runnable tap) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(14), dp(14), dp(14), dp(14));
        t.setBackground(round(CARD, 18));
        TextView ic = new TextView(this);
        ic.setText(icon); ic.setTextSize(26);
        t.addView(ic);
        TextView a = new TextView(this);
        a.setText(title); a.setTextColor(FG); a.setTextSize(16); a.setTypeface(null, Typeface.BOLD);
        a.setPadding(0, dp(6), 0, 0);
        t.addView(a);
        TextView s = new TextView(this);
        s.setText(sub); s.setTextColor(MUT); s.setTextSize(12);
        t.addView(s);
        t.setOnClickListener(v -> tap.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(rowL.getChildCount() == 0 ? 0 : dp(10), 0, 0, 0);
        rowL.addView(t, lp);
    }

    private Button bigButton(String t, Runnable r) {
        Button bt = new Button(this);
        bt.setText(t);
        bt.setAllCaps(false);
        bt.setTextColor(Color.WHITE);
        bt.setTextSize(15);
        bt.setBackground(round(Color.parseColor("#2F7D4F"), 14));
        bt.setStateListAnimator(null);
        bt.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(10), 0, 0);
        box.addView(bt, lp);
        return bt;
    }
}
