package com.proximityvoice.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** หน้าตั้งค่า: ทุกสิทธิ์ขอตอนกดปุ่มของฟังก์ชันนั้นเท่านั้น */
public class SettingsActivity extends Activity {
    private static final int REQ_MIC = 10, REQ_NOTI = 11;
    private static final int BG = Color.parseColor("#161B18"), CARD = Color.parseColor("#1F2622"),
            FG = Color.parseColor("#E8EFE9"), MUT = Color.parseColor("#8FA196"), AC = Color.parseColor("#5FBF86");
    private SharedPreferences sp;
    private LinearLayout box;
    private TextView stMic, stOv, stBat, stNoti;

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("pv", MODE_PRIVATE);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(24), dp(16), dp(40));
        sv.addView(box);
        setContentView(sv);

        text("ตั้งค่า", 26, FG, true);

        label("สิทธิ์ (แตะเพื่อขอ เฉพาะอันที่อยากใช้)");
        stMic = perm("ไมค์", "จำเป็นเมื่อจะเข้าร่วมเสียง", () ->
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC));
        stOv = perm("แสดงทับแอปอื่น", "สำหรับปุ่มไมค์ลอย", () -> startActivity(new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))));
        stBat = perm("ไม่จำกัดแบตเตอรี่", "กันระบบตัดไมค์เมื่อพับแอปนานๆ (สำคัญ)", this::askBattery);
        stNoti = perm("การแจ้งเตือน", "แสดงสถานะไมค์ในแถบแจ้งเตือน", () -> {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTI);
        });

        label("ปุ่มไมค์ลอย");
        sw("เปิดปุ่มไมค์ลอย", "แตะ = ปิด/เปิดไมค์ ลาก = ย้าย", "bubble", false, on -> {
            if (on && !Settings.canDrawOverlays(this)) startActivity(new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        });
        seek("ขนาดปุ่ม", "bsize", 30, 80, 40, "dp");
        seek("ความโปร่งใส (ยิ่งมากยิ่งชัด)", "balpha", 30, 100, 85, "%");
        sw("ซ่อนปุ่มเมื่ออยู่ในแอป", "ปุ่มจะโผล่เฉพาะตอนอยู่แอปอื่น เช่น เกม", "hideInApp", false, null);

        label("การทำงานเบื้องหลัง");
        sw("ทำงานเบื้องหลังต่อเนื่อง", "ให้ไมค์ทำงานตอนพับแอป (แนะนำเปิด)", "keepalive", true, on -> {
            if (!on) stopService(new Intent(this, VoiceService.class));
            else if (hasMic()) try { startForegroundService(new Intent(this, VoiceService.class)); } catch (Exception ignored) { }
        });
        sw("กันจอดับ", "จอไม่ดับตอนเปิดแอปอยู่", "screenOn", true, null);
        sw("ย่อเป็นหน้าต่างลอยเมื่อกดโฮม", "แสดงแถบวัดเสียงลอยเล็กๆ", "pip", true, null);

        label("อื่นๆ");
        button("สร้างเซิร์ฟเวอร์เสียงในแอป (โฮสต์)", () -> startActivity(new Intent(this, HostActivity.class)));
        button("เปลี่ยนที่อยู่เซิร์ฟเวอร์เสียง", this::askUrl);
        button("ตั้งค่าแอปของระบบ", () -> startActivity(new Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))));
        button("ออกจากแอป", () -> {
            startActivity(new Intent(this, MainActivity.class).putExtra("exit", true));
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        status(stMic, hasMic());
        status(stOv, Settings.canDrawOverlays(this));
        status(stBat, ((PowerManager) getSystemService(POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName()));
        status(stNoti, Build.VERSION.SDK_INT < 33
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED);
        if (VoiceService.instance != null) VoiceService.instance.applyBubble();
    }

    @Override
    public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        super.onRequestPermissionsResult(c, p, r);
        onResume();
    }

    private boolean hasMic() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private void askBattery() {
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }

    private void askUrl() {
        EditText et = new EditText(this);
        et.setText(sp.getString("url", ""));
        new AlertDialog.Builder(this).setTitle("ที่อยู่เซิร์ฟเวอร์เสียง").setView(et)
                .setPositiveButton("บันทึก", (d, w) -> {
                    String u = et.getText().toString().trim();
                    if (!u.isEmpty()) sp.edit().putString("url", u).apply();
                })
                .setNegativeButton("ยกเลิก", null).show();
    }

    // ---------- ตัวช่วยสร้าง UI ----------
    private TextView text(String t, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(null, android.graphics.Typeface.BOLD);
        box.addView(v);
        return v;
    }

    private void label(String t) {
        TextView v = text(t, 13, AC, true);
        v.setPadding(0, dp(22), 0, dp(6));
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        l.setBackgroundColor(CARD);
        l.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(6));
        box.addView(l, lp);
        return l;
    }

    private LinearLayout titles(LinearLayout row, String title, String sub) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView a = new TextView(this);
        a.setText(title); a.setTextColor(FG); a.setTextSize(16);
        col.addView(a);
        if (sub != null) {
            TextView s = new TextView(this);
            s.setText(sub); s.setTextColor(MUT); s.setTextSize(12);
            col.addView(s);
        }
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        return col;
    }

    private TextView perm(String title, String sub, Runnable tap) {
        LinearLayout row = card();
        titles(row, title, sub);
        TextView st = new TextView(this);
        st.setTextSize(14);
        row.addView(st);
        row.setOnClickListener(v -> tap.run());
        return st;
    }

    private void status(TextView t, boolean ok) {
        t.setText(ok ? "✓ อนุญาตแล้ว" : "แตะเพื่อขอ");
        t.setTextColor(ok ? AC : Color.parseColor("#F5C518"));
    }

    private interface OnChange { void on(boolean v); }

    private void sw(String title, String sub, String key, boolean def, OnChange cb) {
        LinearLayout row = card();
        titles(row, title, sub);
        Switch s = new Switch(this);
        s.setChecked(sp.getBoolean(key, def));
        s.setOnCheckedChangeListener((CompoundButton b, boolean on) -> {
            sp.edit().putBoolean(key, on).apply();
            if (cb != null) cb.on(on);
            if (VoiceService.instance != null) VoiceService.instance.applyBubble();
        });
        row.addView(s);
    }

    private void seek(String title, String key, int min, int max, int def, String unit) {
        LinearLayout row = card();
        row.setOrientation(LinearLayout.VERTICAL);
        row.setGravity(Gravity.START);
        TextView a = new TextView(this);
        a.setTextColor(FG); a.setTextSize(16);
        int cur = sp.getInt(key, def);
        a.setText(title + ": " + cur + unit);
        row.addView(a);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(cur - min);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                a.setText(title + ": " + (p + min) + unit);
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) {
                sp.edit().putInt(key, s.getProgress() + min).apply();
                if (VoiceService.instance != null) VoiceService.instance.applyBubble();
            }
        });
        row.addView(sb, new LinearLayout.LayoutParams(-1, -2));
    }

    private void button(String title, Runnable tap) {
        LinearLayout row = card();
        titles(row, title, null);
        row.setOnClickListener((View v) -> tap.run());
    }
}
