package com.proximityvoice.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** หน้าตั้งค่า: ทางลัดฟังก์ชันหลักอยู่บนสุด ที่เหลือจัดเป็นหมวด */
public class SettingsActivity extends Activity {
    private static final int REQ_MIC = 10, REQ_NOTI = 11, REQ_ALL = 12;
    private static final int BG = Color.parseColor("#161B18"), CARD = Color.parseColor("#1F2622"),
            LINE = Color.parseColor("#2B352F"), FG = Color.parseColor("#E8EFE9"),
            MUT = Color.parseColor("#8FA196"), AC = Color.parseColor("#5FBF86"), WARN = Color.parseColor("#F5C518");
    private SharedPreferences sp;
    private LinearLayout box;
    private TextView stMic, stOv, stBat, stNoti, setupHint;

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("pv", MODE_PRIVATE);
        ScrollView sv = new ScrollView(this);
        sv.setBackground(Ui.bg());
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(24), dp(16), dp(40));
        sv.addView(box);
        setContentView(sv);

        page = getIntent().getStringExtra("page");
        header(titleOf(page));
        if (page == null) { hub(); return; }
        switch (page) {
            case "perm": pagePerm(); break;
            case "game": pageGame(); break;
            case "talk": pageTalk(); break;
            case "bubble": pageBubble(); break;
            case "net": pageNet(); break;
            default: pageBg(); break;
        }
    }

    private String page;
    private TextView lastSub, subPerm, subGame, subTalk, subBubble, subNet, subBg;

    private static String titleOf(String p) {
        if (p == null) return "ตั้งค่า";
        switch (p) {
            case "perm": return "สิทธิ์ที่ต้องมี";
            case "game": return "ชื่อในเกม";
            case "talk": return "โหมดการพูด";
            case "bubble": return "ปุ่มลอยตอนเล่นเกม";
            case "net": return "การเชื่อมต่อและแจ้งเตือน";
            default: return "เบื้องหลังและระบบ";
        }
    }

    private void open(String p) { startActivity(new Intent(this, SettingsActivity.class).putExtra("page", p)); }

    /** หน้าแรกของตั้งค่า: ทางลัดฟังก์ชันหลัก + หมวดหมู่ที่มีสรุปสถานะ */
    private void hub() {
        LinearLayout r1 = tileRow();
        tile(r1, "\uD83D\uDC65", "กลุ่มเสียง", "สร้าง / เข้าร่วม / โฮสต์", () -> startActivity(new Intent(this, GroupActivity.class)));
        tile(r1, "\uD83D\uDDA5", "เซิร์ฟเวอร์", "สร้างเองไม่ต้องมีกลุ่ม", () -> startActivity(new Intent(this, HostActivity.class)));
        LinearLayout r2 = tileRow();
        tile(r2, "\uD83D\uDD17", "ที่อยู่เซิร์ฟเวอร์", "ใส่ลิงก์เอง", this::askUrl);
        tile(r2, "\uD83D\uDEAA", "ออกจากแอป", "ปิดไมค์และเซิร์ฟเวอร์", () -> {
            startActivity(new Intent(this, MainActivity.class).putExtra("exit", true));
            finish();
        });

        LinearLayout r3 = tileRow();
        tile(r3, "\uD83E\uDE7A", "ตรวจระบบ", "ทำไมไม่ได้ยินเสียง?", () -> startActivity(new Intent(this, DiagnosticsActivity.class)));
        tile(r3, "\uD83D\uDCF2", "อัปเดตแอป", "ตรวจเวอร์ชันใหม่", () -> Updater.check(this, true));


        section("หมวดการตั้งค่า");
        LinearLayout cat = group();
        nav(cat, "\uD83D\uDD10", "สิทธิ์ที่ต้องมี", "-", () -> open("perm")); subPerm = lastSub;
        nav(cat, "\uD83C\uDFAE", "ชื่อในเกม", "-", () -> open("game")); subGame = lastSub;
        nav(cat, "\uD83D\uDDE3", "โหมดการพูด", "-", () -> open("talk")); subTalk = lastSub;
        nav(cat, "\uD83C\uDFAF", "ปุ่มลอยตอนเล่นเกม", "-", () -> open("bubble")); subBubble = lastSub;
        nav(cat, "\uD83C\uDF10", "การเชื่อมต่อและแจ้งเตือน", "-", () -> open("net")); subNet = lastSub;
        nav(cat, "\uD83D\uDD04", "เบื้องหลังและระบบ", "-", () -> open("bg")); subBg = lastSub;
        refreshHub();
    }

    private void refreshHub() {
        if (subPerm == null) return;
        boolean mic = hasMic();
        boolean bat = ((PowerManager) getSystemService(POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName());
        boolean noti = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        int missing = (mic ? 0 : 1) + (bat ? 0 : 1) + (noti ? 0 : 1);
        subPerm.setText(missing == 0 ? "✓ ครบแล้ว" : "ยังขาด " + missing + " อย่าง แตะเพื่อตั้งค่า");
        subPerm.setTextColor(missing == 0 ? AC : WARN);
        String gn = sp.getString("ingame", "");
        subGame.setText(gn.isEmpty() ? "ยังไม่ได้ตั้ง" : gn + (sp.getBoolean("autoname", true) ? "  ·  รอเข้าอัตโนมัติ" : ""));
        subTalk.setText(sp.getBoolean("talkptt", false) ? "กดค้างเพื่อพูด" : "เปิดไมค์ตลอด");
        int n = 0;
        for (String k : new String[]{"bubble", "bubbleShout", "bubblePtt", "bubbleWhisper", "bubbleRadio"}) if (sp.getBoolean(k, false)) n++;
        subBubble.setText(n == 0 ? "ปิดอยู่" : "เปิด " + n + " ปุ่ม");
        subNet.setText((sp.getString("cftoken", "").isEmpty() ? "ลิงก์ชั่วคราว" : "ลิงก์ถาวร") + "  ·  แจ้งเตือนกลุ่ม " + (sp.getBoolean("notifyGroup", false) ? "เปิด" : "ปิด"));
        subBg.setText("ทำงานเบื้องหลัง " + (sp.getBoolean("keepalive", true) ? "เปิด" : "ปิด") + "  ·  build " + Updater.localVersion(this));
    }

    private void pagePerm() {
        LinearLayout perms = group();
        stMic = perm(perms, "\uD83C\uDF99", "ไมค์", "จำเป็นเมื่อจะเข้าร่วมเสียง", () ->
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC));
        stNoti = perm(perms, "\uD83D\uDD14", "การแจ้งเตือน", "แสดงสถานะไมค์/เซิร์ฟเวอร์ในแถบแจ้งเตือน", () -> {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTI);
        });
        stBat = perm(perms, "\uD83D\uDD0B", "ไม่จำกัดแบตเตอรี่", "กันระบบตัดไมค์/เซิร์ฟเวอร์เมื่อพับแอป (สำคัญ)", this::askBattery);
        stOv = perm(perms, "\uD83E\uDEA7", "แสดงทับแอปอื่น", "สำหรับปุ่มไมค์ลอยตอนเล่นเกม", () -> startActivity(new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))));
        setupHint = text("", 12, MUT, false);
        setupHint.setPadding(dp(4), dp(6), 0, 0);
        Button all = bigButton("ตั้งค่าให้ครบในครั้งเดียว", this::setupAll);

    }

    private void pageGame() {
        LinearLayout gnm = group();
        nav(gnm, "\uD83C\uDFAE", "ชื่อในเกมของฉัน", sp.getString("ingame", "").isEmpty() ? "ยังไม่ได้ตั้ง แตะเพื่อใส่" : sp.getString("ingame", ""), this::askGameName);
        sw(gnm, "\u23F3", "เข้าเสียงอัตโนมัติเมื่อเข้าเกม", "แอปจะรอและเชื่อมให้เองทันทีที่ชื่อนี้เข้าโลก ไม่ต้องพิมพ์ชื่อทีหลัง", "autoname", true, on -> reloadVoicePage());

    }

    private void pageTalk() {
        LinearLayout talk = group();
        sw(talk, "\uD83D\uDDE3", "กดค้างเพื่อพูด (Push-to-talk)", "ไมค์เปิดเฉพาะตอนกดปุ่มพูด ปิดไว้ = เปิดไมค์ตลอด", "talkptt", false, on -> {
            if (MainActivity.web != null) MainActivity.web.evaluateJavascript("window.pvRefresh&&pvRefresh()", null);
        });
        text("ปุ่มตะโกน: กดค้างเพื่อให้เสียงคุณไปไกลขึ้น 3 เท่า (ใช้ได้ทั้งในหน้าเสียงและปุ่มลอยด้านล่าง)", 12, MUT, false)
                .setPadding(dp(4), dp(6), 0, 0);

    }

    private void pageBubble() {
        LinearLayout fl = group();
        Runnable askOverlay = () -> {
            if (!Settings.canDrawOverlays(this)) startActivity(new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        };
        sw(fl, "\uD83C\uDF99", "ปุ่มปิด/เปิดไมค์ลอย", "แตะ = ปิด/เปิดไมค์ ลาก = ย้าย", "bubble", false, on -> { if (on) askOverlay.run(); });
        sw(fl, "\uD83D\uDCE2", "ปุ่มตะโกนลอย", "กดค้างเพื่อตะโกน (ลากไกลๆ เพื่อย้าย)", "bubbleShout", false, on -> { if (on) askOverlay.run(); });
        sw(fl, "\uD83E\uDD2B", "ปุ่มกระซิบลอย", "กดค้างเพื่อกระซิบ (ได้ยินแค่ใกล้ๆ)", "bubbleWhisper", false, on -> { if (on) askOverlay.run(); });
        sw(fl, "\uD83D\uDCFB", "ปุ่มวิทยุทีมลอย", "กดค้างพูดวิทยุ (เลือกช่องในหน้าเสียง)", "bubbleRadio", false, on -> { if (on) askOverlay.run(); });
        sw(fl, "\uD83C\uDFA4", "ปุ่มกดค้างพูดลอย", "ใช้คู่กับโหมดกดค้างเพื่อพูด", "bubblePtt", false, on -> { if (on) askOverlay.run(); });
        sw(fl, "\uD83D\uDD17", "รวมปุ่มเป็นแถบเดียว", "ลากทีเดียวขยับทุกปุ่ม (ปิด = แยกเป็นปุ่มอิสระ)", "bubbleAttach", true, null);
        seek(fl, "ขนาดปุ่ม", "bsize", 30, 80, 40, "dp");
        seek(fl, "ความโปร่งใส (ยิ่งมากยิ่งชัด)", "balpha", 30, 100, 85, "%");
        sw(fl, "\uD83D\uDE48", "ซ่อนปุ่มเมื่ออยู่ในแอป", "ปุ่มจะโผล่เฉพาะตอนอยู่แอปอื่น เช่น เกม (ปิดไว้ถ้าอยากดูตัวอย่างปุ่มตอนนี้)", "hideInApp", true, null);
        nav(fl, "\uD83D\uDEE0", "รีเฟรชปุ่มลอย (ถ้าปุ่มหาย)", "สร้างปุ่มใหม่ และเริ่มบริการให้ถ้าหยุดอยู่", () -> {
            if (VoiceService.instance != null) VoiceService.instance.applyBubble();
            else if (hasMic()) try { startForegroundService(new Intent(this, VoiceService.class)); } catch (Exception ignored) { }
            else requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
        });
        nav(fl, "\uD83D\uDD04", "รีเซ็ตตำแหน่งปุ่มลอย", "จัดปุ่มกลับมาเรียงเป็นแถวตามค่าเริ่มต้น", () -> {
            SharedPreferences.Editor ed = sp.edit();
            for (String k : new String[]{"bx", "by", "sx", "sy", "px", "py", "wx", "wy", "rx", "ry"}) ed.remove(k);
            ed.apply();
            if (VoiceService.instance != null) VoiceService.instance.applyBubble();
        });

    }

    private void pageNet() {
        LinearLayout nt = group();
        sw(nt, "\uD83D\uDD14", "แจ้งเตือนเมื่อเพื่อนสร้างเซิร์ฟเวอร์", "ฟังกลุ่มเบื้องหลังแม้ปิดหน้าแอป (ใช้แบตเพิ่มเล็กน้อย)", "notifyGroup", false, on -> {
            if (on && Group.any(this)) {
                try { startForegroundService(new Intent(this, GroupWatchService.class)); } catch (Exception ignored) { }
            } else if (!on) stopService(new Intent(this, GroupWatchService.class));
        });
        nav(nt, "\uD83D\uDD17", "ลิงก์ถาวร (Cloudflare Tunnel)", sp.getString("cftoken", "").isEmpty() ? "ยังไม่ได้ตั้ง (ใช้ลิงก์ชั่วคราว)" : "ตั้งแล้ว: " + sp.getString("cfhost", "-"), this::askPermanent);
        nav(nt, "\uD83D\uDCF2", "อัปเดตแอปจาก GitHub", Updater.repoOf(this) + "  ·  build " + Updater.localVersion(this), this::askUpdateRepo);

    }

    private void pageBg() {
        LinearLayout bg = group();
        sw(bg, "\uD83D\uDD04", "ทำงานเบื้องหลังต่อเนื่อง", "ให้ไมค์ทำงานตอนพับแอป (แนะนำเปิด)", "keepalive", true, on -> {
            if (!on) stopService(new Intent(this, VoiceService.class));
            else if (hasMic()) try { startForegroundService(new Intent(this, VoiceService.class)); } catch (Exception ignored) { }
        });
        sw(bg, "\uD83D\uDCA1", "กันจอดับ", "จอไม่ดับตอนเปิดแอปอยู่", "screenOn", true, null);
        sw(bg, "\uD83E\uDE9F", "ย่อเป็นหน้าต่างลอยเมื่อกดโฮม", "แสดงแถบวัดเสียงลอยเล็กๆ", "pip", true, null);

        LinearLayout sys = group();
        nav(sys, "\u2699", "ตั้งค่าแอปของระบบ", "สิทธิ์ทั้งหมด / ล้างข้อมูล", () -> startActivity(new Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))));
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean mic = hasMic(), ov = Settings.canDrawOverlays(this);
        boolean bat = ((PowerManager) getSystemService(POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName());
        boolean noti = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        if (stMic != null) {
            status(stMic, mic); status(stOv, ov); status(stBat, bat); status(stNoti, noti);
            int missing = (mic ? 0 : 1) + (bat ? 0 : 1) + (noti ? 0 : 1);   // ปุ่มลอยเป็นของเสริม ไม่นับ
            setupHint.setText(missing == 0 ? "✓ สิทธิ์สำคัญครบแล้ว" : "ยังขาด " + missing + " อย่างที่แนะนำ แตะที่รายการ หรือกดปุ่มด้านล่าง");
            setupHint.setTextColor(missing == 0 ? AC : WARN);
        }
        refreshHub();
        if (VoiceService.instance != null) VoiceService.instance.applyBubble();
    }

    @Override
    public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        super.onRequestPermissionsResult(c, p, r);
        onResume();
        if (c == REQ_ALL) askBatteryIfNeeded();
    }

    private boolean hasMic() { return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED; }

    /** ขอไมค์ + แจ้งเตือนพร้อมกัน แล้วต่อด้วยแบตเตอรี่ */
    private void setupAll() {
        List<String> need = new ArrayList<>();
        if (!hasMic()) need.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ_ALL);
        else askBatteryIfNeeded();
    }

    private void askBatteryIfNeeded() {
        if (!((PowerManager) getSystemService(POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName())) askBattery();
    }

    private void askBattery() {
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }

    private void reloadVoicePage() {
        if (MainActivity.web != null) MainActivity.web.reload();   // ให้หน้าเสียงเริ่มรอ/เข้าตามค่าใหม่
    }

    private void askGameName() {
        EditText et = new EditText(this);
        et.setHint("ชื่อในเกม เช่น Steve");
        et.setSingleLine();
        et.setText(sp.getString("ingame", ""));
        new AlertDialog.Builder(this).setTitle("ชื่อในเกมของฉัน")
                .setMessage("พิมพ์ให้ตรงกับชื่อผู้เล่นในเกม (ไม่สนตัวพิมพ์ใหญ่เล็ก) ตั้งไว้ครั้งเดียว แอปจะรอจนคุณเข้าโลกแล้วต่อเสียงให้เอง")
                .setView(et)
                .setPositiveButton("บันทึก", (d, w) -> {
                    sp.edit().putString("ingame", et.getText().toString().trim()).apply();
                    reloadVoicePage();
                    recreate();
                })
                .setNegativeButton("ยกเลิก", null).show();
    }

    private void askPermanent() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        TextView info = new TextView(this);
        info.setText("1) ใน Cloudflare Zero Trust สร้าง Tunnel แล้วคัดลอก token\n2) เพิ่ม Public hostname (เช่น voice.โดเมนของคุณ) ชี้ไปที่ http://localhost:3000\n3) ใส่ token กับโดเมนด้านล่าง เว้นว่างทั้งคู่ = กลับไปใช้ลิงก์ชั่วคราว");
        info.setTextSize(12);
        l.addView(info);
        EditText tk = new EditText(this);
        tk.setHint("Tunnel token"); tk.setSingleLine(); tk.setText(sp.getString("cftoken", ""));
        l.addView(tk);
        EditText hs = new EditText(this);
        hs.setHint("โดเมน เช่น voice.example.com"); hs.setSingleLine(); hs.setText(sp.getString("cfhost", ""));
        l.addView(hs);
        new AlertDialog.Builder(this).setTitle("ลิงก์ถาวร").setView(l)
                .setPositiveButton("บันทึก", (d, w) -> {
                    sp.edit().putString("cftoken", tk.getText().toString().trim()).putString("cfhost", hs.getText().toString().trim()).apply();
                    recreate();
                })
                .setNegativeButton("ยกเลิก", null).show();
    }

    private void askUpdateRepo() {
        EditText et = new EditText(this);
        et.setHint("เจ้าของ/ชื่อrepo เช่น myname/proximity-voice");
        et.setSingleLine();
        et.setText(Updater.repoOf(this));
        new AlertDialog.Builder(this).setTitle("repo สำหรับอัปเดตแอป")
                .setMessage("ต้องเป็น repo สาธารณะ และ workflow ต้องปล่อย APK เป็น Release")
                .setView(et)
                .setPositiveButton("บันทึกและตรวจ", (d, w) -> {
                    sp.edit().putString("updrepo", et.getText().toString().trim()).putLong("updlast", 0).apply();
                    Updater.check(this, true);
                    recreate();
                })
                .setNegativeButton("ยกเลิก", null).show();
    }

    private void askUrl() {
        EditText et = new EditText(this);
        et.setText(sp.getString("url", ""));
        new AlertDialog.Builder(this).setTitle("ที่อยู่เซิร์ฟเวอร์เสียง").setView(et)
                .setPositiveButton("บันทึก", (d, w) -> {
                    String u = et.getText().toString().trim();
                    if (!u.isEmpty()) sp.edit().putString("url", u).apply();
                })
                .setNegativeButton("ยกเลิก", null).show();
    }

    /** หัวหน้า: ปุ่มย้อนกลับกลมที่ซ้ายบน + ชื่อหน้า */
    private TextView header(String t) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = new TextView(this);
        back.setText("\u2039");
        back.setTextSize(30);
        back.setTextColor(Color.parseColor("#E8EFE9"));
        back.setGravity(Gravity.CENTER);
        back.setPadding(0, 0, 0, dp(3));
        GradientDrawable bb = new GradientDrawable();
        bb.setShape(GradientDrawable.OVAL);
        bb.setColor(Color.parseColor("#2A352F"));
        back.setBackground(bb);
        back.setContentDescription("ย้อนกลับ");
        back.setOnClickListener(v -> onBackPressed());
        r.addView(back, new LinearLayout.LayoutParams(dp(42), dp(42)));
        TextView title = new TextView(this);
        title.setText(t);
        title.setTextSize(22);
        title.setTextColor(Color.parseColor("#E8EFE9"));
        title.setTypeface(null, Typeface.BOLD);
        title.setPadding(dp(12), 0, 0, 0);
        r.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        box.addView(r, lp);
        return title;
    }

    // ---------- ตัวช่วยสร้าง UI ----------
    private GradientDrawable round(int color, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(r));
        g.setColor(color);
        return g;
    }

    private TextView text(String t, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(size); v.setTextColor(color);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        box.addView(v);
        return v;
    }

    private void section(String t) {
        TextView v = text(t, 13, AC, true);
        v.setPadding(dp(4), dp(24), 0, dp(8));
    }

    private LinearLayout group() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(Ui.card(this));
        box.addView(l, new LinearLayout.LayoutParams(-1, -2));
        return l;
    }

    /** แถวในกลุ่ม: ไอคอนวงกลม + ชื่อ/คำอธิบาย + (วิดเจ็ตด้านขวา) */
    private LinearLayout row(LinearLayout parent, String icon, String title, String sub) {
        if (parent.getChildCount() > 0) {
            View d = new View(this);
            d.setBackgroundColor(LINE);
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, 1);
            dl.setMargins(dp(64), 0, 0, 0);
            parent.addView(d, dl);
        }
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(dp(64));
        row.setPadding(dp(14), dp(10), dp(14), dp(10));
        TextView ic = new TextView(this);
        ic.setText(icon); ic.setTextSize(18); ic.setGravity(Gravity.CENTER);
        ic.setBackground(round(Color.parseColor("#2A352F"), 14));
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(38), dp(38));
        ilp.setMargins(0, 0, dp(12), 0);
        row.addView(ic, ilp);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView a = new TextView(this);
        a.setText(title); a.setTextColor(FG); a.setTextSize(16);
        col.addView(a);
        lastSub = null;
        if (sub != null) {
            TextView s = new TextView(this);
            s.setText(sub); s.setTextColor(MUT); s.setTextSize(12);
            col.addView(s);
            lastSub = s;
        }
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        parent.addView(row, new LinearLayout.LayoutParams(-1, -2));
        return row;
    }

    private TextView perm(LinearLayout parent, String icon, String title, String sub, Runnable tap) {
        LinearLayout r = row(parent, icon, title, sub);
        TextView st = new TextView(this);
        st.setTextSize(13); st.setTypeface(null, Typeface.BOLD);
        r.addView(st);
        r.setOnClickListener(v -> tap.run());
        return st;
    }

    private void status(TextView t, boolean ok) {
        t.setText(ok ? "✓ แล้ว" : "แตะเพื่อขอ");
        t.setTextColor(ok ? AC : WARN);
    }

    private void nav(LinearLayout parent, String icon, String title, String sub, Runnable tap) {
        LinearLayout r = row(parent, icon, title, sub);
        TextView ch = new TextView(this);
        ch.setText("›"); ch.setTextSize(22); ch.setTextColor(MUT);
        r.addView(ch);
        r.setOnClickListener((View v) -> tap.run());
    }

    private interface OnChange { void on(boolean v); }

    private void sw(LinearLayout parent, String icon, String title, String sub, String key, boolean def, OnChange cb) {
        LinearLayout r = row(parent, icon, title, sub);
        Switch s = new Switch(this);
        Ui.tint(s);
        s.setChecked(sp.getBoolean(key, def));
        s.setOnCheckedChangeListener((CompoundButton b, boolean on) -> {
            sp.edit().putBoolean(key, on).apply();
            if (cb != null) cb.on(on);
            if (VoiceService.instance != null) VoiceService.instance.applyBubble();
        });
        r.addView(s);
        r.setOnClickListener(v -> s.toggle());
    }

    private void seek(LinearLayout parent, String title, String key, int min, int max, int def, String unit) {
        if (parent.getChildCount() > 0) {
            View d = new View(this);
            d.setBackgroundColor(LINE);
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, 1);
            dl.setMargins(dp(64), 0, 0, 0);
            parent.addView(d, dl);
        }
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(64), dp(10), dp(18), dp(8));
        TextView a = new TextView(this);
        a.setTextColor(FG); a.setTextSize(14);
        int cur = sp.getInt(key, def);
        a.setText(title + ": " + cur + unit);
        row.addView(a);
        SeekBar sb = new SeekBar(this);
        Ui.tint(sb);
        sb.setMax(max - min);
        sb.setProgress(cur - min);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) { a.setText(title + ": " + (p + min) + unit); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) {
                sp.edit().putInt(key, s.getProgress() + min).apply();
                if (VoiceService.instance != null) VoiceService.instance.applyBubble();
            }
        });
        row.addView(sb, new LinearLayout.LayoutParams(-1, -2));
        parent.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    private LinearLayout tileRow() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(10), 0, 0);
        box.addView(r, lp);
        return r;
    }

    private void tile(LinearLayout rowL, String icon, String title, String sub, Runnable tap) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(14), dp(14), dp(14), dp(14));
        t.setBackground(Ui.card(this));
        TextView ic = new TextView(this);
        ic.setText(icon); ic.setTextSize(26);
        t.addView(ic);
        TextView a = new TextView(this);
        a.setText(title); a.setTextColor(FG); a.setTextSize(16); a.setTypeface(null, Typeface.BOLD);
        a.setPadding(0, dp(6), 0, 0);
        t.addView(a);
        TextView s = new TextView(this);
        s.setText(sub); s.setTextColor(MUT); s.setTextSize(12);
        t.addView(s);
        t.setOnClickListener(v -> tap.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(rowL.getChildCount() == 0 ? 0 : dp(10), 0, 0, 0);
        rowL.addView(t, lp);
    }

    private Button bigButton(String t, Runnable r) {
        Button bt = new Button(this);
        bt.setText(t);
        bt.setAllCaps(false);
        bt.setTextColor(Color.WHITE);
        bt.setTextSize(15);
        bt.setBackground(round(Color.parseColor("#2F7D4F"), 14));
        bt.setStateListAnimator(null);
        bt.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(10), 0, 0);
        box.addView(bt, lp);
        return bt;
    }
}
