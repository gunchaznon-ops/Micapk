package com.proximityvoice.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** ชุดสี/ตัวช่วยหน้าตาร่วมกันของทุกหน้า */
final class Ui {
    static final int BG = Color.parseColor("#161B18"), CARD = Color.parseColor("#1F2622"), LINE = Color.parseColor("#2B352F"),
            FG = Color.parseColor("#E8EFE9"), MUT = Color.parseColor("#8FA196"), AC = Color.parseColor("#5FBF86"),
            AC_DARK = Color.parseColor("#2F7D4F"), WARN = Color.parseColor("#F5C518"), DANGER = Color.parseColor("#F0716F");
    private static final int[] PAL = {0xFF2F7D4F, 0xFF3B82F6, 0xFFE5484D, 0xFFF59E0B, 0xFF8B5CF6, 0xFF0EA5A5, 0xFFEC4899};

    private Ui() { }

    /** สวิตช์/แถบเลื่อนสีเขียวให้เข้าธีม (แทนสีเขียวอมฟ้าของระบบ) */
    static void tint(Switch s) {
        int[][] st = {{android.R.attr.state_checked}, {}};
        s.setThumbTintList(new ColorStateList(st, new int[]{0xFF5FBF86, 0xFFB7C0BA}));
        s.setTrackTintList(new ColorStateList(st, new int[]{0x885FBF86, 0x44FFFFFF}));
    }

    static void tint(SeekBar b) {
        ColorStateList c = ColorStateList.valueOf(AC);
        b.setProgressTintList(c);
        b.setThumbTintList(c);
        b.setProgressBackgroundTintList(ColorStateList.valueOf(0x33FFFFFF));
    }

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    /** พื้นหลังหน้าจอ: เขียวเข้มไล่ลงไปดำ */
    static GradientDrawable bg() {
        return new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFF1E3A2B, 0xFF161B18, 0xFF121614});
    }

    static GradientDrawable round(int color, int radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(radiusPx);
        g.setColor(color);
        return g;
    }

    static GradientDrawable card(Context c) {
        GradientDrawable g = round(CARD, dp(c, 20));
        g.setStroke(1, LINE);
        return g;
    }

    static GradientDrawable hero(Context c) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF3AA567, 0xFF1F5A38});
        g.setCornerRadius(dp(c, 26));
        return g;
    }

    /** วงกลมตัวอักษรแรกของชื่อ สีตามชื่อ */
    static TextView avatar(Context c, String name, int px) {
        TextView t = new TextView(c);
        String s = (name == null || name.trim().isEmpty()) ? "?" : name.trim();
        t.setText(s.substring(0, s.offsetByCodePoints(0, 1)).toUpperCase());
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, px * 0.42f);
        t.setTypeface(null, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(PAL[Math.abs(s.hashCode()) % PAL.length]);
        g.setStroke(dp(c, 2), BG);
        t.setBackground(g);
        return t;
    }

    static TextView pill(Context c, String text, int bg, int fg) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextColor(fg);
        t.setTextSize(12);
        t.setTypeface(null, Typeface.BOLD);
        t.setPadding(dp(c, 10), dp(c, 3), dp(c, 10), dp(c, 3));
        t.setBackground(round(bg, dp(c, 99)));
        return t;
    }
}
