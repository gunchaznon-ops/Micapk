package com.proximityvoice.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.PictureInPictureParams;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Rational;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import java.io.InputStream;
import java.util.HashMap;

public class MainActivity extends Activity {
    private static final int REQ_MIC = 1;
    static WebView web;      // ให้ปุ่มลอยเรียกปิด/เปิดไมค์ได้
    static boolean visible;  // แอปอยู่หน้าจอหรือไม่
    private PermissionRequest pendingWebPermission;
    private boolean dialogOpen = false;
    private String loadedUrl = null;

    /** WebView ที่ไม่ยอมหยุดทำงานตอนแอปถูกพับ (ไม่งั้นไมค์ดับเมื่อพับนานๆ) */
    static class KeepWebView extends WebView {
        KeepWebView(Context c) { super(c); }
        @Override
        protected void onWindowVisibilityChanged(int v) {
            if (v != View.GONE) super.onWindowVisibilityChanged(View.VISIBLE);
        }
    }

    private SharedPreferences prefs() {
        return getSharedPreferences("pv", MODE_PRIVATE);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new KeepWebView(this);
        FrameLayout root = new FrameLayout(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        TextView gear = new TextView(this);
        gear.setText("\u2699");
        gear.setTextSize(20);
        gear.setTextColor(Color.WHITE);
        gear.setGravity(Gravity.CENTER);
        GradientDrawable gb = new GradientDrawable();
        gb.setShape(GradientDrawable.OVAL);
        gb.setColor(Color.parseColor("#99000000"));
        gear.setBackground(gb);
        FrameLayout.LayoutParams glp = new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.TOP | Gravity.END);
        glp.setMargins(0, dp(10), dp(10), 0);
        gear.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        root.addView(gear, glp);
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("appassets.local".equals(u.getHost())) {
                    try {
                        String path = u.getPath();
                        if (path == null || path.equals("/")) path = "/index.html";
                        InputStream in = getAssets().open(path.substring(1));
                        String mime = path.endsWith(".html") ? "text/html" : "application/octet-stream";
                        return new android.webkit.WebResourceResponse(mime, "utf-8", in);
                    } catch (Exception e) {
                        return new android.webkit.WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                                new HashMap<String, String>(), null);
                    }
                }
                return super.shouldInterceptRequest(v, r);
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) askUrl("เปิดไม่ได้ ตรวจสอบที่อยู่เซิร์ฟเวอร์");
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest req) {
                runOnUiThread(() -> {
                    if (hasMic()) {
                        grantAudio(req);
                    } else {
                        // ขอสิทธิ์ไมค์เฉพาะตอนที่กดเข้าร่วมเสียงจริงๆ
                        pendingWebPermission = req;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                    }
                });
            }
        });

        String fromLink = linkFromIntent(getIntent());
        if (fromLink != null) prefs().edit().putString("url", fromLink).apply();
        String url = prefs().getString("url", null);
        if (url == null) askUrl("ใส่ที่อยู่เซิร์ฟเวอร์เสียง");
        else { loadedUrl = url; openTarget(url); }
    }

    /** ลิงก์ที่เพื่อนกดมา (https://xxx.trycloudflare.com หรือ pvoice://xxx.trycloudflare.com) */
    private String linkFromIntent(Intent i) {
        if (i == null || i.getData() == null) return null;
        Uri d = i.getData();
        String host = d.getHost();
        if (host == null || !host.endsWith(".trycloudflare.com")) return null;
        return "https://" + host;
    }

    private static final java.util.regex.Pattern CF_LINK =
            java.util.regex.Pattern.compile("https://([a-z0-9-]+)\\.trycloudflare\\.com");
    private String lastOffered = null;

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) checkClipboard();
    }

    /** เพื่อนคัดลอกลิงก์แล้วเปิดแอป → ถามว่าจะใช้ลิงก์นี้เลยไหม */
    private void checkClipboard() {
        if (dialogOpen || HostService.instance != null) return;
        try {
            android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip() || cm.getPrimaryClip().getItemCount() == 0) return;
            CharSequence t = cm.getPrimaryClip().getItemAt(0).getText();
            if (t == null) return;
            java.util.regex.Matcher m = CF_LINK.matcher(t);
            String link = null;
            while (m.find()) if (!"api".equals(m.group(1))) { link = m.group(0); break; }
            if (link == null || link.equals(prefs().getString("url", null)) || link.equals(lastOffered)) return;
            lastOffered = link;
            final String u = link;
            dialogOpen = true;
            new AlertDialog.Builder(this)
                    .setTitle("พบลิงก์เซิร์ฟเวอร์เสียง")
                    .setMessage(u + "\n\nเข้าห้องนี้เลยไหม?")
                    .setPositiveButton("เข้าเลย", (d, w) -> {
                        dialogOpen = false;
                        prefs().edit().putString("url", u).apply();
                        loadedUrl = u;
                        openTarget(u);
                    })
                    .setNegativeButton("ไม่", (d, w) -> dialogOpen = false)
                    .setOnCancelListener(d -> dialogOpen = false)
                    .show();
        } catch (Exception ignored) {
        }
    }

    private boolean hasMic() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    protected void onResume() {
        super.onResume();
        visible = true;
        applyPrefs();
        String url = prefs().getString("url", null);
        if (url != null && !url.equals(loadedUrl)) { loadedUrl = url; openTarget(url); }
    }

    @Override
    protected void onPause() {
        visible = false;
        if (VoiceService.instance != null) VoiceService.instance.applyBubble();
        super.onPause();
    }

    @Override
    protected void onStop() {
        // กันระบบพักหน้าเว็บตอนพับแอป
        if (web != null) { web.onResume(); web.resumeTimers(); }
        super.onStop();
    }

    private void applyPrefs() {
        if (prefs().getBoolean("screenOn", true)) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (hasMic() && prefs().getBoolean("keepalive", true)) startVoiceService();
        if (VoiceService.instance != null) VoiceService.instance.applyBubble();
    }

    /** ลิงก์ https/http เต็ม → เปิดตรงๆ; host:port หรือ ws:// → ใช้หน้าที่ฝังในแอป */
    private void openTarget(String input) {
        String u = input.trim();
        if (u.startsWith("https://") || u.startsWith("http://")) {
            web.loadUrl(u);
            return;
        }
        String ws = u;
        if (!(ws.startsWith("ws://") || ws.startsWith("wss://"))) ws = "ws://" + ws;
        web.loadUrl("https://appassets.local/index.html?server=" + Uri.encode(ws));
    }

    private void grantAudio(PermissionRequest req) {
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) {
                req.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                if (prefs().getBoolean("keepalive", true)) startVoiceService();
                return;
            }
        }
        req.deny();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (pendingWebPermission != null) {
            if (hasMic()) grantAudio(pendingWebPermission);
            else pendingWebPermission.deny();
            pendingWebPermission = null;
        }
    }

    private void startVoiceService() {
        try {
            startForegroundService(new Intent(this, VoiceService.class));
        } catch (Exception ignored) {
        }
    }

    private void askUrl(String title) {
        if (dialogOpen) return;
        dialogOpen = true;
        EditText et = new EditText(this);
        et.setHint("147.185.221.216:12345  หรือ  https://xxxx.trycloudflare.com");
        et.setText(prefs().getString("url", ""));
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(et)
                .setCancelable(false)
                .setNeutralButton("สร้างเซิร์ฟเวอร์เอง", (d, w) -> {
                    dialogOpen = false;
                    startActivity(new Intent(this, HostActivity.class));
                })
                .setPositiveButton("เปิด", (d, w) -> {
                    String u = et.getText().toString().trim();
                    dialogOpen = false;
                    if (u.isEmpty()) { askUrl("ใส่ที่อยู่เซิร์ฟเวอร์เสียง"); return; }
                    prefs().edit().putString("url", u).apply();
                    loadedUrl = u;
                    openTarget(u);
                })
                .show();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String lk = linkFromIntent(intent);
        if (lk != null) {
            prefs().edit().putString("url", lk).apply();
            loadedUrl = lk;
            openTarget(lk);
        }
        if (intent.getBooleanExtra("exit", false)) {
            stopService(new Intent(this, VoiceService.class));
            stopService(new Intent(this, HostService.class));
            finishAndRemoveTask();
        }
    }

    /** กดโฮม → ย่อเป็นหน้าต่างลอย (ถ้าเปิดไว้ในตั้งค่า) */
    @Override
    protected void onUserLeaveHint() {
        if (!prefs().getBoolean("pip", true)) return;
        try {
            enterPictureInPictureMode(
                    new PictureInPictureParams.Builder().setAspectRatio(new Rational(2, 1)).build());
        } catch (Exception ignored) {
        }
    }

    /** กดย้อนกลับ → ซ่อนแอปแต่ไม่ปิด */
    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        stopService(new Intent(this, VoiceService.class));
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }
}
