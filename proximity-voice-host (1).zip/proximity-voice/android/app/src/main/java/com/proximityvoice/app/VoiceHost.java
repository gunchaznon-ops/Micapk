package com.proximityvoice.app;

import android.content.res.AssetManager;

import fi.iki.elonen.NanoHTTPD;
import fi.iki.elonen.NanoWSD;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/** เซิร์ฟเวอร์เสียงในตัวแอป (พอร์ตตรรกะมาจาก server.js เดิม)
 *  - พอร์ต 3000: เว็บ + WebSocket ให้เพื่อนเข้า (ผ่าน cloudflared)
 *  - พอร์ต 3001 (เฉพาะเครื่องนี้): รับ /wsserver จากเกม */
final class VoiceHost {
    static final int VOICE_PORT = 3000, MC_PORT = 3001;
    private static final double FULL = 2, MAX = 32;

    private static final class Player {
        String name, dim;
        double x, y, z, fx, fz;
        long t;
    }

    private static final class Client {
        final int id;
        final NanoWSD.WebSocket ws;
        final String name;
        Client(int id, NanoWSD.WebSocket ws, String name) { this.id = id; this.ws = ws; this.name = name; }
    }

    private final AssetManager assets;
    private final Object lock = new Object();
    private final Map<String, Player> players = new HashMap<>();
    private final Map<String, String> codes = new HashMap<>();
    private final Map<String, String> nameCode = new HashMap<>();
    private final Map<Integer, Client> clients = new LinkedHashMap<>();
    private int nextId = 1;
    private final AtomicInteger games = new AtomicInteger();
    private volatile boolean running;
    private VoiceServer voice;
    private McServer mc;

    VoiceHost(AssetManager assets) { this.assets = assets; }

    boolean isRunning() { return running; }
    boolean gameConnected() { return games.get() > 0; }
    int clientCount() { synchronized (lock) { return clients.size(); } }

    void start() throws IOException {
        voice = new VoiceServer();
        voice.start(0, true);
        try {
            mc = new McServer();
            mc.start(0, true);
        } catch (IOException e) {
            voice.stop();
            throw e;
        }
        running = true;
    }

    void stop() {
        running = false;
        if (voice != null) voice.stop();
        if (mc != null) mc.stop();
    }

    // ---------- ตัวช่วย ----------
    private static JSONObject o(Object... kv) {
        JSONObject j = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) j.put((String) kv[i], kv[i + 1]);
        } catch (Exception ignored) { }
        return j;
    }

    private static void sendTo(NanoWSD.WebSocket ws, JSONObject j) {
        try { ws.send(j.toString()); } catch (Exception ignored) { }
    }

    /** เรียกขณะถือ lock */
    private String newCode(String name) {
        String c = nameCode.get(name);
        if (c != null) return c;
        do { c = String.valueOf(1000 + (int) (Math.random() * 9000)); } while (codes.containsKey(c));
        codes.put(c, name);
        nameCode.put(name, c);
        return c;
    }

    private double[] mixFor(String a, String b) {
        long now = System.currentTimeMillis();
        Player A = players.get(a), B = players.get(b);
        if (A == null || B == null || now - A.t > 3000 || now - B.t > 3000 || !A.dim.equals(B.dim))
            return new double[]{0, 0};
        double dx = B.x - A.x, dy = B.y - A.y, dz = B.z - A.z;
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double gain = dist <= FULL ? 1 : dist >= MAX ? 0 : 1 - (dist - FULL) / (MAX - FULL);
        double h = Math.hypot(dx, dz); if (h == 0) h = 1;
        double fl = Math.hypot(A.fx, A.fz); if (fl == 0) fl = 1;
        double fx = A.fx / fl, fz = A.fz / fl;
        // ขวามือของผู้ฟัง = (-fz, fx) ในพิกัด Minecraft (x=ตะวันออก, z=ใต้)
        double pan = Math.max(-1, Math.min(1, (dx / h) * -fz + (dz / h) * fx));
        return new double[]{gain * gain, dist < 1 ? 0 : pan};
    }

    private void sendMix() {
        synchronized (lock) {
            for (Client A : clients.values()) {
                JSONObject peers = new JSONObject();
                for (Client B : clients.values()) {
                    if (A.id == B.id) continue;
                    double[] m = mixFor(A.name, B.name);
                    try { peers.put(String.valueOf(B.id), o("gain", m[0], "pan", m[1])); } catch (Exception ignored) { }
                }
                sendTo(A.ws, o("type", "mix", "peers", peers));
            }
        }
    }

    // ---------- เซิร์ฟเวอร์เว็บ + WebSocket ของเพื่อน ----------
    private final class VoiceServer extends NanoWSD {
        VoiceServer() { super(VOICE_PORT); }

        @Override
        protected WebSocket openWebSocket(IHTTPSession handshake) { return new VoiceConn(handshake); }

        @Override
        public Response serve(IHTTPSession s) {
            String up = s.getHeaders().get("upgrade");
            if (up != null && up.equalsIgnoreCase("websocket")) return super.serve(s);
            String uri = s.getUri();
            if ("/".equals(uri) || "/index.html".equals(uri)) {
                try {
                    InputStream in = assets.open("index.html");
                    return newChunkedResponse(Response.Status.OK, "text/html; charset=utf-8", in);
                } catch (IOException e) {
                    return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", "no page");
                }
            }
            return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "not found");
        }
    }

    private final class VoiceConn extends NanoWSD.WebSocket {
        private int id = 0;

        VoiceConn(NanoHTTPD.IHTTPSession h) { super(h); }

        @Override protected void onOpen() { }

        @Override
        protected void onMessage(NanoWSD.WebSocketFrame frame) {
            JSONObject m;
            try { m = new JSONObject(frame.getTextPayload()); } catch (Exception e) { return; }
            String type = m.optString("type");
            synchronized (lock) {
                if ("join".equals(type) && id == 0) {
                    String name = codes.get(m.optString("code"));
                    if (name == null) {
                        sendTo(this, o("type", "error", "message", "รหัสไม่ถูกต้อง ดูรหัสที่แถบด้านบนจอในเกม"));
                        return;
                    }
                    id = nextId++;
                    JSONArray peers = new JSONArray();
                    for (Client c : clients.values()) peers.put(o("id", c.id, "name", c.name));
                    clients.put(id, new Client(id, this, name));
                    sendTo(this, o("type", "joined", "id", id, "name", name, "peers", peers));
                    for (Client c : clients.values())
                        if (c.id != id) sendTo(c.ws, o("type", "peer-joined", "id", id, "name", name));
                } else if ("signal".equals(type) && id != 0) {
                    Client t = clients.get(m.optInt("to"));
                    if (t != null) sendTo(t.ws, o("type", "signal", "from", id, "data", m.opt("data")));
                }
                // "level" ใช้เฉพาะโหมด BDS เดิม ตอนนี้ไม่ใช้ จึงไม่ต้องทำอะไร
            }
        }

        @Override
        protected void onClose(NanoWSD.WebSocketFrame.CloseCode code, String reason, boolean remote) {
            synchronized (lock) {
                if (id == 0) return;
                clients.remove(id);
                for (Client c : clients.values()) sendTo(c.ws, o("type", "peer-left", "id", id));
                id = 0;
            }
        }

        @Override protected void onPong(NanoWSD.WebSocketFrame pong) { }
        @Override protected void onException(IOException e) { }
    }

    // ---------- รับเกม Minecraft (/wsserver localhost:3001) ----------
    private final class McServer extends NanoWSD {
        McServer() { super("127.0.0.1", MC_PORT); }

        @Override
        protected WebSocket openWebSocket(IHTTPSession handshake) { return new McConn(handshake); }
    }

    private final class McConn extends NanoWSD.WebSocket {
        private final Map<String, CompletableFuture<JSONObject>> pending = new ConcurrentHashMap<>();
        private volatile boolean open;
        private Thread poller;

        McConn(NanoHTTPD.IHTTPSession h) { super(h); }

        @Override
        protected void onOpen() {
            open = true;
            games.incrementAndGet();
            poller = new Thread(this::loop, "mc-poll");
            poller.setDaemon(true);
            poller.start();
        }

        @Override
        protected void onClose(NanoWSD.WebSocketFrame.CloseCode code, String reason, boolean remote) {
            if (!open) return;
            open = false;
            games.decrementAndGet();
            if (poller != null) poller.interrupt();
        }

        @Override
        protected void onMessage(NanoWSD.WebSocketFrame frame) {
            try {
                JSONObject m = new JSONObject(frame.getTextPayload());
                JSONObject h = m.optJSONObject("header");
                if (h == null || !"commandResponse".equals(h.optString("messagePurpose"))) return;
                CompletableFuture<JSONObject> f = pending.remove(h.optString("requestId"));
                if (f != null) f.complete(m.optJSONObject("body") != null ? m.optJSONObject("body") : new JSONObject());
            } catch (Exception ignored) { }
        }

        @Override protected void onPong(NanoWSD.WebSocketFrame pong) { }
        @Override protected void onException(IOException e) { }

        private void fire(String line) {
            String id = UUID.randomUUID().toString();
            JSONObject req = o(
                    "header", o("version", 1, "requestId", id, "messageType", "commandRequest",
                            "messagePurpose", "commandRequest"),
                    "body", o("version", 1, "commandLine", line, "origin", o("type", "player")));
            try { this.send(req.toString()); } catch (Exception ignored) { }
        }

        private JSONObject cmd(String line, long ms) {
            String id = UUID.randomUUID().toString();
            CompletableFuture<JSONObject> f = new CompletableFuture<>();
            pending.put(id, f);
            JSONObject req = o(
                    "header", o("version", 1, "requestId", id, "messageType", "commandRequest",
                            "messagePurpose", "commandRequest"),
                    "body", o("version", 1, "commandLine", line, "origin", o("type", "player")));
            try {
                this.send(req.toString());
                return f.get(ms, TimeUnit.MILLISECONDS);
            } catch (Exception e) {
                pending.remove(id);
                return null;
            }
        }

        private List<String> parseNames(JSONObject b) {
            List<String> out = new ArrayList<>();
            if (b == null) return out;
            String s = b.optString("players", "");
            if (s.isEmpty() && b.has("statusMessage")) {
                String[] lines = b.optString("statusMessage").split("\n");
                s = lines[lines.length - 1];
            }
            for (String x : s.split("\\s*,\\s*")) {
                x = x.trim();
                if (!x.isEmpty()) out.add(x);
            }
            return out;
        }

        private void loop() {
            // คำสั่งไม่ต้องรอผล (ห้ามเรียกใน onOpen เพราะจะรอผลจากเธรดเดียวกัน)
            fire("gamerule sendcommandfeedback false");
            int tick = 0;
            while (open) {
                long t0 = System.currentTimeMillis();
                try { tick = poll(tick); } catch (Exception ignored) { }
                long wait = 500 - (System.currentTimeMillis() - t0);
                if (wait > 0) {
                    try { Thread.sleep(wait); } catch (InterruptedException e) { return; }
                }
            }
        }

        private int poll(int tick) {
            JSONObject lb = cmd("list", 1500);
            List<Player> list = new ArrayList<>();
            for (String name : parseNames(lb)) {
                JSONObject b = cmd("querytarget \"" + name.replace("\"", "") + "\"", 1500);
                if (b == null || !b.has("details")) continue;
                try {
                    JSONArray a = new JSONArray(b.optString("details"));
                    JSONObject p = a.optJSONObject(0);
                    if (p == null || p.optJSONObject("position") == null) continue;
                    JSONObject pos = p.getJSONObject("position");
                    double yaw = Math.toRadians(p.optDouble("yRot", 0));
                    Player pl = new Player();
                    pl.name = name;
                    pl.x = pos.optDouble("x"); pl.y = pos.optDouble("y"); pl.z = pos.optDouble("z");
                    pl.fx = -Math.sin(yaw); pl.fz = Math.cos(yaw);
                    pl.dim = p.has("dimension") ? String.valueOf(p.opt("dimension")) : "0";
                    list.add(pl);
                } catch (Exception ignored) { }
            }
            long now = System.currentTimeMillis();
            List<String[]> titles = new ArrayList<>();
            synchronized (lock) {
                java.util.Set<String> linked = new java.util.HashSet<>();
                for (Client c : clients.values()) linked.add(c.name);
                for (Player p : list) {
                    p.t = now;
                    players.put(p.name, p);
                    if (!linked.contains(p.name)) titles.add(new String[]{p.name, newCode(p.name)});
                }
            }
            if (tick % 3 == 0) {
                for (String[] t : titles)
                    fire("titleraw \"" + t[0] + "\" actionbar {\"rawtext\":[{\"text\":\"รหัสเสียง: " + t[1] + "\"}]}");
            }
            sendMix();
            return tick + 1;
        }
    }
}
