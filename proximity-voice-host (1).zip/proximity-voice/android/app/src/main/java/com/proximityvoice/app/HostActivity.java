package com.proximityvoice.app;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** หน้าสร้างเซิร์ฟเวอร์เสียงในแอป */
public class HostActivity extends Activity {
    private static final int BG = Color.parseColor("#161B18"), FG = Color.parseColor("#E8EFE9"),
            MUT = Color.parseColor("#8FA196"), AC = Color.parseColor("#5FBF86");
    private SharedPreferences sp;
    private LinearLayout box;
    private TextView status, link;
    private Button toggle, copy, share, joinSelf, logBtn;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() { refresh(); h.postDelayed(this, 1000); }
    };

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("pv", MODE_PRIVATE);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(24), dp(16), dp(40));
        sv.addView(box);
        setContentView(sv);

        text("สร้างเซิร์ฟเวอร์เสียง", 26, FG, true);
        text("เครื่องนี้เป็นโฮสต์ เพื่อนเข้าผ่านลิงก์อินเทอร์เน็ต (cloudflared ฝังในแอป)", 13, MUT, false);

        Switch sw = new Switch(this);
        sw.setText("ให้เพื่อนเข้าจากอินเทอร์เน็ต (cloudflared)");
        sw.setTextColor(FG);
        sw.setChecked(sp.getBoolean("tunnel", true));
        sw.setOnCheckedChangeListener((v, on) -> sp.edit().putBoolean("tunnel", on).apply());
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.setMargins(0, dp(16), 0, dp(8));
        box.addView(sw, slp);

        toggle = button("สร้างเซิร์ฟเวอร์", this::onToggle);
        status = text("", 14, FG, false);
        status.setPadding(0, dp(12), 0, dp(4));
        link = text("", 16, AC, true);
        link.setTextIsSelectable(true);
        copy = button("คัดลอกลิงก์", () -> {
            String u = linkUrl();
            if (u == null) return;
            ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("link", u));
            Toast.makeText(this, "คัดลอกแล้ว", Toast.LENGTH_SHORT).show();
        });
        share = button("แชร์ลิงก์ให้เพื่อน", () -> {
            String u = linkUrl();
            if (u == null) return;
            Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, "เข้าเสียงในเกม 🎧\nกดลิงก์นี้: " + u + "\n(ถ้าลงแอป Proximity Voice ไว้ ให้คัดลอกลิงก์แล้วเปิดแอป มันจะถามเข้าห้องให้เอง)\nแล้วใส่รหัส 4 หลักที่โชว์บนจอเกม");
            startActivity(Intent.createChooser(i, "แชร์ลิงก์"));
        });
        joinSelf = button("เข้าร่วมเสียงเอง (เครื่องนี้)", () -> {
            sp.edit().putString("url", "http://localhost:" + VoiceHost.VOICE_PORT).apply();
            startActivity(new Intent(this, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
        });
        logBtn = button("คัดลอก log cloudflared (ไว้ส่งให้ผมแก้)", () -> {
            HostService s = HostService.instance;
            String lg = (s != null && s.tunnel != null) ? s.tunnel.log() : "(ไม่มี log)";
            ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("log", lg));
            Toast.makeText(this, "คัดลอก log แล้ว", Toast.LENGTH_SHORT).show();
        });
        text("ในเกม (เป็นโฮสต์/เปิดโลก) พิมพ์:\n/wsserver localhost:3001\nแล้วรหัส 4 หลักจะขึ้นที่แถบด้านบนจอ", 13, MUT, false)
                .setPadding(0, dp(20), 0, 0);
    }

    private String linkUrl() {
        HostService s = HostService.instance;
        return (s != null && s.tunnel != null) ? s.tunnel.url : null;
    }

    private void onToggle() {
        HostService s = HostService.instance;
        if (s != null) {
            stopService(new Intent(this, HostService.class));
        } else {
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 21);
            try {
                startForegroundService(new Intent(this, HostService.class)
                        .putExtra("tunnel", sp.getBoolean("tunnel", true)));
            } catch (Exception e) {
                Toast.makeText(this, "เริ่มบริการไม่ได้: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
        h.postDelayed(this::refresh, 300);
    }

    @Override protected void onResume() { super.onResume(); h.post(tick); }
    @Override protected void onPause() { h.removeCallbacks(tick); super.onPause(); }

    private void refresh() {
        HostService s = HostService.instance;
        boolean on = s != null;
        toggle.setText(on ? "หยุดเซิร์ฟเวอร์" : "สร้างเซิร์ฟเวอร์");
        String u = linkUrl();
        link.setText(u == null ? "" : u);
        int vis = u == null ? android.view.View.GONE : android.view.View.VISIBLE;
        copy.setVisibility(vis);
        share.setVisibility(vis);
        joinSelf.setVisibility(on && s.host != null ? android.view.View.VISIBLE : android.view.View.GONE);
        logBtn.setVisibility(on && s.tunnel != null ? android.view.View.VISIBLE : android.view.View.GONE);
        if (!on) { status.setText("ยังไม่ได้เริ่ม"); return; }
        if (s.error != null) { status.setText(s.error); return; }
        VoiceHost vh = s.host;
        StringBuilder sb = new StringBuilder();
        sb.append("เซิร์ฟเวอร์: ").append(vh != null ? "ทำงานอยู่ (พอร์ต 3000)" : "กำลังเริ่ม...").append('\n');
        sb.append("เกม: ").append(vh != null && vh.gameConnected() ? "ต่ออยู่ ✓" : "ยังไม่ต่อ").append('\n');
        sb.append("คนในห้องเสียง: ").append(vh != null ? vh.clientCount() : 0).append('\n');
        Tunnel t = s.tunnel;
        if (t != null) {
            String st = t.state;
            sb.append("อินเทอร์เน็ต: ");
            switch (st) {
                case "ok": sb.append("พร้อม ✓"); break;
                case "starting": sb.append("กำลังขอลิงก์..."); break;
                case "missing": sb.append("ไม่พบ cloudflared ในแอป (บิลด์ไม่ได้ฝัง)"); break;
                default: sb.append("ไม่สำเร็จ (").append(st).append(") กด \"คัดลอก log\" ส่งให้ผม"); break;
            }
        }
        status.setText(sb.toString());
    }

    // ---------- ตัวช่วย UI ----------
    private TextView text(String t, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(size); v.setTextColor(color);
        if (bold) v.setTypeface(null, android.graphics.Typeface.BOLD);
        box.addView(v);
        return v;
    }

    private Button button(String t, Runnable r) {
        Button bt = new Button(this);
        bt.setText(t);
        bt.setAllCaps(false);
        bt.setGravity(Gravity.CENTER);
        bt.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(8), 0, 0);
        box.addView(bt, lp);
        return bt;
    }
}
